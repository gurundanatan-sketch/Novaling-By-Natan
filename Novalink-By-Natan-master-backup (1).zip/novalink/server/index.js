// Novalink By Natan — real-time server (zero dependencies, Node >= 20)
'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { attachWebSocket } = require('./ws');
const { Store } = require('./store');

const ROOT = path.resolve(__dirname, '..');
const CLIENT_DIR = path.join(ROOT, 'client');
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const MAX_UPLOAD = Number(process.env.MAX_UPLOAD_MB || 1024) * 1024 * 1024; // 1 GB default — long story videos
const STORY_TTL = 24 * 3600 * 1000;
const MAX_GROUP_MEMBERS = 1024;
const APP_NAME = 'Novalink By Natan';

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp',
  '.mp4': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime', '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg',
  '.wav': 'audio/wav', '.m4a': 'audio/mp4', '.pdf': 'application/pdf', '.txt': 'text/plain; charset=utf-8',
  '.zip': 'application/zip', '.ico': 'image/x-icon',
};

function createServer({ dataFile = path.join(DATA_DIR, 'db.json'), persist = true } = {}) {
  const store = new Store(persist ? dataFile : null);
  const db = store.data;
  const sockets = new Map();   // userId -> Set<ws>
  const callRooms = new Map(); // roomId -> Set<userId>
  const rate = new Map();      // key -> {count, reset}
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });

  // ---------- helpers ----------
  const uid = (n = 12) => crypto.randomBytes(n).toString('base64url');
  const now = () => Date.now();
  const hashPin = (pin, salt) => crypto.scryptSync(String(pin), salt, 32).toString('hex');
  const hashPhone = (phone) => crypto.createHash('sha256').update('novalink:' + String(phone).replace(/\D/g, '')).digest('hex');

  function limited(key, max, windowMs) {
    const r = rate.get(key);
    const t = now();
    if (!r || r.reset < t) { rate.set(key, { count: 1, reset: t + windowMs }); return false; }
    r.count++;
    return r.count > max;
  }

  /** Public profile — never contains phone numbers or IPs (anti-tracking). */
  function publicUser(u, viewerId) {
    if (!u) return null;
    const isContact = viewerId && (u.contacts || []).includes(viewerId);
    const lastSeenRule = u.privacy?.lastSeen || 'contacts';
    const showLastSeen = lastSeenRule === 'all' || (lastSeenRule === 'contacts' && isContact) || u.id === viewerId;
    return {
      id: u.id, username: u.username, displayName: u.displayName, about: u.about || '',
      avatar: u.avatar || null, verified: !!u.verified,
      online: showLastSeen ? sockets.has(u.id) : null,
      lastSeen: showLastSeen ? u.lastSeen || null : null,
      waNumber: u.privacy?.shareWhatsApp && (isContact || u.id === viewerId) ? u.waNumber || null : null,
    };
  }

  function selfUser(u) {
    return { ...publicUser(u, u.id), contacts: u.contacts || [], blocked: u.blocked || [], privacy: u.privacy || {},
      waNumber: u.waNumber || '', hasPhone: !!u.phoneHash, discoverable: u.discoverable !== false };
  }

  function authUser(req, url) {
    const h = req.headers.authorization || '';
    const token = h.startsWith('Bearer ') ? h.slice(7) : url?.searchParams.get('token');
    const id = token && db.tokens[token];
    return id ? db.users[id] : null;
  }

  function send(res, status, body, headers = {}) {
    const data = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body);
    res.writeHead(status, {
      'Content-Type': typeof body === 'object' && !Buffer.isBuffer(body) ? 'application/json' : 'text/plain; charset=utf-8',
      ...securityHeaders(), ...headers,
    });
    res.end(data);
  }

  function securityHeaders() {
    return {
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'no-referrer',            // do not leak URLs/identity to other sites
      'Permissions-Policy': 'geolocation=()',     // location is never requested
      'Cross-Origin-Opener-Policy': 'same-origin',
      // Token-based auth (no cookies), so any origin may call the API: web, GitHub Pages, Android APK.
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Authorization, Content-Type, X-Filename, Range',
      'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
      'Access-Control-Expose-Headers': 'Content-Range, Accept-Ranges',
    };
  }

  function readBody(req, limit = 1024 * 1024) {
    return new Promise((resolve, reject) => {
      const chunks = []; let size = 0;
      req.on('data', (c) => { size += c.length; if (size > limit) { reject(new Error('too large')); req.destroy(); } else chunks.push(c); });
      req.on('end', () => resolve(Buffer.concat(chunks)));
      req.on('error', reject);
    });
  }
  async function readJSON(req) {
    const b = await readBody(req);
    try { return b.length ? JSON.parse(b.toString('utf8')) : {}; } catch { return {}; }
  }

  function emit(userId, payload) {
    const set = sockets.get(userId);
    if (!set) return false;
    const s = JSON.stringify(payload);
    for (const ws of set) ws.send(s);
    return true;
  }

  function convMembers(to) {
    if (db.groups[to]) return db.groups[to].members;
    return null;
  }

  function canSee(msg, userId) {
    if (msg.from === userId || msg.to === userId) return true;
    const g = db.groups[msg.to];
    return !!g && g.members.includes(userId);
  }

  function visibleStories(viewer) {
    const t = now();
    return db.stories.filter((s) => s.expires > t && (
      s.owner === viewer.id || s.audience === 'public' ||
      (s.audience === 'contacts' && (db.users[s.owner]?.contacts || []).includes(viewer.id))
    ) && !(db.users[s.owner]?.blocked || []).includes(viewer.id));
  }

  function prune() {
    const t = now();
    const before = db.messages.length + db.stories.length;
    db.messages = db.messages.filter((m) => !m.expiresAt || m.expiresAt > t);
    db.stories = db.stories.filter((s) => s.expires > t);
    if (db.messages.length + db.stories.length !== before) store.save();
  }
  const pruneTimer = setInterval(prune, 60 * 1000);
  pruneTimer.unref();

  function broadcastPresence(u) {
    for (const cid of u.contacts || []) {
      const c = db.users[cid];
      if (c) emit(cid, { t: 'presence', user: publicUser(u, cid) });
    }
  }

  // ---------- TURN / ICE (IP protection) ----------
  function iceConfig(user) {
    const servers = [];
    const stun = process.env.STUN_URLS || 'stun:stun.l.google.com:19302';
    servers.push({ urls: stun.split(',') });
    if (process.env.TURN_URLS && process.env.TURN_SECRET) {
      // coturn "use-auth-secret" REST credentials, valid 12h
      const username = `${Math.floor(now() / 1000) + 12 * 3600}:${user.id}`;
      const credential = crypto.createHmac('sha1', process.env.TURN_SECRET).update(username).digest('base64');
      servers.push({ urls: process.env.TURN_URLS.split(','), username, credential });
    }
    return { iceServers: servers, relayAvailable: servers.length > 1 };
  }

  // ---------- LiveKit token for large group calls (> 8 people, up to hundreds) ----------
  function livekitToken(user, room) {
    const key = process.env.LIVEKIT_API_KEY, secret = process.env.LIVEKIT_API_SECRET, url = process.env.LIVEKIT_URL;
    if (!key || !secret || !url) return null;
    const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
    const header = b64({ alg: 'HS256', typ: 'JWT' });
    const t = Math.floor(now() / 1000);
    const payload = b64({ iss: key, sub: user.id, name: user.displayName, nbf: t, exp: t + 6 * 3600,
      video: { room, roomJoin: true, canPublish: true, canSubscribe: true } });
    const sig = crypto.createHmac('sha256', secret).update(`${header}.${payload}`).digest('base64url');
    return { url, token: `${header}.${payload}.${sig}` };
  }

  // ---------- AI assistant (optional LLM, heuristic fallback) ----------
  function heuristicReplies(text = '') {
    const t = text.toLowerCase();
    if (/\?$|apa|kapan|dimana|di mana|gimana|bagaimana|kenapa|siapa/.test(t)) return ['Sebentar ya, aku cek dulu 🙏', 'Nanti aku kabari lagi ya', 'Boleh, kita bahas nanti?'];
    if (/terima kasih|makasih|thanks|thx/.test(t)) return ['Sama-sama! 😊', 'Siap, sama-sama 🙌', 'Anytime!'];
    if (/halo|hai|hi|hello|pagi|siang|sore|malam|assalam/.test(t)) return ['Halo juga! 👋', 'Hai, ada apa nih?', 'Halo, apa kabar?'];
    if (/telepon|telpon|call|vc/.test(t)) return ['Aku telepon balik sebentar lagi ya 📞', 'Lagi nggak bisa angkat, chat aja dulu ya', 'Oke, jam berapa enaknya?'];
    if (/maaf|sorry/.test(t)) return ['Nggak apa-apa kok 😊', 'Santai aja', 'Oke, dimaafkan 🤝'];
    return ['Oke 👍', 'Siap!', 'Nanti aku balas lagi ya'];
  }

  async function aiReplies(context, lastText) {
    const url = process.env.AI_API_URL, key = process.env.AI_API_KEY;
    if (!url || !key) return { source: 'local', replies: heuristicReplies(lastText) };
    try {
      const r = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
        body: JSON.stringify({
          model: process.env.AI_MODEL || 'gpt-4o-mini',
          messages: [
            { role: 'system', content: 'Kamu asisten chat di aplikasi Novalink By Natan. Berikan tepat 3 saran balasan singkat, santai, berbahasa Indonesia, satu per baris, tanpa penomoran.' },
            { role: 'user', content: `Percakapan:\n${String(context).slice(-3000)}\n\nPesan terakhir: ${lastText}` },
          ],
          max_tokens: 150,
        }),
      });
      const j = await r.json();
      const out = (j.choices?.[0]?.message?.content || '').split('\n').map((s) => s.replace(/^[-*\d.\s]+/, '').trim()).filter(Boolean).slice(0, 3);
      return out.length ? { source: 'ai', replies: out } : { source: 'local', replies: heuristicReplies(lastText) };
    } catch {
      return { source: 'local', replies: heuristicReplies(lastText) };
    }
  }

  // ---------- static + media ----------
  function serveFile(req, res, file, extraHeaders = {}) {
    fs.stat(file, (err, st) => {
      if (err || !st.isFile()) return send(res, 404, 'Not found');
      const type = MIME[path.extname(file).toLowerCase()] || 'application/octet-stream';
      const range = req.headers.range;
      const base = { 'Content-Type': type, 'Accept-Ranges': 'bytes', ...securityHeaders(), ...extraHeaders };
      if (range) {
        const m = /bytes=(\d*)-(\d*)/.exec(range);
        let start = m && m[1] ? Number(m[1]) : 0;
        let end = m && m[2] ? Number(m[2]) : st.size - 1;
        if (start >= st.size) { res.writeHead(416, { 'Content-Range': `bytes */${st.size}` }); return res.end(); }
        end = Math.min(end, st.size - 1);
        res.writeHead(206, { ...base, 'Content-Range': `bytes ${start}-${end}/${st.size}`, 'Content-Length': end - start + 1 });
        fs.createReadStream(file, { start, end }).pipe(res);
      } else {
        res.writeHead(200, { ...base, 'Content-Length': st.size });
        if (req.method === 'HEAD') return res.end();
        fs.createReadStream(file).pipe(res);
      }
    });
  }

  function storyPage(owner, stories) {
    const esc = (s) => String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const items = stories.map((s) => {
      if (s.type === 'video') return `<video src="${esc(s.media)}" controls playsinline preload="metadata"></video><p>${esc(s.caption)}</p>`;
      if (s.type === 'image') return `<img src="${esc(s.media)}" alt="story"><p>${esc(s.caption)}</p>`;
      return `<div class="txt" style="background:${esc(s.bg || '#6d28d9')}">${esc(s.text)}</div>`;
    }).join('');
    const wa = owner.privacy?.shareWhatsApp && owner.waNumber
      ? `<a class="btn wa" href="https://wa.me/${esc(owner.waNumber.replace(/\D/g, ''))}">Chat via WhatsApp</a>` : '';
    return `<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Story ${esc(owner.displayName)} · ${APP_NAME}</title>
<meta property="og:title" content="Story ${esc(owner.displayName)} di ${APP_NAME}"><meta property="og:description" content="Lihat story & simpan kontak @${esc(owner.username)}">
<style>body{margin:0;font-family:system-ui;background:#07060f;color:#eee;display:flex;flex-direction:column;align-items:center;padding:24px}
h1{font-size:20px}video,img{max-width:100%;border-radius:18px;margin-top:16px}.txt{padding:60px 24px;border-radius:18px;font-size:22px;text-align:center;width:100%;max-width:480px;box-sizing:border-box;margin-top:16px}
.btn{display:inline-block;margin:8px;padding:12px 20px;border-radius:999px;background:linear-gradient(90deg,#7c3aed,#06b6d4);color:#fff;text-decoration:none;font-weight:600}.wa{background:#25d366}</style></head>
<body><h1>✦ ${esc(owner.displayName)} <small style="opacity:.6">@${esc(owner.username)}</small></h1>
<div><a class="btn" href="/api/vcard/${esc(owner.username)}">Simpan Kontak</a><a class="btn" href="/#/add/${esc(owner.username)}">Chat di Novalink</a>${wa}</div>
<div style="max-width:480px;width:100%">${items || '<p>Belum ada story publik.</p>'}</div></body></html>`;
  }

  // ---------- HTTP routes ----------
  async function handle(req, res) {
    const url = new URL(req.url, 'http://x');
    const p = url.pathname;
    if (req.method === 'OPTIONS') { res.writeHead(204, securityHeaders()); return res.end(); }
    try {
      if (p.startsWith('/api/')) return await api(req, res, url, p);
      if (p.startsWith('/media/')) {
        const f = path.join(UPLOAD_DIR, path.basename(p));
        return serveFile(req, res, f, { 'Cache-Control': 'private, max-age=31536000, immutable' });
      }
      if (p.startsWith('/s/')) {
        const owner = Object.values(db.users).find((u) => u.username === decodeURIComponent(p.slice(3)).toLowerCase());
        if (!owner) return send(res, 404, 'Story tidak ditemukan');
        const list = db.stories.filter((s) => s.owner === owner.id && s.audience === 'public' && s.expires > now());
        return send(res, 200, storyPage(owner, list), { 'Content-Type': 'text/html; charset=utf-8' });
      }
      let file = path.normalize(path.join(CLIENT_DIR, p === '/' ? 'index.html' : p));
      if (!file.startsWith(CLIENT_DIR)) return send(res, 403, 'Forbidden');
      if (!fs.existsSync(file)) file = path.join(CLIENT_DIR, 'index.html');
      const extra = file.endsWith('sw.js') ? { 'Service-Worker-Allowed': '/', 'Cache-Control': 'no-cache' } : { 'Cache-Control': 'no-cache' };
      return serveFile(req, res, file, extra);
    } catch (e) {
      return send(res, 500, { error: 'server_error', detail: e.message });
    }
  }

  async function api(req, res, url, p) {
    const m = req.method;
    const ipKey = 'ip:' + (req.socket.remoteAddress || ''); // used only in-memory for rate limiting, never stored
    if (p === '/api/health') return send(res, 200, { ok: true, app: APP_NAME, users: Object.keys(db.users).length });

    if (p === '/api/register' && m === 'POST') {
      if (limited(ipKey + ':reg', 10, 3600e3)) return send(res, 429, { error: 'Terlalu banyak percobaan' });
      const b = await readJSON(req);
      const username = String(b.username || '').toLowerCase().trim();
      if (!/^[a-z0-9_.]{3,24}$/.test(username)) return send(res, 400, { error: 'Username 3-24 karakter (huruf, angka, _ .)' });
      if (!/^\d{4,8}$/.test(String(b.pin || ''))) return send(res, 400, { error: 'PIN harus 4-8 digit' });
      if (Object.values(db.users).some((u) => u.username === username)) return send(res, 409, { error: 'Username sudah dipakai' });
      const salt = uid(16);
      const u = {
        id: uid(9), username, displayName: String(b.displayName || username).slice(0, 40), about: 'Hai! Aku pakai Novalink ✦',
        salt, pinHash: hashPin(b.pin, salt), phoneHash: b.phone ? hashPhone(b.phone) : null, waNumber: '',
        contacts: [], blocked: [], discoverable: true, createdAt: now(), lastSeen: now(),
        privacy: { lastSeen: 'contacts', readReceipts: true, shareWhatsApp: false, storyAudience: 'contacts' },
      };
      db.users[u.id] = u;
      const token = uid(32); db.tokens[token] = u.id; store.save();
      return send(res, 201, { token, user: selfUser(u) });
    }

    if (p === '/api/login' && m === 'POST') {
      const b = await readJSON(req);
      const username = String(b.username || '').toLowerCase().trim();
      if (limited(ipKey + ':login:' + username, 8, 15 * 60e3)) return send(res, 429, { error: 'Terlalu banyak percobaan, coba lagi nanti' });
      const u = Object.values(db.users).find((x) => x.username === username);
      if (!u || !crypto.timingSafeEqual(Buffer.from(hashPin(b.pin || '', u.salt)), Buffer.from(u.pinHash))) return send(res, 401, { error: 'Username atau PIN salah' });
      const token = uid(32); db.tokens[token] = u.id; store.save();
      return send(res, 200, { token, user: selfUser(u) });
    }

    // public endpoints
    if (p.startsWith('/api/vcard/')) {
      const u = Object.values(db.users).find((x) => x.username === decodeURIComponent(p.slice(11)).toLowerCase());
      if (!u) return send(res, 404, 'not found');
      const host = req.headers.host || 'localhost';
      const tel = u.privacy?.shareWhatsApp && u.waNumber ? `TEL;TYPE=CELL:${u.waNumber}\r\n` : '';
      const card = `BEGIN:VCARD\r\nVERSION:3.0\r\nFN:${u.displayName}\r\nNOTE:Novalink @${u.username}\r\n${tel}URL:https://${host}/#/add/${u.username}\r\nEND:VCARD\r\n`;
      return send(res, 200, card, { 'Content-Type': 'text/vcard; charset=utf-8', 'Content-Disposition': `attachment; filename="${u.username}.vcf"` });
    }

    const me = authUser(req, url);
    if (!me) return send(res, 401, { error: 'unauthorized' });

    if (p === '/api/logout' && m === 'POST') {
      const token = (req.headers.authorization || '').slice(7); delete db.tokens[token]; store.save();
      return send(res, 200, { ok: true });
    }
    if (p === '/api/me' && m === 'GET') return send(res, 200, selfUser(me));
    if (p === '/api/me' && m === 'PATCH') {
      const b = await readJSON(req);
      if (b.displayName) me.displayName = String(b.displayName).slice(0, 40);
      if (b.about !== undefined) me.about = String(b.about).slice(0, 140);
      if (b.avatar !== undefined) me.avatar = b.avatar ? String(b.avatar).slice(0, 300) : null;
      if (b.waNumber !== undefined) me.waNumber = String(b.waNumber).replace(/[^\d+]/g, '').slice(0, 16);
      if (b.discoverable !== undefined) me.discoverable = !!b.discoverable;
      if (b.privacy) me.privacy = { ...me.privacy, ...b.privacy };
      store.save(); broadcastPresence(me);
      return send(res, 200, selfUser(me));
    }

    if (p === '/api/bootstrap') {
      const contacts = (me.contacts || []).map((id) => publicUser(db.users[id], me.id)).filter(Boolean);
      const groups = Object.values(db.groups).filter((g) => g.members.includes(me.id));
      const peers = new Set(contacts.map((c) => c.id));
      const messages = db.messages.filter((x) => canSee(x, me.id)).slice(-3000);
      for (const x of messages) { peers.add(x.from); if (db.users[x.to]) peers.add(x.to); }
      for (const g of groups) for (const id of g.members) peers.add(id);
      const users = [...peers].map((id) => publicUser(db.users[id], me.id)).filter(Boolean);
      const stories = visibleStories(me);
      return send(res, 200, { me: selfUser(me), users, groups, messages, stories, ice: iceConfig(me), livekit: !!process.env.LIVEKIT_URL });
    }

    if (p === '/api/users/search') {
      // Anti-tracking: exact/prefix username search only, rate limited, no phone enumeration.
      if (limited('search:' + me.id, 30, 60e3)) return send(res, 429, { error: 'Pelan-pelan ya, terlalu banyak pencarian' });
      const q = String(url.searchParams.get('q') || '').toLowerCase().replace(/^@/, '').trim();
      if (q.length < 3) return send(res, 200, []);
      const out = Object.values(db.users)
        .filter((u) => u.id !== me.id && u.discoverable !== false && u.username.startsWith(q) && !(u.blocked || []).includes(me.id))
        .slice(0, 10).map((u) => publicUser(u, me.id));
      return send(res, 200, out);
    }

    if (p === '/api/users/by-phone' && m === 'POST') {
      // Optional contact discovery by phone — hashed, strictly rate limited, only if target opted in.
      if (limited('phone:' + me.id, 5, 3600e3)) return send(res, 429, { error: 'Batas pencarian nomor tercapai (anti-pelacakan)' });
      const b = await readJSON(req);
      const h = hashPhone(b.phone || '');
      const u = Object.values(db.users).find((x) => x.phoneHash === h && x.privacy?.findByPhone === true);
      return send(res, 200, u ? [publicUser(u, me.id)] : []);
    }

    if (p === '/api/contacts' && m === 'POST') {
      const b = await readJSON(req);
      const u = db.users[b.id] || Object.values(db.users).find((x) => x.username === String(b.username || '').toLowerCase());
      if (!u || u.id === me.id) return send(res, 404, { error: 'Pengguna tidak ditemukan' });
      if (!me.contacts.includes(u.id)) me.contacts.push(u.id);
      store.save();
      emit(u.id, { t: 'user', user: publicUser(me, u.id) });
      return send(res, 200, publicUser(u, me.id));
    }
    if (p === '/api/block' && m === 'POST') {
      const b = await readJSON(req);
      if (!db.users[b.id]) return send(res, 404, { error: 'not found' });
      if (b.block) { if (!me.blocked.includes(b.id)) me.blocked.push(b.id); } else me.blocked = me.blocked.filter((x) => x !== b.id);
      store.save(); return send(res, 200, selfUser(me));
    }

    if (p === '/api/groups' && m === 'POST') {
      const b = await readJSON(req);
      const members = [...new Set([me.id, ...(b.members || []).filter((id) => db.users[id])])].slice(0, MAX_GROUP_MEMBERS);
      const g = { id: 'g_' + uid(8), name: String(b.name || 'Grup Baru').slice(0, 50), avatar: b.avatar || null,
        members, admins: [me.id], createdAt: now(), description: String(b.description || '') };
      db.groups[g.id] = g; store.save();
      for (const id of members) emit(id, { t: 'group', group: g, users: members.map((x) => publicUser(db.users[x], id)) });
      return send(res, 201, g);
    }
    const gm = /^\/api\/groups\/([\w-]+)$/.exec(p);
    if (gm && m === 'PATCH') {
      const g = db.groups[gm[1]];
      if (!g || !g.admins.includes(me.id)) return send(res, 403, { error: 'Hanya admin' });
      const b = await readJSON(req);
      if (b.name) g.name = String(b.name).slice(0, 50);
      if (b.add) for (const id of b.add) if (db.users[id] && !g.members.includes(id) && g.members.length < MAX_GROUP_MEMBERS) g.members.push(id);
      if (b.remove) g.members = g.members.filter((x) => !b.remove.includes(x));
      store.save();
      for (const id of g.members) emit(id, { t: 'group', group: g, users: g.members.map((x) => publicUser(db.users[x], id)) });
      return send(res, 200, g);
    }

    if (p === '/api/upload' && m === 'POST') {
      const len = Number(req.headers['content-length'] || 0);
      if (len > MAX_UPLOAD) return send(res, 413, { error: 'File terlalu besar' });
      const name = decodeURIComponent(String(req.headers['x-filename'] || 'file'));
      let ext = path.extname(name).toLowerCase().replace(/[^.\w]/g, '').slice(0, 8);
      if (!ext) ext = '.bin';
      const fname = uid(16) + ext;
      const out = fs.createWriteStream(path.join(UPLOAD_DIR, fname));
      let size = 0;
      req.on('data', (c) => { size += c.length; if (size > MAX_UPLOAD) { req.destroy(); out.destroy(); } });
      req.pipe(out);
      out.on('finish', () => send(res, 201, { url: '/media/' + fname, name, size }));
      out.on('error', () => send(res, 500, { error: 'upload gagal' }));
      return;
    }

    if (p === '/api/stories' && m === 'POST') {
      const b = await readJSON(req);
      const s = { id: 's_' + uid(8), owner: me.id, type: ['image', 'video', 'text'].includes(b.type) ? b.type : 'text',
        media: b.media || null, text: String(b.text || '').slice(0, 700), caption: String(b.caption || '').slice(0, 300),
        bg: b.bg || null, duration: Number(b.duration) || null, audience: b.audience === 'public' ? 'public' : 'contacts',
        createdAt: now(), expires: now() + STORY_TTL, views: [] };
      db.stories.push(s); store.save();
      const targets = new Set(s.audience === 'public' ? sockets.keys() : (me.contacts || []).filter((cid) => (db.users[cid]?.contacts || []).length >= 0));
      targets.add(me.id);
      for (const id of targets) if (!(me.blocked || []).includes(id)) emit(id, { t: 'story', story: s, user: publicUser(me, id) });
      return send(res, 201, s);
    }
    const sv = /^\/api\/stories\/([\w-]+)\/view$/.exec(p);
    if (sv && m === 'POST') {
      const s = db.stories.find((x) => x.id === sv[1]);
      if (s && s.owner !== me.id && !s.views.some((v) => v.id === me.id)) {
        s.views.push({ id: me.id, at: now() }); store.save();
        emit(s.owner, { t: 'story-view', id: s.id, viewer: publicUser(me, s.owner) });
      }
      return send(res, 200, { ok: true });
    }
    const sd = /^\/api\/stories\/([\w-]+)$/.exec(p);
    if (sd && m === 'DELETE') {
      db.stories = db.stories.filter((x) => !(x.id === sd[1] && x.owner === me.id)); store.save();
      return send(res, 200, { ok: true });
    }

    if (p === '/api/ice') return send(res, 200, iceConfig(me));
    if (p === '/api/livekit') {
      const room = String(url.searchParams.get('room') || '');
      const t = livekitToken(me, room);
      return t ? send(res, 200, t) : send(res, 404, { error: 'SFU tidak dikonfigurasi' });
    }
    if (p === '/api/ai/reply' && m === 'POST') {
      if (limited('ai:' + me.id, 30, 60e3)) return send(res, 429, { error: 'AI sedang sibuk' });
      const b = await readJSON(req);
      return send(res, 200, await aiReplies(b.context || '', b.text || ''));
    }
    return send(res, 404, { error: 'not_found' });
  }

  // ---------- WebSocket ----------
  function onSocket(ws, req, url) {
    const me = authUser(req, url);
    if (!me) { ws.close(4001, 'unauthorized'); return; }
    if (!sockets.has(me.id)) sockets.set(me.id, new Set());
    sockets.get(me.id).add(ws);
    me.lastSeen = now();
    broadcastPresence(me);
    ws.send({ t: 'hello', id: me.id, serverTime: now() });

    ws.on('message', (raw) => {
      let m; try { m = JSON.parse(raw); } catch { return; }
      if (limited('ws:' + me.id, 300, 10e3)) return;
      handleWS(me, ws, m);
    });
    ws.on('close', () => {
      const set = sockets.get(me.id);
      if (set) { set.delete(ws); if (!set.size) sockets.delete(me.id); }
      me.lastSeen = now(); store.save();
      for (const [room, members] of callRooms) if (members.has(me.id) && !sockets.has(me.id)) leaveRoom(me, room);
      broadcastPresence(me);
    });
  }

  function deliver(msg, payload) {
    const g = db.groups[msg.to];
    const targets = g ? g.members : [msg.to, msg.from];
    let delivered = false;
    for (const id of targets) {
      if (id !== msg.from && (db.users[id]?.blocked || []).includes(msg.from)) continue;
      if (emit(id, payload) && id !== msg.from) delivered = true;
    }
    return delivered;
  }

  function leaveRoom(me, room) {
    const members = callRooms.get(room);
    if (!members) return;
    members.delete(me.id);
    for (const id of members) emit(id, { t: 'call-left', room, user: me.id });
    if (!members.size) callRooms.delete(room);
  }

  function handleWS(me, ws, m) {
    switch (m.t) {
      case 'msg': {
        const to = String(m.to || '');
        const isGroup = !!db.groups[to];
        if (!isGroup && !db.users[to]) return;
        if (isGroup && !db.groups[to].members.includes(me.id)) return;
        if (db.messages.some((x) => x.id === m.id)) { ws.send({ t: 'ack', id: m.id, ts: now(), dup: true }); return; }
        const msg = {
          id: String(m.id || uid(10)).slice(0, 40), from: me.id, to, ts: now(), kind: m.kind || 'text',
          text: String(m.text || '').slice(0, 20000), media: m.media || null, replyTo: m.replyTo || null,
          forwarded: !!m.forwarded, viewOnce: !!m.viewOnce, expiresAt: m.ttl ? now() + Number(m.ttl) * 1000 : null,
          status: 'sent', reactions: {}, edits: [], deleted: false, offline: !!m.offline, clientTs: m.clientTs || null,
        };
        db.messages.push(msg); store.save();
        const delivered = deliver(msg, { t: 'msg', msg });
        if (delivered && !isGroup) msg.status = 'delivered';
        ws.send({ t: 'ack', id: msg.id, ts: msg.ts, status: msg.status });
        if (delivered && !isGroup) emit(me.id, { t: 'status', ids: [msg.id], status: 'delivered' });
        break;
      }
      case 'read': {
        if (me.privacy?.readReceipts === false) return;
        const ids = (m.ids || []).slice(0, 500);
        const bySender = {};
        for (const x of db.messages) if (ids.includes(x.id) && x.to === me.id) { x.status = 'read'; (bySender[x.from] ||= []).push(x.id); }
        for (const [from, list] of Object.entries(bySender)) emit(from, { t: 'status', ids: list, status: 'read' });
        store.save();
        break;
      }
      case 'delete': {
        const x = db.messages.find((y) => y.id === m.id && y.from === me.id);
        if (!x || x.deleted) return;
        // Delete-for-everyone: content is retained so recipients with "Anti Hapus" can still view it.
        x.deleted = true; x.deletedAt = now(); store.save();
        deliver(x, { t: 'deleted', id: x.id, at: x.deletedAt, to: x.to, from: x.from });
        break;
      }
      case 'edit': {
        const x = db.messages.find((y) => y.id === m.id && y.from === me.id && !y.deleted);
        if (!x || now() - x.ts > 15 * 60e3) return;
        x.edits.push({ text: x.text, at: now() }); x.text = String(m.text || '').slice(0, 20000); store.save();
        deliver(x, { t: 'edited', id: x.id, text: x.text, edits: x.edits });
        break;
      }
      case 'react': {
        const x = db.messages.find((y) => y.id === m.id);
        if (!x || !canSee(x, me.id)) return;
        if (m.emoji) x.reactions[me.id] = String(m.emoji).slice(0, 8); else delete x.reactions[me.id];
        store.save();
        deliver(x, { t: 'reaction', id: x.id, reactions: x.reactions });
        break;
      }
      case 'typing': {
        const g = db.groups[m.to];
        const targets = g ? g.members.filter((x) => x !== me.id) : [m.to];
        for (const id of targets) emit(id, { t: 'typing', from: me.id, to: m.to, on: !!m.on, mode: m.mode || 'text' });
        break;
      }
      case 'signal': {
        // WebRTC signaling relay — server never exposes the peer's IP; clients may force TURN relay.
        if (!db.users[m.to] || (db.users[m.to].blocked || []).includes(me.id)) {
          if (m.data?.type === 'offer') ws.send({ t: 'signal', from: m.to, data: { type: 'unavailable', callId: m.data.callId } });
          return;
        }
        const ok = emit(m.to, { t: 'signal', from: me.id, data: m.data });
        if (!ok && m.data?.type === 'ring') ws.send({ t: 'signal', from: m.to, data: { type: 'offline', callId: m.data.callId } });
        break;
      }
      case 'call-join': {
        const room = String(m.room || '');
        if (!room) return;
        if (!callRooms.has(room)) callRooms.set(room, new Set());
        const members = callRooms.get(room);
        ws.send({ t: 'call-members', room, members: [...members] });
        for (const id of members) emit(id, { t: 'call-joined', room, user: me.id });
        members.add(me.id);
        break;
      }
      case 'call-leave': leaveRoom(me, String(m.room || '')); break;
      case 'ring-group': {
        const g = db.groups[m.group];
        if (!g || !g.members.includes(me.id)) return;
        for (const id of g.members) if (id !== me.id) emit(id, { t: 'group-ring', group: g.id, room: m.room, from: me.id, video: !!m.video });
        break;
      }
      case 'ping': ws.send({ t: 'pong', ts: now() }); break;
      default: break;
    }
  }

  const server = http.createServer(handle);
  attachWebSocket(server, '/ws', onSocket);
  const hb = setInterval(() => { for (const set of sockets.values()) for (const ws of set) ws.ping(); }, 25e3);
  hb.unref();
  server.on('close', () => { clearInterval(hb); clearInterval(pruneTimer); store.flush(); });
  return { server, store, db };
}

if (require.main === module) {
  const port = Number(process.env.PORT || 8080);
  const { server } = createServer();
  server.listen(port, () => console.log(`✦ Novalink By Natan berjalan di http://localhost:${port}`));
}

module.exports = { createServer };
