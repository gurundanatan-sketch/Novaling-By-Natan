// Run: node --test server/
'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { createServer } = require('./index');

function start() {
  const { server } = createServer({ persist: false });
  return new Promise((r) => server.listen(0, () => r({ server, base: `http://127.0.0.1:${server.address().port}` })));
}
const j = (base, p, body, token, method) => fetch(base + p, {
  method: method || (body ? 'POST' : 'GET'),
  headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
  body: body ? JSON.stringify(body) : undefined,
}).then(async (r) => ({ status: r.status, body: await r.json().catch(() => null) }));

function socket(base, token) {
  const ws = new WebSocket(base.replace('http', 'ws') + '/ws?token=' + token);
  const inbox = [];
  const waiters = [];
  ws.onmessage = (e) => {
    const m = JSON.parse(e.data); inbox.push(m);
    for (const w of [...waiters]) if (w.pred(m)) { waiters.splice(waiters.indexOf(w), 1); w.res(m); }
  };
  const next = (pred) => new Promise((res) => {
    const hit = inbox.find(pred); if (hit) return res(hit);
    waiters.push({ pred, res });
  });
  return new Promise((r) => { ws.onopen = () => r({ ws, next, send: (o) => ws.send(JSON.stringify(o)) }); });
}

test('register, chat, anti-delete, privacy', async () => {
  const { server, base } = await start();
  try {
    const a = await j(base, '/api/register', { username: 'natan', displayName: 'Natan', pin: '1234', phone: '+628123' });
    const b = await j(base, '/api/register', { username: 'sari', displayName: 'Sari', pin: '5678' });
    assert.equal(a.status, 201);
    assert.equal(b.status, 201);
    assert.equal((await j(base, '/api/register', { username: 'natan', pin: '1111' })).status, 409);
    assert.equal((await j(base, '/api/login', { username: 'natan', pin: '0000' })).status, 401);

    // search never leaks phone numbers
    const s = await j(base, '/api/users/search?q=sar', null, a.body.token);
    assert.equal(s.body[0].username, 'sari');
    assert.ok(!JSON.stringify(s.body).includes('phone'));
    // phone lookup does not find users who didn't opt in
    const ph = await j(base, '/api/users/by-phone', { phone: '+628123' }, b.body.token);
    assert.deepEqual(ph.body, []);

    await j(base, '/api/contacts', { username: 'sari' }, a.body.token);
    const A = await socket(base, a.body.token);
    const B = await socket(base, b.body.token);
    await A.next((m) => m.t === 'hello');
    await B.next((m) => m.t === 'hello');

    A.send({ t: 'msg', id: 'm1', to: b.body.user.id, text: 'Halo Sari 👋' });
    const got = await B.next((m) => m.t === 'msg');
    assert.equal(got.msg.text, 'Halo Sari 👋');
    const ack = await A.next((m) => m.t === 'ack');
    assert.equal(ack.status, 'delivered');

    A.send({ t: 'delete', id: 'm1' });
    const del = await B.next((m) => m.t === 'deleted');
    assert.equal(del.id, 'm1');
    const boot = await j(base, '/api/bootstrap', null, b.body.token);
    const kept = boot.body.messages.find((m) => m.id === 'm1');
    assert.equal(kept.deleted, true);
    assert.equal(kept.text, 'Halo Sari 👋'); // anti-delete: content retained

    B.send({ t: 'read', ids: ['m1'] });
    const st = await A.next((m) => m.t === 'status' && m.status === 'read');
    assert.deepEqual(st.ids, ['m1']);

    // call signaling relay
    A.send({ t: 'signal', to: b.body.user.id, data: { type: 'ring', callId: 'c1', video: false } });
    const ring = await B.next((m) => m.t === 'signal');
    assert.equal(ring.data.callId, 'c1');

    // group with many members + group call room
    const g = await j(base, '/api/groups', { name: 'Geng', members: [b.body.user.id] }, a.body.token);
    assert.equal(g.body.members.length, 2);
    A.send({ t: 'call-join', room: 'r1' });
    await A.next((m) => m.t === 'call-members');
    B.send({ t: 'call-join', room: 'r1' });
    const joined = await A.next((m) => m.t === 'call-joined');
    assert.equal(joined.user, b.body.user.id);

    // stories
    const story = await j(base, '/api/stories', { type: 'text', text: 'Story publik', audience: 'public' }, a.body.token);
    assert.equal(story.status, 201);
    const page = await fetch(base + '/s/natan').then((r) => r.text());
    assert.ok(page.includes('Story publik'));

    // AI fallback
    const ai = await j(base, '/api/ai/reply', { text: 'makasih ya' }, b.body.token);
    assert.equal(ai.body.replies.length, 3);

    A.ws.close(); B.ws.close();
  } finally {
    server.close();
  }
});

test('upload and ranged media', async () => {
  const { server, base } = await start();
  try {
    const a = await j(base, '/api/register', { username: 'uploader', pin: '1234' });
    const r = await fetch(base + '/api/upload', { method: 'POST', headers: { Authorization: 'Bearer ' + a.body.token, 'x-filename': 'tes.txt' }, body: 'hello world' });
    const up = await r.json();
    assert.equal(r.status, 201);
    const part = await fetch(base + up.url, { headers: { Range: 'bytes=0-4' } });
    assert.equal(part.status, 206);
    assert.equal(await part.text(), 'hello');
  } finally { server.close(); }
});
