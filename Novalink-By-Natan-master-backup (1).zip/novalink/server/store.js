// Tiny JSON-file persistence with debounced, atomic writes.
'use strict';
const fs = require('node:fs');
const path = require('node:path');

class Store {
  constructor(file) {
    this.file = file;
    this.timer = null;
    this.data = { users: {}, messages: [], groups: {}, stories: [], tokens: {} };
    if (file && fs.existsSync(file)) {
      try { Object.assign(this.data, JSON.parse(fs.readFileSync(file, 'utf8'))); } catch { /* fresh start */ }
    }
  }
  save() {
    if (!this.file) return;
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.flush(), 300);
  }
  flush() {
    if (!this.file) return;
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    const tmp = this.file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(this.data));
    fs.renameSync(tmp, this.file);
  }
}

module.exports = { Store };
