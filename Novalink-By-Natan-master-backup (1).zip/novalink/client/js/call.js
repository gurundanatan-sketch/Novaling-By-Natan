// Voice/video calls (1:1 and group). Mesh WebRTC for small groups, optional LiveKit SFU for 20+ people.
import { AudioPipeline, VOICE_EFFECTS } from './audiofx.js';
import { playRingtone, stopRingtone, dialTone } from './sounds.js';

const MESH_LIMIT = 8;
const rid = () => Math.random().toString(36).slice(2, 10);

export class Calls {
  constructor(app) {
    this.app = app;
    this.pcs = new Map();
    this.remoteStreams = new Map();
    this.active = null;
    this.el = document.getElementById('call');
  }

  get busy() { return !!this.active; }

  rtcConfig() {
    const ice = this.app.state.ice || { iceServers: [] };
    const hide = this.app.settings.hideIp;
    if (this.app.settings.airplane || this.active?.offline) return { iceServers: [] };
    return { iceServers: ice.iceServers, iceTransportPolicy: hide && ice.relayAvailable ? 'relay' : 'all', bundlePolicy: 'max-bundle' };
  }

  async getMedia(video) {
    const s = this.app.settings;
    const mic = await navigator.mediaDevices.getUserMedia({
      audio: { noiseSuppression: s.noiseSuppression !== false, echoCancellation: true, autoGainControl: true, channelCount: 1 },
      video: video ? { facingMode: this.facing || 'user', width: { ideal: 1280 }, height: { ideal: 720 } } : false,
    });
    this.pipeline = await new AudioPipeline(new MediaStream(mic.getAudioTracks()), { noiseSuppression: s.noiseSuppression !== false }).init();
    if (s.voiceEffect && s.voiceEffect !== 'normal') this.pipeline.setEffect(s.voiceEffect);
    this.videoTrack = mic.getVideoTracks()[0] || null;
    this.local = new MediaStream([this.pipeline.track, ...(this.videoTrack ? [this.videoTrack] : [])]);
    return this.local;
  }

  // ---------------- outgoing ----------------
  async start(peerId, video = false) {
    if (this.busy) return this.app.toast('Kamu sedang dalam panggilan');
    if (this.app.settings.airplane) return this.app.toast('Mode pesawat aktif ✈️ — matikan dulu untuk menelepon');
    const room = 'c:' + rid();
    this.active = { room, callId: room, peer: peerId, video, status: 'calling', dir: 'out', startedAt: Date.now() };
    try { await this.getMedia(video); } catch (e) { this.active = null; return this.app.toast('Izin mikrofon/kamera ditolak'); }
    this.render();
    this.stopDial = dialTone();
    this.app.send({ t: 'signal', to: peerId, data: { type: 'ring', room, callId: room, video } });
    this.app.send({ t: 'call-join', room });
    this.timeout = setTimeout(() => { if (this.active?.status === 'calling') { this.app.send({ t: 'signal', to: peerId, data: { type: 'cancel', callId: room } }); this.finish('Tidak dijawab', 'missed-out'); } }, 45000);
  }

  async startGroup(groupId, video = false) {
    if (this.busy) return;
    if (this.app.settings.airplane) return this.app.toast('Mode pesawat aktif ✈️');
    const g = this.app.state.groups[groupId];
    const room = 'g:' + groupId + ':' + rid();
    const useSfu = this.app.state.livekit && (g.members.length > MESH_LIMIT || this.app.settings.preferSfu);
    this.active = { room, callId: room, group: groupId, video, status: 'connected', dir: 'out', startedAt: Date.now(), sfu: useSfu };
    try { await this.getMedia(video); } catch { this.active = null; return this.app.toast('Izin mikrofon/kamera ditolak'); }
    this.app.send({ t: 'ring-group', group: groupId, room, video });
    if (useSfu) await this.joinSfu(room); else this.app.send({ t: 'call-join', room });
    if (!useSfu && g.members.length > MESH_LIMIT) this.app.toast(`Grup besar (${g.members.length} orang): aktifkan server SFU agar lancar untuk 20+ peserta`);
    this.render();
  }

  // ---------------- incoming ----------------
  onSignal(from, d) {
    const a = this.active;
    switch (d.type) {
      case 'ring':
        if (a) { this.app.send({ t: 'signal', to: from, data: { type: 'busy', callId: d.callId } }); this.app.addCallLog({ peer: from, dir: 'in', status: 'missed', video: d.video }); return; }
        if (this.app.settings.airplane || this.app.isBlocked(from)) return;
        this.active = { room: d.room, callId: d.callId, peer: from, video: d.video, status: 'ringing', dir: 'in', startedAt: Date.now() };
        playRingtone(this.app.settings.ringtone, this.app.settings.customRingtone);
        this.render();
        this.app.notify(`${d.video ? '📹 Video call' : '📞 Panggilan'} masuk`, this.app.userName(from), { call: true });
        this.app.assistant.announceCall(from, d.video);
        this.ringTimeout = setTimeout(() => { if (this.active?.status === 'ringing') this.finish('Panggilan tak terjawab', 'missed'); }, 45000);
        break;
      case 'accept':
        if (a && a.callId === d.callId) { a.status = 'connecting'; this.stopDial?.(); this.render(); }
        break;
      case 'decline': case 'busy': case 'offline': case 'unavailable': case 'cancel':
        if (a && a.callId === d.callId) {
          const msg = { decline: 'Panggilan ditolak', busy: 'Sedang sibuk di panggilan lain', offline: 'Pengguna sedang offline', unavailable: 'Tidak tersedia', cancel: 'Panggilan dibatalkan' }[d.type];
          this.finish(msg, d.type === 'cancel' ? 'missed' : 'declined', d.type === 'offline' ? from : null);
        }
        break;
      case 'offer': this.handleOffer(from, d); break;
      case 'answer': this.pcs.get(from)?.setRemoteDescription({ type: 'answer', sdp: d.sdp }).catch(() => {}); break;
      case 'ice': if (d.candidate) this.pcs.get(from)?.addIceCandidate(d.candidate).catch(() => {}); break;
      case 'end': if (a && a.callId === d.callId && !a.group) this.finish('Panggilan berakhir', 'done'); break;
      default: break;
    }
  }

  onGroupRing(m) {
    if (this.active || this.app.settings.airplane) return;
    this.active = { room: m.room, callId: m.room, group: m.group, caller: m.from, video: m.video, status: 'ringing', dir: 'in', startedAt: Date.now() };
    playRingtone(this.app.settings.ringtone, this.app.settings.customRingtone);
    this.render();
    this.app.assistant.announceCall(m.from, m.video, this.app.state.groups[m.group]?.name);
  }

  onRoom(m) {
    const a = this.active;
    if (!a || a.room !== m.room) return;
    if (m.t === 'call-members') for (const id of m.members) if (id !== this.app.state.me.id) this.connectTo(id);
    if (m.t === 'call-joined') { a.status = 'connected'; a.connectedAt ||= Date.now(); this.render(); }
    if (m.t === 'call-left') {
      this.closePeer(m.user);
      if (!a.group) this.finish('Panggilan berakhir', 'done'); else this.render();
    }
  }

  async accept() {
    const a = this.active;
    if (!a || a.status !== 'ringing') return;
    stopRingtone(); clearTimeout(this.ringTimeout);
    a.status = 'connecting';
    this.render();
    try { await this.getMedia(a.video); } catch { this.app.toast('Izin mikrofon ditolak'); return this.decline(); }
    if (a.peer) this.app.send({ t: 'signal', to: a.peer, data: { type: 'accept', callId: a.callId } });
    if (a.group && this.app.state.livekit && (this.app.state.groups[a.group]?.members.length > MESH_LIMIT || this.app.settings.preferSfu)) {
      a.sfu = true; await this.joinSfu(a.room);
    } else this.app.send({ t: 'call-join', room: a.room });
    a.status = 'connected'; a.connectedAt = Date.now();
    this.render();
  }

  decline(reply) {
    const a = this.active;
    if (!a) return;
    if (a.peer) this.app.send({ t: 'signal', to: a.peer, data: { type: 'decline', callId: a.callId } });
    if (reply && a.peer) this.app.sendText(a.peer, reply);
    this.finish('Panggilan ditolak', 'declined');
  }

  hangup() {
    const a = this.active;
    if (!a) return;
    if (a.peer) this.app.send({ t: 'signal', to: a.peer, data: { type: a.status === 'calling' ? 'cancel' : 'end', callId: a.callId } });
    this.finish('Panggilan berakhir', a.status === 'calling' ? 'cancelled' : 'done');
  }

  finish(text, status, offlinePeer) {
    const a = this.active;
    if (!a) return;
    stopRingtone(); this.stopDial?.(); clearTimeout(this.timeout); clearTimeout(this.ringTimeout); clearInterval(this.tick);
    this.app.send({ t: 'call-leave', room: a.room });
    for (const id of [...this.pcs.keys()]) this.closePeer(id);
    this.lk?.disconnect(); this.lk = null;
    this.pipeline?.destroy(); this.pipeline = null;
    this.videoTrack?.stop(); this.screenTrack?.stop();
    const dur = a.connectedAt ? Math.round((Date.now() - a.connectedAt) / 1000) : 0;
    this.app.addCallLog({ peer: a.peer || a.caller, group: a.group, dir: a.dir, status: status === 'done' && !dur ? (a.dir === 'in' ? 'missed' : 'cancelled') : status, video: a.video, dur });
    this.active = null;
    this.el.classList.remove('open');
    this.el.innerHTML = '';
    this.app.toast(text + (dur ? ` · ${fmt(dur)}` : ''));
    if (offlinePeer) this.app.offerWhatsAppFallback(offlinePeer, a.video);
    this.app.assistant.stopListening();
  }

  // ---------------- WebRTC mesh ----------------
  makePeer(id) {
    const pc = new RTCPeerConnection(this.rtcConfig());
    this.pcs.set(id, pc);
    for (const t of this.local.getTracks()) pc.addTrack(t, this.local);
    pc.onicecandidate = (e) => { if (e.candidate) this.app.send({ t: 'signal', to: id, data: { type: 'ice', candidate: e.candidate, room: this.active?.room } }); };
    pc.ontrack = (e) => { this.remoteStreams.set(id, e.streams[0] || new MediaStream([e.track])); this.render(); };
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'connected' && this.active) { this.active.status = 'connected'; this.active.connectedAt ||= Date.now(); this.stopDial?.(); this.render(); }
      if (pc.connectionState === 'failed') pc.restartIce?.();
    };
    return pc;
  }

  async connectTo(id) {
    if (this.pcs.has(id) || !this.local) return;
    const pc = this.makePeer(id);
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    this.app.send({ t: 'signal', to: id, data: { type: 'offer', sdp: offer.sdp, room: this.active.room, callId: this.active.callId } });
  }

  async handleOffer(from, d) {
    if (!this.active || d.room !== this.active.room || !this.local) return;
    let pc = this.pcs.get(from);
    if (!pc) pc = this.makePeer(from);
    await pc.setRemoteDescription({ type: 'offer', sdp: d.sdp });
    const ans = await pc.createAnswer();
    await pc.setLocalDescription(ans);
    this.app.send({ t: 'signal', to: from, data: { type: 'answer', sdp: ans.sdp, room: d.room } });
  }

  closePeer(id) {
    this.pcs.get(id)?.close();
    this.pcs.delete(id);
    this.remoteStreams.delete(id);
  }

  // ---------------- SFU (LiveKit) for 20+ participants ----------------
  async joinSfu(room) {
    try {
      const cfg = await this.app.api('/api/livekit?room=' + encodeURIComponent(room));
      const LK = await import('https://cdn.jsdelivr.net/npm/livekit-client@2/+esm');
      const r = new LK.Room({ adaptiveStream: true, dynacast: true });
      this.lk = r;
      r.on(LK.RoomEvent.TrackSubscribed, (track, _pub, p) => {
        const s = this.remoteStreams.get(p.identity) || new MediaStream();
        s.addTrack(track.mediaStreamTrack); this.remoteStreams.set(p.identity, s); this.render();
      });
      r.on(LK.RoomEvent.ParticipantDisconnected, (p) => { this.remoteStreams.delete(p.identity); this.render(); });
      await r.connect(cfg.url, cfg.token);
      for (const t of this.local.getTracks()) await r.localParticipant.publishTrack(t);
    } catch (e) {
      this.app.toast('SFU tidak tersedia, beralih ke mode mesh');
      this.active.sfu = false;
      this.app.send({ t: 'call-join', room });
    }
  }

  // ---------------- controls ----------------
  toggleMute() { this.muted = !this.muted; this.pipeline?.setMuted(this.muted); this.render(); }
  toggleVideo() { if (this.videoTrack) { this.videoTrack.enabled = !this.videoTrack.enabled; this.render(); } }
  async switchCamera() {
    if (!this.videoTrack) return;
    this.facing = this.facing === 'environment' ? 'user' : 'environment';
    const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: this.facing } });
    const nt = s.getVideoTracks()[0];
    for (const pc of this.pcs.values()) pc.getSenders().find((x) => x.track?.kind === 'video')?.replaceTrack(nt);
    this.local.removeTrack(this.videoTrack); this.videoTrack.stop(); this.videoTrack = nt; this.local.addTrack(nt);
    this.render();
  }
  async shareScreen() {
    try {
      const s = await navigator.mediaDevices.getDisplayMedia({ video: true });
      const t = s.getVideoTracks()[0];
      this.screenTrack = t;
      for (const pc of this.pcs.values()) {
        const snd = pc.getSenders().find((x) => x.track?.kind === 'video');
        if (snd) snd.replaceTrack(t); else pc.addTrack(t, this.local);
      }
      t.onended = () => { for (const pc of this.pcs.values()) pc.getSenders().find((x) => x.track === t)?.replaceTrack(this.videoTrack || null); };
      this.app.toast('Berbagi layar aktif');
    } catch { /* cancelled */ }
  }
  setNoise(on) { this.app.settings.noiseSuppression = on; this.app.saveSettings(); this.pipeline?.setNoiseSuppression(on); this.render(); }
  setEffect(e) { this.app.settings.voiceEffect = e; this.app.saveSettings(); this.pipeline?.setEffect(e); this.render(); }
  pickMusic() {
    const inp = Object.assign(document.createElement('input'), { type: 'file', accept: 'audio/*,video/*' });
    inp.onchange = () => { const f = inp.files[0]; if (f) { this.pipeline?.playMusic(f); this.musicName = f.name; this.musicPlaying = true; this.render(); } };
    inp.click();
  }

  // ---------------- UI ----------------
  render() {
    const a = this.active;
    if (!a) return;
    const app = this.app;
    const title = a.group ? (app.state.groups[a.group]?.name || 'Grup') : app.userName(a.peer);
    const statusText = { calling: 'Memanggil…', ringing: a.dir === 'in' ? (a.video ? 'Video call masuk' : 'Panggilan masuk') : 'Berdering…', connecting: 'Menghubungkan…', connected: '' }[a.status];
    const remotes = [...this.remoteStreams.entries()];
    const hideIp = app.settings.hideIp;
    const relayOn = hideIp && app.state.ice?.relayAvailable;
    this.el.classList.add('open');
    this.el.classList.toggle('video', !!a.video);
    if (a.status === 'ringing' && a.dir === 'in') {
      this.el.innerHTML = `
        <div class="call-bg"></div>
        <div class="call-center">
          ${app.avatarHtml(a.group ? { displayName: title } : app.state.users[a.peer], 'xl pulse')}
          <h2>${app.esc(title)}</h2><p class="muted">${statusText}${a.group ? ' · dari ' + app.esc(app.userName(a.caller)) : ''}</p>
          <p class="chip glass">🎙️ Katakan <b>"angkat"</b> atau <b>"tolak"</b></p>
        </div>
        <div class="quick-replies">
          ${['Lagi sibuk, nanti aku telepon balik', 'Lagi di jalan 🚗', 'Chat aja dulu ya'].map((r) => `<button class="chip" data-call="reply" data-text="${app.esc(r)}">${r}</button>`).join('')}
        </div>
        <div class="call-actions ring">
          <button class="round red" data-call="decline" aria-label="Tolak">${icon('end')}</button>
          <button class="round green big" data-call="accept" aria-label="Angkat">${icon(a.video ? 'video' : 'phone')}</button>
        </div>`;
    } else {
      const tiles = remotes.map(([id, st]) => { const hasVid = st.getVideoTracks().some((t) => t.readyState === 'live' && !t.muted); return `<div class="tile ${hasVid ? '' : 'audio-only'}" data-id="${id}"><video autoplay playsinline></video>${hasVid ? '' : app.avatarHtml(app.state.users[id])}<span class="tag">${app.esc(app.userName(id))}</span></div>`; }).join('');
      const count = remotes.length + 1;
      this.el.innerHTML = `
        <div class="call-bg"></div>
        <div class="call-top">
          <div><h3>${app.esc(title)}</h3><p class="muted"><span id="call-timer">${statusText || fmt(0)}</span> · ${count} peserta ${a.sfu ? '· SFU' : ''}</p></div>
          <span class="chip ${relayOn ? 'ok' : ''}" title="Perlindungan IP">${relayOn ? '🛡️ IP tersembunyi' : hideIp ? '🛡️ IP terlindung (mDNS)' : '🌐 P2P langsung'}</span>
        </div>
        <div class="grid g${Math.min(count, 9)}">
          ${a.video || remotes.length > 1 ? `<div class="tile me"><video autoplay playsinline muted></video><span class="tag">Kamu</span></div>` : ''}
          ${tiles || (!a.video ? `<div class="call-center">${app.avatarHtml(a.group ? { displayName: title } : app.state.users[a.peer], 'xl ' + (a.status === 'connected' ? '' : 'pulse'))}<h2>${app.esc(title)}</h2></div>` : '')}
        </div>
        <div class="call-tools glass">
          <label>🎚️ Peredam bising <input type="checkbox" data-call="noise" ${app.settings.noiseSuppression !== false ? 'checked' : ''}></label>
          <label>🎭 <select data-call="fx">${Object.entries(VOICE_EFFECTS).map(([k, v]) => `<option value="${k}" ${app.settings.voiceEffect === k ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
          <div class="music">
            <button class="chip" data-call="music">🎵 ${this.musicName ? app.esc(this.musicName.slice(0, 18)) : 'Putar musik'}</button>
            ${this.musicName ? `<button class="chip" data-call="music-toggle">${this.musicPlaying ? '⏸' : '▶️'}</button>
            <label>Vol <input type="range" min="0" max="1" step="0.05" value="${this.pipeline?.musicGain.gain.value ?? 0.5}" data-call="music-vol"></label>
            <button class="chip ${this.pipeline?.karaoke ? 'ok' : ''}" data-call="karaoke">🎤 Karaoke</button>` : ''}
          </div>
        </div>
        <div class="call-actions">
          <button class="round ${this.muted ? 'on' : ''}" data-call="mute" aria-label="Bisukan">${icon(this.muted ? 'micoff' : 'mic')}</button>
          ${a.video ? `<button class="round" data-call="cam" aria-label="Kamera">${icon('video')}</button><button class="round" data-call="flip" aria-label="Ganti kamera">${icon('flip')}</button>` : ''}
          <button class="round" data-call="screen" aria-label="Bagikan layar">${icon('screen')}</button>
          <button class="round red" data-call="hangup" aria-label="Akhiri">${icon('end')}</button>
        </div>`;
      const me = this.el.querySelector('.tile.me video');
      if (me) me.srcObject = new MediaStream(this.videoTrack ? [this.videoTrack] : []);
      for (const [id, s] of remotes) {
        const v = this.el.querySelector(`.tile[data-id="${CSS.escape(id)}"] video`);
        if (v) v.srcObject = s;
      }
      if (!remotes.length && this.remoteAudio) this.remoteAudio.srcObject = null;
      clearInterval(this.tick);
      if (a.status === 'connected') this.tick = setInterval(() => { const t = this.el.querySelector('#call-timer'); if (t && this.active?.connectedAt) t.textContent = fmt(Math.round((Date.now() - this.active.connectedAt) / 1000)); }, 1000);
    }
    this.bind();
  }

  bind() {
    this.el.onclick = (e) => {
      const b = e.target.closest('[data-call]');
      if (!b) return;
      const act = b.dataset.call;
      if (act === 'accept') this.accept();
      else if (act === 'decline') this.decline();
      else if (act === 'reply') this.decline(b.dataset.text);
      else if (act === 'hangup') this.hangup();
      else if (act === 'mute') this.toggleMute();
      else if (act === 'cam') this.toggleVideo();
      else if (act === 'flip') this.switchCamera();
      else if (act === 'screen') this.shareScreen();
      else if (act === 'music') this.pickMusic();
      else if (act === 'music-toggle') { this.musicPlaying = this.pipeline?.toggleMusic(); this.render(); }
      else if (act === 'karaoke') { this.pipeline?.setKaraoke(!this.pipeline.karaoke); this.render(); }
    };
    this.el.onchange = (e) => {
      const b = e.target.closest('[data-call]');
      if (!b) return;
      if (b.dataset.call === 'noise') this.setNoise(b.checked);
      if (b.dataset.call === 'fx') this.setEffect(b.value);
    };
    this.el.oninput = (e) => { if (e.target.dataset.call === 'music-vol') this.pipeline?.setMusicVolume(Number(e.target.value)); };
  }
}

export function fmt(s) { const m = Math.floor(s / 60), r = s % 60; return `${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}`; }

export function icon(name) {
  const P = {
    phone: 'M6.6 10.8a15.1 15.1 0 006.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 013 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1z',
    video: 'M17 10.5V7a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h12a1 1 0 001-1v-3.5l4 4v-11z',
    end: 'M12 9c-1.6 0-3.2.3-4.6.7v3.1c0 .4-.2.7-.6.9-1 .5-1.9 1.1-2.7 1.8-.2.2-.4.3-.7.3s-.5-.1-.7-.3L.3 13.1A1 1 0 010 12.4c0-.3.1-.5.3-.7A16.9 16.9 0 0112 7c4.6 0 8.7 1.8 11.7 4.7.2.2.3.4.3.7s-.1.5-.3.7l-2.5 2.4c-.2.2-.4.3-.7.3s-.5-.1-.7-.3a11 11 0 00-2.7-1.8.9.9 0 01-.6-.9V9.7C15.2 9.3 13.6 9 12 9z',
    mic: 'M12 14a3 3 0 003-3V5a3 3 0 10-6 0v6a3 3 0 003 3zm5-3a5 5 0 01-10 0H5a7 7 0 006 6.9V21h2v-3.1A7 7 0 0019 11z',
    micoff: 'M19 11h-2c0 .7-.2 1.4-.4 2l1.5 1.5c.6-1 .9-2.2.9-3.5zm-4 .2V5a3 3 0 00-6-.2zM4.3 3L3 4.3l6 6V11a3 3 0 004.5 2.6l1.6 1.6A5 5 0 017 11H5a7 7 0 006 6.9V21h2v-3.1c.9-.1 1.8-.4 2.6-.9l4.1 4.1 1.3-1.3z',
    flip: 'M20 5h-3.2L15 3H9L7.2 5H4a2 2 0 00-2 2v12c0 1.1.9 2 2 2h16a2 2 0 002-2V7a2 2 0 00-2-2zm-5 11.5V14H9v2.5L5.5 13 9 9.5V12h6V9.5l3.5 3.5z',
    screen: 'M20 18a2 2 0 002-2V6a2 2 0 00-2-2H4a2 2 0 00-2 2v10c0 1.1.9 2 2 2H0v2h24v-2zM4 6h16v10H4z',
  };
  return `<svg viewBox="0 0 24 24" width="26" height="26" fill="currentColor"><path d="${P[name] || ''}"/></svg>`;
}
