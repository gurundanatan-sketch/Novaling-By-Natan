// Audio pipeline for calls: noise suppression, voice changer, and music/karaoke mixing on one phone.
import { audioContext } from './sounds.js';

const WORKLET = `
class NoiseGate extends AudioWorkletProcessor {
  static get parameterDescriptors() { return [{ name: 'threshold', defaultValue: 0.012 }, { name: 'enabled', defaultValue: 1 }]; }
  constructor() { super(); this.env = 0; this.gain = 1; this.noiseFloor = 0.005; }
  process(inputs, outputs, p) {
    const i = inputs[0][0], o = outputs[0][0];
    if (!i) return true;
    const on = p.enabled[0] > 0.5;
    let sum = 0; for (let k = 0; k < i.length; k++) sum += i[k] * i[k];
    const rms = Math.sqrt(sum / i.length);
    // adaptive noise floor tracking
    this.noiseFloor = rms < this.noiseFloor * 2 ? this.noiseFloor * 0.995 + rms * 0.005 : this.noiseFloor * 1.0005;
    const th = Math.max(p.threshold[0], this.noiseFloor * 2.5);
    const target = !on || rms > th ? 1 : 0.04;
    for (let k = 0; k < i.length; k++) {
      this.gain += (target - this.gain) * (target > this.gain ? 0.02 : 0.0015);
      o[k] = i[k] * this.gain;
    }
    for (let c = 1; c < outputs[0].length; c++) outputs[0][c].set(o);
    return true;
  }
}
class PitchShifter extends AudioWorkletProcessor {
  static get parameterDescriptors() { return [{ name: 'pitch', defaultValue: 1 }]; }
  constructor() { super(); this.size = 2048; this.buf = new Float32Array(this.size); this.w = 0; this.r = 0; }
  process(inputs, outputs, p) {
    const i = inputs[0][0], o = outputs[0][0];
    if (!i) return true;
    const pitch = p.pitch[0], N = this.size, win = N / 2;
    for (let k = 0; k < i.length; k++) {
      this.buf[this.w] = i[k];
      if (pitch === 1) { o[k] = i[k]; }
      else {
        // two-tap delay-line pitch shift with crossfade
        const d1 = (this.w - this.r + N) % N;
        const r2 = (this.r + win) % N;
        const d2 = (this.w - r2 + N) % N;
        const g1 = Math.sin(Math.PI * d1 / N) ** 2, g2 = Math.sin(Math.PI * d2 / N) ** 2;
        const s = (pos) => { const a = Math.floor(pos), f = pos - a; return this.buf[a % N] * (1 - f) + this.buf[(a + 1) % N] * f; };
        o[k] = s(this.r) * g1 + s(r2) * g2;
        this.r = (this.r + pitch) % N;
      }
      this.w = (this.w + 1) % N;
    }
    for (let c = 1; c < outputs[0].length; c++) outputs[0][c].set(o);
    return true;
  }
}
registerProcessor('nl-noise-gate', NoiseGate);
registerProcessor('nl-pitch', PitchShifter);
`;

export const VOICE_EFFECTS = {
  normal: 'Normal', chipmunk: 'Chipmunk 🐿️', deep: 'Suara Berat 🗿', robot: 'Robot 🤖', alien: 'Alien 👽',
  cave: 'Gua / Gema 🏔️', radio: 'Radio HT 📻', child: 'Anak Kecil 🧒', monster: 'Monster 👹',
};

let workletReady = null;
function loadWorklet(ctx) {
  if (!workletReady) {
    const url = URL.createObjectURL(new Blob([WORKLET], { type: 'text/javascript' }));
    workletReady = ctx.audioWorklet ? ctx.audioWorklet.addModule(url).then(() => true).catch(() => false) : Promise.resolve(false);
  }
  return workletReady;
}

function impulse(ctx, seconds = 2.2, decay = 2.5) {
  const len = ctx.sampleRate * seconds;
  const b = ctx.createBuffer(2, len, ctx.sampleRate);
  for (let c = 0; c < 2; c++) {
    const d = b.getChannelData(c);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay);
  }
  return b;
}

/**
 * Build the outgoing audio graph:
 * mic -> highpass -> noiseGate -> [voice fx] -> micGain --\
 *                                                          +-> dest (sent to peers)
 * music <audio> -> musicGain ------------------------------/  (+ local monitor)
 * karaoke: mic -> reverb -> dest
 */
export class AudioPipeline {
  constructor(micStream, opts = {}) {
    this.ctx = audioContext();
    this.mic = micStream;
    this.opts = opts;
    this.effect = 'normal';
  }

  async init() {
    const ctx = this.ctx;
    if (ctx.state === 'suspended') await ctx.resume().catch(() => {});
    this.hasWorklet = await loadWorklet(ctx);
    this.src = ctx.createMediaStreamSource(this.mic);
    this.hp = ctx.createBiquadFilter(); this.hp.type = 'highpass'; this.hp.frequency.value = 85;
    this.lp = ctx.createBiquadFilter(); this.lp.type = 'lowpass'; this.lp.frequency.value = 12000;
    this.gate = this.hasWorklet ? new AudioWorkletNode(ctx, 'nl-noise-gate') : ctx.createGain();
    this.fxIn = ctx.createGain();
    this.fxOut = ctx.createGain();
    this.micGain = ctx.createGain();
    this.dest = ctx.createMediaStreamDestination();
    this.musicGain = ctx.createGain(); this.musicGain.gain.value = 0.5;
    this.monitor = ctx.createGain(); this.monitor.gain.value = 0.8;
    this.reverb = ctx.createConvolver(); this.reverb.buffer = impulse(ctx);
    this.reverbGain = ctx.createGain(); this.reverbGain.gain.value = 0;
    this.src.connect(this.hp).connect(this.lp).connect(this.gate).connect(this.fxIn);
    this.fxOut.connect(this.micGain).connect(this.dest);
    this.micGain.connect(this.reverb).connect(this.reverbGain).connect(this.dest);
    this.musicGain.connect(this.dest);
    this.musicGain.connect(this.monitor).connect(ctx.destination);
    this.setEffect('normal');
    this.setNoiseSuppression(this.opts.noiseSuppression !== false);
    return this;
  }

  get track() { return this.dest.stream.getAudioTracks()[0]; }

  setNoiseSuppression(on) {
    this.nsOn = on;
    if (this.gate.parameters) this.gate.parameters.get('enabled').value = on ? 1 : 0;
    this.lp.frequency.value = on ? 7500 : 16000;
    for (const t of this.mic.getAudioTracks()) t.applyConstraints?.({ noiseSuppression: on, echoCancellation: true, autoGainControl: true }).catch(() => {});
  }

  setMuted(m) { this.micGain.gain.value = m ? 0 : 1; }

  setEffect(name) {
    const ctx = this.ctx;
    this.effect = name;
    try { this.fxIn.disconnect(); } catch { /* */ }
    for (const n of this.fxNodes || []) try { n.disconnect(); n.stop?.(); } catch { /* */ }
    this.fxNodes = [];
    const chain = (...nodes) => { let prev = this.fxIn; for (const n of nodes) { prev.connect(n); prev = n; } prev.connect(this.fxOut); this.fxNodes.push(...nodes); };
    const pitch = (v) => {
      if (!this.hasWorklet) return ctx.createGain();
      const n = new AudioWorkletNode(ctx, 'nl-pitch'); n.parameters.get('pitch').value = v; return n;
    };
    const ringMod = (freq) => {
      const g = ctx.createGain(); g.gain.value = 0;
      const o = ctx.createOscillator(); o.frequency.value = freq; o.connect(g.gain); o.start();
      this.fxNodes.push(o); return g;
    };
    const bp = (f, q = 1) => { const b = ctx.createBiquadFilter(); b.type = 'bandpass'; b.frequency.value = f; b.Q.value = q; return b; };
    const delay = (t, fb) => {
      const d = ctx.createDelay(1); d.delayTime.value = t; const g = ctx.createGain(); g.gain.value = fb;
      d.connect(g).connect(d); const mix = ctx.createGain(); this.fxIn.connect(mix); d.connect(mix);
      this.fxNodes.push(g); return [d, mix];
    };
    const distort = (k) => {
      const s = ctx.createWaveShaper(); const c = new Float32Array(1024);
      for (let i = 0; i < 1024; i++) { const x = i / 512 - 1; c[i] = ((1 + k) * x) / (1 + k * Math.abs(x)); }
      s.curve = c; return s;
    };
    switch (name) {
      case 'chipmunk': chain(pitch(1.7)); break;
      case 'child': chain(pitch(1.35), bp(2000, 0.4)); break;
      case 'deep': chain(pitch(0.72)); break;
      case 'monster': chain(pitch(0.55), distort(8)); break;
      case 'robot': chain(ringMod(50)); break;
      case 'alien': chain(pitch(1.25), ringMod(30)); break;
      case 'radio': chain(bp(1800, 1.2), distort(25)); break;
      case 'cave': { const [d, mix] = delay(0.28, 0.45); this.fxIn.connect(d); mix.connect(this.fxOut); this.fxNodes.push(d, mix); break; }
      default: this.fxIn.connect(this.fxOut);
    }
  }

  /** Play a song from the gallery into the call (everyone hears it) — karaoke-ready. */
  playMusic(fileOrUrl) {
    this.stopMusic();
    const el = new Audio();
    el.src = typeof fileOrUrl === 'string' ? fileOrUrl : URL.createObjectURL(fileOrUrl);
    el.crossOrigin = 'anonymous';
    el.loop = true;
    this.musicEl = el;
    this.musicNode = this.ctx.createMediaElementSource(el);
    this.musicNode.connect(this.musicGain);
    return el.play();
  }
  toggleMusic() { if (!this.musicEl) return false; if (this.musicEl.paused) this.musicEl.play(); else this.musicEl.pause(); return !this.musicEl.paused; }
  stopMusic() { if (this.musicEl) { this.musicEl.pause(); try { this.musicNode.disconnect(); } catch { /* */ } this.musicEl = null; } }
  setMusicVolume(v) { this.musicGain.gain.value = v; }
  setMonitor(v) { this.monitor.gain.value = v; }
  setKaraoke(on) { this.reverbGain.gain.value = on ? 0.35 : 0; this.karaoke = on; }

  /** Mic level 0..1 for UI meters. */
  level() {
    if (!this.analyser) { this.analyser = this.ctx.createAnalyser(); this.analyser.fftSize = 256; this.fxOut.connect(this.analyser); this.levelBuf = new Uint8Array(128); }
    this.analyser.getByteTimeDomainData(this.levelBuf);
    let m = 0; for (const v of this.levelBuf) m = Math.max(m, Math.abs(v - 128));
    return m / 128;
  }

  destroy() {
    this.stopMusic();
    try { this.src.disconnect(); this.musicGain.disconnect(); this.monitor.disconnect(); } catch { /* */ }
    for (const n of this.fxNodes || []) try { n.stop?.(); } catch { /* */ }
    this.mic.getTracks().forEach((t) => t.stop());
  }
}
