// Offline mode: direct device-to-device chat & voice call without internet or server.
// Both phones join the same Wi-Fi / hotspot (no internet needed); they exchange a one-time
// pairing code (copy, Nearby Share, Bluetooth share, or QR scan) and talk over WebRTC host candidates.
import { AudioPipeline } from './audiofx.js';

async function pack(obj) {
  const data = new TextEncoder().encode(JSON.stringify(obj));
  if (!window.CompressionStream) return 'NL0.' + btoa(String.fromCharCode(...data));
  const s = new Blob([data]).stream().pipeThrough(new CompressionStream('deflate-raw'));
  const buf = new Uint8Array(await new Response(s).arrayBuffer());
  let bin = ''; for (const b of buf) bin += String.fromCharCode(b);
  return 'NL1.' + btoa(bin);
}
async function unpack(code) {
  code = code.trim();
  const [v, b64] = [code.slice(0, 3), code.slice(4)];
  const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
  if (v === 'NL0') return JSON.parse(new TextDecoder().decode(bytes));
  const s = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  return JSON.parse(await new Response(s).text());
}
function gathered(pc) {
  return new Promise((res) => {
    if (pc.iceGatheringState === 'complete') return res();
    const t = setTimeout(res, 4000);
    pc.addEventListener('icegatheringstatechange', () => { if (pc.iceGatheringState === 'complete') { clearTimeout(t); res(); } });
  });
}

export class OfflineLink {
  constructor(app) {
    this.app = app;
    this.log = [];
    this.pc = null;
    this.dc = null;
    this.peerName = 'Perangkat terdekat';
  }

  newPc() {
    this.close();
    const pc = new RTCPeerConnection({ iceServers: [] }); // no STUN/TURN: works on LAN without internet
    pc.ontrack = (e) => { const a = this.audioEl ||= new Audio(); a.autoplay = true; a.srcObject = e.streams[0]; a.play().catch(() => {}); };
    pc.onconnectionstatechange = () => this.render();
    pc.ondatachannel = (e) => this.bindDc(e.channel);
    this.pc = pc;
    return pc;
  }

  bindDc(dc) {
    this.dc = dc;
    dc.onopen = () => { dc.send(JSON.stringify({ t: 'hi', name: this.app.state.me?.displayName || 'Teman' })); this.render(); this.app.toast('📡 Terhubung offline!'); };
    dc.onclose = () => this.render();
    dc.onmessage = async (e) => {
      const m = JSON.parse(e.data);
      if (m.t === 'hi') this.peerName = m.name;
      if (m.t === 'msg') { this.log.push({ me: false, text: m.text, ts: Date.now() }); this.app.playMessageSound(); }
      if (m.t === 'sdp') {
        await this.pc.setRemoteDescription(m.sdp);
        if (m.sdp.type === 'offer') {
          if (!this.mic) await this.startMic();
          const a = await this.pc.createAnswer(); await this.pc.setLocalDescription(a);
          dc.send(JSON.stringify({ t: 'sdp', sdp: this.pc.localDescription }));
        }
      }
      if (m.t === 'hangup') this.stopMic();
      this.render();
    };
  }

  async createInvite() {
    const pc = this.newPc();
    this.bindDc(pc.createDataChannel('novalink', { ordered: true }));
    await pc.setLocalDescription(await pc.createOffer());
    await gathered(pc);
    return pack({ sdp: pc.localDescription, n: this.app.state.me?.displayName });
  }

  async acceptInvite(code) {
    const { sdp, n } = await unpack(code);
    this.peerName = n || this.peerName;
    const pc = this.newPc();
    await pc.setRemoteDescription(sdp);
    await pc.setLocalDescription(await pc.createAnswer());
    await gathered(pc);
    return pack({ sdp: pc.localDescription, n: this.app.state.me?.displayName });
  }

  async finish(code) {
    const { sdp, n } = await unpack(code);
    this.peerName = n || this.peerName;
    await this.pc.setRemoteDescription(sdp);
  }

  send(text) {
    if (!this.dc || this.dc.readyState !== 'open' || !text.trim()) return;
    this.dc.send(JSON.stringify({ t: 'msg', text }));
    this.log.push({ me: true, text, ts: Date.now() });
    this.render();
  }

  async startMic() {
    const s = await navigator.mediaDevices.getUserMedia({ audio: { noiseSuppression: true, echoCancellation: true } });
    this.pipe = await new AudioPipeline(s).init();
    this.mic = new MediaStream([this.pipe.track]);
    for (const t of this.mic.getTracks()) this.pc.addTrack(t, this.mic);
  }

  async call() {
    if (!this.dc || this.dc.readyState !== 'open') return;
    if (this.mic) { this.dc.send(JSON.stringify({ t: 'hangup' })); this.stopMic(); return this.render(); }
    await this.startMic();
    await this.pc.setLocalDescription(await this.pc.createOffer());
    this.dc.send(JSON.stringify({ t: 'sdp', sdp: this.pc.localDescription }));
    this.render();
  }

  stopMic() {
    if (!this.mic) return;
    for (const s of this.pc?.getSenders() || []) try { this.pc.removeTrack(s); } catch { /* */ }
    this.pipe?.destroy(); this.mic = null; this.pipe = null;
  }

  close() { this.stopMic(); this.dc?.close(); this.pc?.close(); this.pc = null; this.dc = null; }

  get connected() { return this.dc?.readyState === 'open'; }

  // ---------- UI ----------
  open() {
    this.app.dialog('📡 Mode Offline (tanpa internet)', '<div id="offline-ui"></div>', { wide: true });
    this.render();
  }

  render(step) {
    const el = document.getElementById('offline-ui');
    if (!el) return;
    const esc = this.app.esc;
    if (this.connected) {
      el.innerHTML = `
        <p class="chip ok">🟢 Terhubung langsung dengan <b>${esc(this.peerName)}</b> — tanpa server</p>
        <div class="offline-log">${this.log.map((m) => `<div class="bubble ${m.me ? 'out' : 'in'}"><span>${esc(m.text)}</span></div>`).join('') || '<p class="muted">Mulai ngobrol…</p>'}</div>
        <form class="row" data-off="form"><input class="input" name="t" placeholder="Pesan offline…" autocomplete="off"><button class="btn">Kirim</button></form>
        <button class="btn ${this.mic ? 'red' : 'ghost'}" data-off="call">${this.mic ? '📴 Akhiri telepon' : '📞 Telepon offline'}</button>
        <button class="btn ghost" data-off="close">Putuskan</button>`;
      const log = el.querySelector('.offline-log'); log.scrollTop = log.scrollHeight;
    } else {
      el.innerHTML = `
        <p class="muted">Sambungkan 2 HP ke Wi-Fi/hotspot yang sama (internet <b>tidak</b> perlu). Satu HP buat kode undangan, HP lain menempelkan kode itu lalu mengirim kode balasan.</p>
        <div class="row"><button class="btn" data-off="invite">1️⃣ Buat kode undangan</button><button class="btn ghost" data-off="join">Saya punya kode</button></div>
        <div id="off-step">${step || ''}</div>`;
    }
    el.onclick = async (e) => {
      const b = e.target.closest('[data-off]');
      if (!b) return;
      const step = el.querySelector('#off-step');
      try {
        if (b.dataset.off === 'invite') {
          step.innerHTML = '<p class="muted">Menyiapkan…</p>';
          const code = await this.createInvite();
          step.innerHTML = `<label>Bagikan kode ini ke HP lain:</label><textarea class="input code" readonly>${code}</textarea>
            <div class="row"><button class="btn ghost" data-off="copy">Salin</button><button class="btn ghost" data-off="share">Bagikan</button></div>
            <label>2️⃣ Tempel kode balasan dari HP lain:</label><textarea class="input code" id="off-answer"></textarea><button class="btn" data-off="finish">Sambungkan</button>`;
        } else if (b.dataset.off === 'join') {
          step.innerHTML = `<label>Tempel kode undangan:</label><textarea class="input code" id="off-invite"></textarea><button class="btn" data-off="answer">Buat kode balasan</button>`;
        } else if (b.dataset.off === 'answer') {
          const code = await this.acceptInvite(el.querySelector('#off-invite').value);
          step.innerHTML = `<label>Kirim kode balasan ini ke pembuat undangan:</label><textarea class="input code" readonly>${code}</textarea>
            <div class="row"><button class="btn ghost" data-off="copy">Salin</button><button class="btn ghost" data-off="share">Bagikan</button></div><p class="muted">Menunggu sambungan…</p>`;
        } else if (b.dataset.off === 'finish') {
          await this.finish(el.querySelector('#off-answer').value);
          step.insertAdjacentHTML('beforeend', '<p class="muted">Menghubungkan…</p>');
        } else if (b.dataset.off === 'copy') {
          await navigator.clipboard.writeText(el.querySelector('textarea[readonly]').value); this.app.toast('Kode disalin');
        } else if (b.dataset.off === 'share') {
          const text = el.querySelector('textarea[readonly]').value;
          if (navigator.share) navigator.share({ title: 'Kode Novalink Offline', text }).catch(() => {}); else { await navigator.clipboard.writeText(text); this.app.toast('Kode disalin'); }
        } else if (b.dataset.off === 'call') await this.call();
        else if (b.dataset.off === 'close') { this.close(); this.render(); }
      } catch (err) { this.app.toast('Kode tidak valid atau koneksi gagal'); }
    };
    el.onsubmit = (e) => { e.preventDefault(); const i = e.target.elements.t; this.send(i.value); i.value = ''; };
  }
}
