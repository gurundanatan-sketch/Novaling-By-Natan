// Extension system: built-in extensions + user-installed extensions running in a sandboxed iframe.
const FANCY = {
  bold: [0x1D5D4, 0x1D5EE, 0x1D7EC], italic: [0x1D608, 0x1D622, null], mono: [0x1D670, 0x1D68A, 0x1D7F6], script: [0x1D4D0, 0x1D4EA, null],
};
function stylize(text, style) {
  const [U, L, D] = FANCY[style];
  return [...text].map((c) => {
    const k = c.codePointAt(0);
    if (k >= 65 && k <= 90) return String.fromCodePoint(U + k - 65);
    if (k >= 97 && k <= 122) return String.fromCodePoint(L + k - 97);
    if (D && k >= 48 && k <= 57) return String.fromCodePoint(D + k - 48);
    return c;
  }).join('');
}
function safeCalc(expr) {
  if (!/^[\d\s+\-*/().,%^]+$/.test(expr)) return null;
  try {
    // eslint-disable-next-line no-new-func
    const v = Function(`"use strict";return (${expr.replace(/\^/g, '**').replace(/,/g, '.')})`)();
    return Number.isFinite(v) ? v : null;
  } catch { return null; }
}
function parseDelay(s) {
  const m = /^(\d+)\s*(d|detik|s|m|menit|j|jam|h)$/i.exec(s.trim());
  if (!m) return null;
  const n = Number(m[1]); const u = m[2].toLowerCase();
  return n * (u.startsWith('d') || u === 's' ? 1e3 : u.startsWith('m') ? 6e4 : 36e5);
}

export const BUILTIN = [
  {
    id: 'quick', icon: '⚡', name: 'Balasan Cepat', desc: 'Ketik /1 /2 /3 … untuk balasan tersimpan (atur di bawah).',
    onSend(text, ctx) {
      const m = /^\/(\d)$/.exec(text.trim());
      if (!m) return text;
      return ctx.settings.quickReplies?.[Number(m[1]) - 1] || text;
    },
  },
  {
    id: 'schedule', icon: '⏰', name: 'Jadwal Pesan', desc: 'Kirim nanti: "/jadwal 10m Pesan kamu" (d=detik, m=menit, j=jam).',
    onSend(text, ctx) {
      const m = /^\/jadwal\s+(\S+)\s+([\s\S]+)/i.exec(text);
      if (!m) return text;
      const ms = parseDelay(m[1]);
      if (!ms) { ctx.toast('Format: /jadwal 10m pesan'); return null; }
      ctx.schedule(ctx.convo, m[2], Date.now() + ms);
      ctx.toast(`⏰ Pesan dijadwalkan ${m[1]} lagi`);
      return null;
    },
  },
  {
    id: 'remind', icon: '🔔', name: 'Pengingat', desc: '"/ingatkan 30m Minum air" — notifikasi untuk dirimu sendiri.',
    onSend(text, ctx) {
      const m = /^\/ingatkan\s+(\S+)\s+([\s\S]+)/i.exec(text);
      if (!m) return text;
      const ms = parseDelay(m[1]);
      if (!ms) return text;
      setTimeout(() => { ctx.notify('🔔 Pengingat', m[2]); ctx.sfx(); }, ms);
      ctx.toast('🔔 Pengingat disetel');
      return null;
    },
  },
  {
    id: 'style', icon: '𝗕', name: 'Gaya Teks Keren', desc: '"/bold teks", "/italic", "/mono", "/script" → huruf unicode bergaya.',
    onSend(text) {
      const m = /^\/(bold|italic|mono|script)\s+([\s\S]+)/i.exec(text);
      return m ? stylize(m[2], m[1].toLowerCase()) : text;
    },
  },
  {
    id: 'calc', icon: '🧮', name: 'Kalkulator Inline', desc: 'Ketik "=12*7+3" untuk mengirim hasil hitungan.',
    onSend(text) {
      if (!text.startsWith('=')) return text;
      const v = safeCalc(text.slice(1));
      return v === null ? text : `${text.slice(1).trim()} = ${+v.toFixed(6)}`;
    },
  },
  {
    id: 'away', icon: '🌙', name: 'Balas Otomatis', desc: 'Saat mode pesawat/“jangan ganggu”, pesan masuk dibalas otomatis.',
    onIncoming(msg, ctx) {
      if (!ctx.settings.awayOn || ctx.state.groups[msg.to]) return;
      const key = 'away:' + msg.from;
      if (ctx.mem[key] && Date.now() - ctx.mem[key] < 30 * 60e3) return;
      ctx.mem[key] = Date.now();
      ctx.sendText(msg.from, ctx.settings.awayText || '🌙 Lagi nggak pegang HP, nanti aku balas ya. — dikirim otomatis oleh Novalink');
    },
  },
  {
    id: 'summary', icon: '🧠', name: 'Ringkas Chat', desc: '"/ringkas" menampilkan ringkasan percakapan (lokal, privat).',
    onSend(text, ctx) {
      if (text.trim() !== '/ringkas') return text;
      const msgs = ctx.messages(ctx.convo).filter((m) => m.kind === 'text');
      const words = {};
      for (const m of msgs) for (const w of m.text.toLowerCase().match(/[a-zÀ-ɏ]{5,}/g) || []) words[w] = (words[w] || 0) + 1;
      const top = Object.entries(words).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([w]) => w);
      const who = {};
      for (const m of msgs) who[m.from] = (who[m.from] || 0) + 1;
      ctx.alert('🧠 Ringkasan chat', `${msgs.length} pesan teks.\nPaling aktif: ${Object.entries(who).sort((a, b) => b[1] - a[1]).map(([id, n]) => `${ctx.userName(id)} (${n})`).join(', ') || '-'}\nTopik: ${top.join(', ') || '-'}`);
      return null;
    },
  },
  {
    id: 'stickers', icon: '🎨', name: 'Stiker Jumbo', desc: 'Kirim emoji tunggal sebagai stiker besar beranimasi.',
    onSend(text, ctx) {
      const t = text.trim();
      if ([...new Intl.Segmenter().segment(t)].length === 1 && /\p{Extended_Pictographic}/u.test(t)) { ctx.sendRaw(ctx.convo, { kind: 'sticker', text: t }); return null; }
      return text;
    },
  },
];

const SANDBOX_BOOT = `<script>
const handlers = { msg: [], cmd: {} };
const nl = {
  onMessage: (fn) => handlers.msg.push(fn),
  command: (name, fn) => { handlers.cmd[name] = fn; parent.postMessage({ nl: 'cmd', name }, '*'); },
  send: (to, text) => parent.postMessage({ nl: 'send', to, text: String(text) }, '*'),
  toast: (text) => parent.postMessage({ nl: 'toast', text: String(text) }, '*'),
};
addEventListener('message', async (e) => {
  const d = e.data || {};
  if (d.nl === 'code') { try { new Function('nl', d.code)(nl); parent.postMessage({ nl: 'ready' }, '*'); } catch (err) { parent.postMessage({ nl: 'error', text: String(err) }, '*'); } }
  if (d.nl === 'incoming') for (const fn of handlers.msg) try { fn(d.msg); } catch {}
  if (d.nl === 'run') { const fn = handlers.cmd[d.name]; let out = null; try { out = fn ? await fn(d.args, d.convo) : null; } catch {} parent.postMessage({ nl: 'result', id: d.id, text: out == null ? null : String(out) }, '*'); }
});
<\/script>`;

export const SAMPLE_EXTENSION = `// Contoh ekstensi Novalink — jalan di sandbox, tanpa akses ke token/akunmu.
nl.command('dadu', () => '🎲 Dadu: ' + (1 + Math.floor(Math.random() * 6)));
nl.command('balik', (args) => args.split('').reverse().join(''));
nl.onMessage((msg) => { if (/^ping$/i.test(msg.text)) nl.send(msg.from, 'pong 🏓'); });
`;

export class Extensions {
  constructor(app) {
    this.app = app;
    this.mem = {};
    this.custom = new Map(); // id -> {frame, name, commands:Set}
    this.pending = new Map();
    window.addEventListener('message', (e) => this.onFrameMessage(e));
  }

  enabled(id) { return this.app.settings.extensions?.[id] !== false; }

  ctx(convo) {
    const app = this.app;
    return {
      convo, settings: app.settings, state: app.state, mem: this.mem,
      toast: (t) => app.toast(t), notify: (a, b) => app.notify(a, b), sfx: () => app.playMessageSound(),
      sendText: (to, t) => app.sendText(to, t), sendRaw: (to, o) => app.sendMessage(to, o),
      schedule: (to, t, at) => app.scheduleMessage(to, t, at), messages: (c) => app.convMessages(c),
      userName: (id) => app.userName(id), alert: (t, b) => app.dialog(t, `<pre class="pre">${app.esc(b)}</pre>`),
    };
  }

  /** Returns transformed text or null if an extension consumed the message. */
  async transformOutgoing(text, convo) {
    const ctx = this.ctx(convo);
    for (const ext of BUILTIN) {
      if (!this.enabled(ext.id) || !ext.onSend) continue;
      text = ext.onSend(text, ctx);
      if (text == null) return null;
    }
    const m = /^\/(\w+)\s*([\s\S]*)/.exec(text);
    if (m) {
      for (const [, c] of this.custom) {
        if (c.commands.has(m[1])) {
          const out = await this.run(c, m[1], m[2], convo);
          return out;
        }
      }
    }
    return text;
  }

  onIncoming(msg) {
    const ctx = this.ctx(msg.to);
    for (const ext of BUILTIN) if (this.enabled(ext.id) && ext.onIncoming) try { ext.onIncoming(msg, ctx); } catch { /* */ }
    for (const [, c] of this.custom) c.frame.contentWindow?.postMessage({ nl: 'incoming', msg: { from: msg.from, to: msg.to, text: msg.text, kind: msg.kind } }, '*');
  }

  commandList() {
    const list = [
      ['/1 … /9', 'Balasan cepat'], ['/jadwal 10m teks', 'Jadwalkan pesan'], ['/ingatkan 30m teks', 'Pengingat'],
      ['/bold teks', 'Huruf tebal keren'], ['=2*21', 'Kalkulator'], ['/ringkas', 'Ringkas chat'],
    ];
    for (const [, c] of this.custom) for (const n of c.commands) list.push(['/' + n, c.name]);
    return list;
  }

  // ---------- custom sandboxed extensions ----------
  loadCustom() {
    for (const e of this.app.settings.customExtensions || []) if (e.enabled !== false) this.mount(e);
  }

  mount(e) {
    const frame = document.createElement('iframe');
    frame.sandbox = 'allow-scripts'; // no same-origin: cannot read token, storage, or DOM of the app
    frame.style.display = 'none';
    frame.srcdoc = SANDBOX_BOOT;
    frame.onload = () => frame.contentWindow.postMessage({ nl: 'code', code: e.code }, '*');
    document.body.appendChild(frame);
    this.custom.set(e.id, { id: e.id, name: e.name, frame, commands: new Set() });
  }

  unmount(id) { const c = this.custom.get(id); c?.frame.remove(); this.custom.delete(id); }

  install(name, code) {
    const e = { id: 'x' + Date.now().toString(36), name: name.slice(0, 40), code, enabled: true };
    this.app.settings.customExtensions = [...(this.app.settings.customExtensions || []), e];
    this.app.saveSettings();
    this.mount(e);
    return e;
  }

  remove(id) {
    this.unmount(id);
    this.app.settings.customExtensions = (this.app.settings.customExtensions || []).filter((x) => x.id !== id);
    this.app.saveSettings();
  }

  run(c, name, args, convo) {
    const id = Math.random().toString(36).slice(2);
    return new Promise((res) => {
      this.pending.set(id, res);
      c.frame.contentWindow.postMessage({ nl: 'run', id, name, args, convo }, '*');
      setTimeout(() => { if (this.pending.has(id)) { this.pending.delete(id); res(null); } }, 3000);
    });
  }

  onFrameMessage(e) {
    const c = [...this.custom.values()].find((x) => x.frame.contentWindow === e.source);
    if (!c) return;
    const d = e.data || {};
    if (d.nl === 'cmd') c.commands.add(String(d.name).replace(/\W/g, ''));
    if (d.nl === 'result') { const r = this.pending.get(d.id); if (r) { this.pending.delete(d.id); r(d.text); } }
    if (d.nl === 'toast') this.app.toast(`${c.name}: ${d.text}`);
    if (d.nl === 'error') this.app.toast(`Ekstensi ${c.name} error: ${d.text}`);
    if (d.nl === 'send' && (this.app.state.users[d.to] || this.app.state.groups[d.to])) {
      // rate limit sends from extensions
      const k = 'rl:' + c.id; const now = Date.now();
      this.mem[k] = (this.mem[k] || []).filter((t) => now - t < 60e3);
      if (this.mem[k].length < 10) { this.mem[k].push(now); this.app.sendText(d.to, d.text); }
    }
  }
}
