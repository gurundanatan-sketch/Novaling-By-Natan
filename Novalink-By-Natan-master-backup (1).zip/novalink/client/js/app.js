// Novalink By Natan — main application
import { idb } from './db.js';
import { RINGTONES, SFX, playSfx, previewRingtone, SEND_SFX, stopRingtone } from './sounds.js';
import { Calls, icon, fmt } from './call.js';
import { Assistant } from './assistant.js';
import { Extensions, BUILTIN, SAMPLE_EXTENSION } from './extensions.js';
import { OfflineLink } from './offline.js';
import { EMOJI_GROUPS, emojiName, speakableText } from './emoji.js';
import { VOICE_EFFECTS } from './audiofx.js';

const APP_NAME = 'Novalink';
const IS_APK = location.hostname === 'appassets.androidplatform.net';
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const timeStr = (ts) => new Date(ts).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
function dayStr(ts) {
  const d = new Date(ts), n = new Date();
  if (d.toDateString() === n.toDateString()) return 'Hari ini';
  const y = new Date(n); y.setDate(n.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return 'Kemarin';
  return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
}
function lastSeenStr(u) {
  if (!u) return '';
  if (u.online) return 'online';
  if (!u.lastSeen) return 'terakhir dilihat disembunyikan';
  const d = Date.now() - u.lastSeen;
  if (d < 60e3) return 'terakhir dilihat baru saja';
  if (d < 3600e3) return `terakhir dilihat ${Math.floor(d / 60e3)} menit lalu`;
  return `terakhir dilihat ${dayStr(u.lastSeen).toLowerCase()} ${timeStr(u.lastSeen)}`;
}

export const THEMES = {
  neon: { name: 'Neon Violet', bg: '#07060f', bg2: '#110d24', panel: 'rgba(24,18,48,.72)', text: '#f2efff', muted: '#9a93c4', accent: '#8b5cf6', accent2: '#06b6d4', out: 'linear-gradient(135deg,#7c3aed,#4f46e5)', in: 'rgba(255,255,255,.07)' },
  cyber: { name: 'Cyber Teal', bg: '#020c10', bg2: '#05222a', panel: 'rgba(6,40,48,.7)', text: '#e6fffb', muted: '#7fb5b0', accent: '#14f1d9', accent2: '#f72585', out: 'linear-gradient(135deg,#0d9488,#0891b2)', in: 'rgba(255,255,255,.07)' },
  sunset: { name: 'Sunset Pop', bg: '#140612', bg2: '#2a0c22', panel: 'rgba(52,16,40,.7)', text: '#fff1f5', muted: '#d29bb4', accent: '#fb7185', accent2: '#fbbf24', out: 'linear-gradient(135deg,#f43f5e,#f97316)', in: 'rgba(255,255,255,.08)' },
  matrix: { name: 'Matrix', bg: '#010702', bg2: '#03160a', panel: 'rgba(4,30,12,.75)', text: '#d7ffe0', muted: '#6fae7f', accent: '#22c55e', accent2: '#a3e635', out: 'linear-gradient(135deg,#15803d,#166534)', in: 'rgba(255,255,255,.06)' },
  sakura: { name: 'Sakura', bg: '#1a0c14', bg2: '#2c1322', panel: 'rgba(60,24,44,.65)', text: '#fff0f7', muted: '#e1a7c4', accent: '#f472b6', accent2: '#c4b5fd', out: 'linear-gradient(135deg,#ec4899,#a855f7)', in: 'rgba(255,255,255,.08)' },
  ocean: { name: 'Ocean Deep', bg: '#020617', bg2: '#0b1a3a', panel: 'rgba(12,30,70,.65)', text: '#e8f1ff', muted: '#8aa4d6', accent: '#3b82f6', accent2: '#22d3ee', out: 'linear-gradient(135deg,#2563eb,#0ea5e9)', in: 'rgba(255,255,255,.07)' },
  amoled: { name: 'AMOLED Black', bg: '#000', bg2: '#000', panel: 'rgba(16,16,16,.85)', text: '#fafafa', muted: '#8a8a8a', accent: '#a78bfa', accent2: '#34d399', out: 'linear-gradient(135deg,#27272a,#3f3f46)', in: 'rgba(255,255,255,.06)' },
  frost: { name: 'Light Frost', bg: '#eef2ff', bg2: '#ffffff', panel: 'rgba(255,255,255,.75)', text: '#1e1b4b', muted: '#6366f1', accent: '#6d28d9', accent2: '#0891b2', out: 'linear-gradient(135deg,#8b5cf6,#6366f1)', in: 'rgba(30,27,75,.07)', light: true },
};

const DEFAULT_SETTINGS = {
  theme: 'neon', accent: '', dim: 0.55, ringtone: 'neon', msgSound: 'pop', groupSound: 'chime', antiDelete: true,
  airplane: false, autoAirplaneMin: 0, hideIp: true, noiseSuppression: true, voiceEffect: 'normal', assistant: true,
  announceCalls: true, announceMessages: false, handsFree: true, assistantVoice: true, readEmoji: false, fontScale: 1,
  highContrast: false, extensions: {}, customExtensions: [], quickReplies: ['Oke siap 👍', 'Lagi di jalan, nanti aku kabari ya', 'Terima kasih banyak 🙏'],
  awayOn: false, awayText: '', pinned: {}, muted: {}, disappearing: {}, scheduled: [], hidden: {}, lastRead: {}, preferSfu: false,
  serverUrl: '', voiceCheck: true, enterSend: true,
};

class App {
  constructor() {
    this.settings = { ...DEFAULT_SETTINGS, ...JSON.parse(localStorage.getItem('nl:settings') || '{}') };
    this.state = { token: localStorage.getItem('nl:token'), me: null, users: {}, groups: {}, messages: {}, stories: [], callLog: [], outbox: [], typing: {}, ice: null, livekit: false, online: false };
    this.view = { tab: 'chats', conv: null };
    this.calls = new Calls(this);
    this.assistant = new Assistant(this);
    this.ext = new Extensions(this);
    this.offline = new OfflineLink(this);
    this.esc = esc;
    this.replyTo = null;
    this.editing = null;
  }

  // ================= boot =================
  async boot() {
    const qs = new URLSearchParams(location.search).get('server');
    if (qs && !this.settings.serverUrl) { this.settings.serverUrl = qs; this.saveSettings(); }
    this.applyTheme();
    this.state.callLog = JSON.parse(localStorage.getItem('nl:calls') || '[]');
    this.state.outbox = (await idb.get('outbox')) || [];
    if ('serviceWorker' in navigator && location.protocol.startsWith('http') && !IS_APK) navigator.serviceWorker.register('sw.js').catch(() => {});
    window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); this.installPrompt = e; });
    window.addEventListener('online', () => this.connect());
    this.setupIdle();
    setInterval(() => this.tickScheduled(), 5000);
    if (!this.state.token) return this.renderAuth();
    const cache = await idb.get('cache');
    if (cache) this.ingest(cache, true);
    this.renderShell();
    this.ext.loadCustom();
    await this.bootstrap();
    this.connect();
    this.handleDeepLink();
  }

  get base() {
    if (this.settings.serverUrl) return this.settings.serverUrl.replace(/\/$/, '');
    if (IS_APK) return ''; // APK: server must be set (build-time NOVALINK_SERVER_URL or "Server lanjutan")
    return location.protocol.startsWith('http') ? location.origin : 'http://localhost:8080';
  }
  media(u) { return !u ? '' : /^(https?:|blob:|data:)/.test(u) ? u : this.base + u; }

  async api(path, body, method) {
    const r = await fetch(this.base + path, {
      method: method || (body ? 'POST' : 'GET'),
      headers: { 'Content-Type': 'application/json', ...(this.state.token ? { Authorization: 'Bearer ' + this.state.token } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
    const j = await r.json().catch(() => ({}));
    if (r.status === 401 && this.state.token && !path.includes('login')) { this.logout(true); throw new Error('Sesi berakhir'); }
    if (!r.ok) throw new Error(j.error || 'Gagal');
    return j;
  }

  async bootstrap() {
    if (this.settings.airplane) return;
    try {
      const b = await this.api('/api/bootstrap');
      this.ingest(b, false);
      this.persistCache();
      this.render();
    } catch { /* offline: use cache */ }
  }

  ingest(b, fromCache) {
    const s = this.state;
    if (b.me) s.me = b.me;
    for (const u of b.users || []) s.users[u.id] = u;
    for (const g of b.groups || []) s.groups[g.id] = g;
    if (b.ice) s.ice = b.ice;
    if (b.livekit !== undefined) s.livekit = b.livekit;
    if (b.stories) s.stories = b.stories;
    if (b.messages) {
      const map = fromCache ? {} : s.messages;
      if (!fromCache) for (const k of Object.keys(map)) map[k] = map[k].filter((m) => m.pending);
      for (const m of Array.isArray(b.messages) ? b.messages : Object.values(b.messages).flat()) this.putMessage(m, map);
      s.messages = map;
    }
  }

  persistCache() {
    clearTimeout(this.cacheT);
    this.cacheT = setTimeout(() => {
      const s = this.state;
      idb.set('cache', { me: s.me, users: Object.values(s.users), groups: Object.values(s.groups), messages: Object.values(s.messages).flat().filter((m) => !m.pending), stories: s.stories });
    }, 800);
  }

  saveSettings() { localStorage.setItem('nl:settings', JSON.stringify(this.settings)); }
  saveCallLog() { localStorage.setItem('nl:calls', JSON.stringify(this.state.callLog.slice(-300))); }

  // ================= realtime =================
  connect() {
    if (!this.state.token || this.settings.airplane) return;
    if (this.ws && this.ws.readyState <= 1) return;
    const url = this.base.replace(/^http/, 'ws') + '/ws?token=' + encodeURIComponent(this.state.token);
    const ws = new WebSocket(url);
    this.ws = ws;
    ws.onopen = () => { this.state.online = true; this.retry = 0; this.renderStatus(); this.flushOutbox(); this.bootstrap(); };
    ws.onmessage = (e) => this.onWS(JSON.parse(e.data));
    ws.onclose = (e) => {
      this.state.online = false; this.renderStatus();
      if (e.code === 4001) return this.logout(true);
      if (this.settings.airplane) return;
      clearTimeout(this.reconnectT);
      this.reconnectT = setTimeout(() => this.connect(), Math.min(30000, 1000 * 2 ** (this.retry = (this.retry || 0) + 1)));
    };
  }

  send(obj) {
    if (this.ws?.readyState === 1) { this.ws.send(JSON.stringify(obj)); return true; }
    return false;
  }

  onWS(m) {
    const s = this.state;
    switch (m.t) {
      case 'msg': {
        const msg = m.msg;
        if (msg.from === s.me.id) { this.putMessage(msg); this.refreshConv(this.convOf(msg)); break; }
        if (this.isBlocked(msg.from)) break;
        if (!s.users[msg.from]) this.fetchUserLater(msg.from);
        this.putMessage(msg);
        const conv = this.convOf(msg);
        const open = this.view.conv === conv && !document.hidden;
        if (open) this.markRead(conv); else if (!this.settings.muted[conv]) {
          this.playMessageSound(!!s.groups[msg.to]);
          this.notify(this.convTitle(conv), this.preview(msg));
          this.assistant.announceMessage(msg);
        }
        this.ext.onIncoming(msg);
        this.refreshConv(conv);
        this.persistCache();
        break;
      }
      case 'ack': {
        const msg = this.findMsg(m.id);
        if (msg) { msg.pending = false; msg.ts = m.ts; if (m.status) msg.status = m.status; this.refreshConv(this.convOf(msg)); }
        this.state.outbox = this.state.outbox.filter((o) => o.id !== m.id); idb.set('outbox', this.state.outbox);
        break;
      }
      case 'status': for (const id of m.ids) { const x = this.findMsg(id); if (x) x.status = m.status; } this.refreshConv(this.view.conv); break;
      case 'deleted': {
        const x = this.findMsg(m.id);
        if (x) { x.deleted = true; x.deletedAt = m.at; this.refreshConv(this.convOf(x)); if (x.from !== s.me.id && this.settings.antiDelete) this.toast(`🛡️ ${this.userName(x.from)} menghapus pesan — tetap tersimpan oleh Anti-Hapus`); }
        break;
      }
      case 'edited': { const x = this.findMsg(m.id); if (x) { x.text = m.text; x.edits = m.edits; this.refreshConv(this.convOf(x)); } break; }
      case 'reaction': { const x = this.findMsg(m.id); if (x) { x.reactions = m.reactions; this.refreshConv(this.convOf(x)); } break; }
      case 'typing': {
        const conv = s.groups[m.to] ? m.to : m.from;
        s.typing[conv] = m.on ? { who: m.from, mode: m.mode, at: Date.now() } : null;
        this.renderTyping(conv);
        if (m.on) setTimeout(() => { if (s.typing[conv] && Date.now() - s.typing[conv].at > 5500) { s.typing[conv] = null; this.renderTyping(conv); } }, 6000);
        break;
      }
      case 'presence': s.users[m.user.id] = { ...s.users[m.user.id], ...m.user }; this.renderHeader(); if (this.view.tab === 'chats') this.renderList(); break;
      case 'user': s.users[m.user.id] = m.user; this.renderList(); break;
      case 'group': s.groups[m.group.id] = m.group; for (const u of m.users || []) if (u) s.users[u.id] = { ...s.users[u.id], ...u }; this.render(); break;
      case 'story': s.stories = s.stories.filter((x) => x.id !== m.story.id).concat(m.story); if (m.user) s.users[m.user.id] = { ...s.users[m.user.id], ...m.user }; if (this.view.tab === 'stories') this.renderList(); break;
      case 'story-view': { const st = s.stories.find((x) => x.id === m.id); if (st) { st.views = st.views || []; if (!st.views.some((v) => v.id === m.viewer.id)) st.views.push({ id: m.viewer.id, at: Date.now() }); s.users[m.viewer.id] ||= m.viewer; } break; }
      case 'signal': this.calls.onSignal(m.from, m.data); break;
      case 'call-members': case 'call-joined': case 'call-left': this.calls.onRoom(m); break;
      case 'group-ring': this.calls.onGroupRing(m); break;
      default: break;
    }
  }

  async fetchUserLater(id) {
    try { const b = await this.api('/api/bootstrap'); this.ingest({ users: b.users, groups: b.groups }); this.renderList(); } catch { /* */ }
  }

  // ================= messages =================
  convOf(m) { return this.state.groups[m.to] ? m.to : m.from === this.state.me?.id ? m.to : m.from; }
  convMessages(conv) {
    const now = Date.now();
    return (this.state.messages[conv] || []).filter((m) => !this.settings.hidden[m.id] && (!m.expiresAt || m.expiresAt > now));
  }
  putMessage(m, map = this.state.messages) {
    const conv = this.convOf(m);
    const list = (map[conv] ||= []);
    const i = list.findIndex((x) => x.id === m.id);
    if (i >= 0) list[i] = { ...list[i], ...m, pending: false }; else list.push(m);
    list.sort((a, b) => a.ts - b.ts);
  }
  findMsg(id) { for (const l of Object.values(this.state.messages)) { const m = l.find((x) => x.id === id); if (m) return m; } return null; }
  isBlocked(id) { return (this.state.me?.blocked || []).includes(id); }

  sendText(to, text) { if (text && text.trim()) this.sendMessage(to, { kind: 'text', text: text.trim() }); }

  sendMessage(to, payload, file) {
    const s = this.state;
    const ttl = this.settings.disappearing[to] || 0;
    const msg = { id: uid(), from: s.me.id, to, ts: Date.now(), clientTs: Date.now(), status: 'pending', pending: true, reactions: {}, edits: [], kind: 'text', text: '', ...payload, ttl, expiresAt: ttl ? Date.now() + ttl * 1000 : null };
    this.putMessage(msg);
    this.refreshConv(to);
    const out = { t: 'msg', id: msg.id, to, kind: msg.kind, text: msg.text, media: msg.media || null, replyTo: msg.replyTo || null, forwarded: !!msg.forwarded, viewOnce: !!msg.viewOnce, ttl: ttl || undefined, clientTs: msg.clientTs, offline: !this.state.online };
    if (file) { this.uploadThenSend(msg, out, file); return msg; }
    if (!this.send(out)) { this.state.outbox.push({ id: msg.id, out }); idb.set('outbox', this.state.outbox); }
    if (this.settings.msgSound !== 'none') SEND_SFX();
    return msg;
  }

  async uploadThenSend(msg, out, file) {
    if (!this.state.online) {
      this.state.outbox.push({ id: msg.id, out, file }); idb.set('outbox', this.state.outbox);
      this.toast('📥 Media disimpan di antrean, dikirim otomatis saat online');
      return;
    }
    try {
      msg.progress = 0;
      const res = await this.upload(file, (p) => { msg.progress = p; this.updateProgress(msg); });
      msg.media = { ...msg.media, url: res.url, name: file.name, size: file.size, mime: file.type };
      out.media = msg.media;
      msg.progress = null;
      if (!this.send(out)) { this.state.outbox.push({ id: msg.id, out }); idb.set('outbox', this.state.outbox); }
      this.refreshConv(out.to);
    } catch { this.toast('Upload gagal'); msg.status = 'failed'; this.refreshConv(out.to); }
  }

  upload(file, onProgress) {
    return new Promise((res, rej) => {
      const x = new XMLHttpRequest();
      x.open('POST', this.base + '/api/upload');
      x.setRequestHeader('Authorization', 'Bearer ' + this.state.token);
      x.setRequestHeader('x-filename', encodeURIComponent(file.name || 'file'));
      x.upload.onprogress = (e) => e.lengthComputable && onProgress?.(e.loaded / e.total);
      x.onload = () => (x.status < 300 ? res(JSON.parse(x.responseText)) : rej(new Error(x.status)));
      x.onerror = rej;
      x.send(file);
    });
  }

  async flushOutbox() {
    const box = [...this.state.outbox];
    for (const o of box) {
      if (o.file) {
        try {
          const r = await this.upload(o.file);
          o.out.media = { ...(o.out.media || {}), url: r.url, name: o.file.name, size: o.file.size, mime: o.file.type };
          const m = this.findMsg(o.id); if (m) m.media = o.out.media;
          delete o.file;
        } catch { continue; }
      }
      this.send(o.out);
    }
    idb.set('outbox', this.state.outbox);
  }

  scheduleMessage(to, text, at) { this.settings.scheduled.push({ to, text, at }); this.saveSettings(); }
  tickScheduled() {
    const now = Date.now();
    const due = this.settings.scheduled.filter((x) => x.at <= now);
    if (!due.length) return;
    this.settings.scheduled = this.settings.scheduled.filter((x) => x.at > now);
    this.saveSettings();
    for (const d of due) this.sendText(d.to, d.text);
  }

  markRead(conv) {
    const list = this.convMessages(conv);
    const me = this.state.me.id;
    this.settings.lastRead[conv] = Date.now(); this.saveSettings();
    const ids = list.filter((m) => m.from !== me && m.status !== 'read' && !this.state.groups[conv]).map((m) => m.id);
    for (const m of list) if (m.from !== me) m.status = 'read';
    if (ids.length) this.send({ t: 'read', ids });
  }
  unreadCount(conv) {
    const lr = this.settings.lastRead[conv] || 0;
    return this.convMessages(conv).filter((m) => m.from !== this.state.me.id && m.ts > lr).length;
  }
  unreadMessages() { return Object.keys(this.state.messages).flatMap((c) => { const lr = this.settings.lastRead[c] || 0; return this.convMessages(c).filter((m) => m.from !== this.state.me.id && m.ts > lr); }).sort((a, b) => a.ts - b.ts); }

  preview(m) {
    if (!m) return '';
    if (m.deleted && !(this.settings.antiDelete && m.from !== this.state.me.id)) return '🚫 Pesan dihapus';
    const icons = { image: '📷 Foto', video: '🎬 Video', audio: '🎵 Audio', voice: '🎤 Pesan suara', doc: '📄 ' + (m.media?.name || 'Dokumen'), sticker: m.text + ' Stiker' };
    const t = m.kind === 'text' ? m.text : icons[m.kind] + (m.text && m.kind !== 'sticker' ? ' · ' + m.text : '');
    return (m.deleted ? '🛡️ ' : '') + t;
  }

  // ================= names / avatars =================
  userName(id) { if (id === this.state.me?.id) return 'Kamu'; const u = this.state.users[id]; return u ? u.displayName : 'Pengguna'; }
  convTitle(conv) { return this.state.groups[conv]?.name || this.userName(conv); }
  avatarHtml(u, cls = '') {
    const name = u?.displayName || u?.name || '?';
    if (u?.avatar) return `<span class="avatar ${cls}"><img src="${esc(this.media(u.avatar))}" alt=""></span>`;
    let h = 0; for (const c of name) h = (h * 31 + c.charCodeAt(0)) % 360;
    const ini = name.split(/\s+/).map((w) => [...w][0] || '').join('').slice(0, 2).toUpperCase();
    return `<span class="avatar ${cls}" style="--h:${h}">${esc(ini)}</span>`;
  }

  // ================= theme =================
  async applyTheme() {
    const t = THEMES[this.settings.theme] || THEMES.neon;
    const r = document.documentElement.style;
    r.setProperty('--bg', t.bg); r.setProperty('--bg2', t.bg2); r.setProperty('--panel', t.panel); r.setProperty('--text', t.text);
    r.setProperty('--muted', t.muted); r.setProperty('--accent', this.settings.accent || t.accent); r.setProperty('--accent2', t.accent2);
    r.setProperty('--out', t.out); r.setProperty('--in', t.in); r.setProperty('--dim', this.settings.dim);
    r.setProperty('--fs', this.settings.fontScale);
    document.documentElement.classList.toggle('light', !!t.light);
    document.documentElement.classList.toggle('contrast', !!this.settings.highContrast);
    const bg = await idb.get('appBg');
    if (this.appBgUrl) URL.revokeObjectURL(this.appBgUrl);
    this.appBgUrl = bg ? URL.createObjectURL(bg) : null;
    r.setProperty('--app-img', this.appBgUrl ? `url("${this.appBgUrl}")` : 'none');
    document.querySelector('meta[name=theme-color]')?.setAttribute('content', t.bg);
  }
  async chatWallpaper(conv) {
    const per = await idb.get('wall:' + conv);
    const glob = per || (await idb.get('wall:*'));
    if (this.wallUrl) URL.revokeObjectURL(this.wallUrl);
    this.wallUrl = glob instanceof Blob ? URL.createObjectURL(glob) : null;
    const preset = this.settings['wallPreset:' + conv] || this.settings['wallPreset:*'];
    return this.wallUrl ? `url("${this.wallUrl}")` : preset || 'none';
  }
  pickImage(cb, accept = 'image/*') {
    const i = Object.assign(document.createElement('input'), { type: 'file', accept });
    i.onchange = () => i.files[0] && cb(i.files[0]);
    i.click();
  }

  // ================= notifications & sounds =================
  playMessageSound(group) { playSfx(group ? this.settings.groupSound : this.settings.msgSound); }
  notify(title, body, opts = {}) {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    if (!document.hidden && !opts.call) return;
    const text = this.settings.readEmoji ? body : body;
    navigator.serviceWorker?.getRegistration().then((r) => {
      if (r) r.showNotification(title, { body: text, icon: 'icons/icon-192.png', tag: opts.call ? 'call' : undefined, renotify: true, vibrate: opts.call ? [500, 250, 500] : [120] });
      else new Notification(title, { body: text });
    }).catch(() => {});
  }
  toast(text) {
    const t = document.createElement('div');
    t.className = 'toast'; t.textContent = text;
    $('#toasts').appendChild(t);
    setTimeout(() => t.classList.add('out'), 3200);
    setTimeout(() => t.remove(), 3700);
  }
  dialog(title, html, opts = {}) {
    const d = $('#dialog');
    d.innerHTML = `<div class="sheet glass ${opts.wide ? 'wide' : ''}" role="dialog" aria-label="${esc(title)}"><div class="sheet-head"><h3>${title}</h3><button class="icon-btn" data-act="close-dialog" aria-label="Tutup">✕</button></div><div class="sheet-body">${html}</div></div>`;
    d.classList.add('open');
    return d.querySelector('.sheet-body');
  }
  closeDialog() { $('#dialog').classList.remove('open'); $('#dialog').innerHTML = ''; }

  // ================= airplane mode =================
  setAirplane(on) {
    this.settings.airplane = on; this.saveSettings();
    if (on) { clearTimeout(this.reconnectT); this.ws?.close(); this.calls.active && this.calls.hangup(); stopRingtone(); this.state.online = false; }
    else this.connect();
    this.renderStatus();
    this.toast(on ? '✈️ Mode pesawat aktif — Novalink tidak menerima pesan & panggilan' : '📶 Mode pesawat nonaktif');
  }
  setupIdle() {
    const reset = () => {
      this.lastActive = Date.now();
    };
    ['pointerdown', 'keydown', 'touchstart'].forEach((e) => window.addEventListener(e, reset, { passive: true }));
    reset();
    setInterval(() => {
      const min = Number(this.settings.autoAirplaneMin);
      if (min > 0 && !this.settings.airplane && !this.calls.active && Date.now() - this.lastActive > min * 60e3) {
        this.setAirplane(true);
        this.settings.autoAirplaneTriggered = true; this.saveSettings();
      }
    }, 15e3);
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) {
        if (this.settings.autoAirplaneTriggered && this.settings.airplane) { this.settings.autoAirplaneTriggered = false; this.setAirplane(false); }
        if (this.view.conv) this.markRead(this.view.conv);
      }
    });
  }

  // ================= auth =================
  renderAuth(mode = 'register') {
    this.bindGlobal();
    $('#app').innerHTML = `
      <div class="auth">
        <div class="auth-card glass">
          <div class="logo big">${logo()}<div><h1>${APP_NAME}</h1><span class="by">By Natan</span></div></div>
          <p class="muted">Chat, telepon & story generasi baru — privat, canggih, dan bisa offline.</p>
          <div class="seg"><button data-act="auth-mode" data-mode="register" class="${mode === 'register' ? 'on' : ''}">Daftar</button><button data-act="auth-mode" data-mode="login" class="${mode === 'login' ? 'on' : ''}">Masuk</button></div>
          <form id="auth-form">
            ${mode === 'register' ? '<input class="input" name="displayName" placeholder="Nama tampilan" required maxlength="40">' : ''}
            <input class="input" name="username" placeholder="Username (tanpa nomor HP)" required pattern="[a-zA-Z0-9_.]{3,24}" autocapitalize="none" autocomplete="username">
            <input class="input" name="pin" type="password" inputmode="numeric" placeholder="PIN 4-8 digit" required pattern="\\d{4,8}" autocomplete="${mode === 'register' ? 'new-password' : 'current-password'}">
            ${mode === 'register' ? '<input class="input" name="phone" type="tel" placeholder="No. HP (opsional, disimpan ter-hash)">' : ''}
            <details ${IS_APK && !this.settings.serverUrl ? 'open' : ''}><summary class="muted">Server lanjutan</summary><input class="input" name="serverUrl" placeholder="https://server-kamu.com" value="${esc(this.settings.serverUrl)}"></details>
            <button class="btn full">${mode === 'register' ? 'Buat akun' : 'Masuk'} →</button>
            <p class="err" id="auth-err"></p>
          </form>
          <p class="tiny muted">🛡️ Nomor HP tidak pernah ditampilkan ke pengguna lain. Kamu ditemukan lewat username.</p>
        </div>
      </div>`;
    $('#auth-form').onsubmit = async (e) => {
      e.preventDefault();
      const f = Object.fromEntries(new FormData(e.target));
      this.settings.serverUrl = (f.serverUrl || '').trim().replace(/\/$/, ''); this.saveSettings();
      if (!this.base) { $('#auth-err').textContent = 'Isi alamat server dulu di "Server lanjutan" (mis. https://novalink.domainmu.com)'; return; }
      try {
        const r = await this.api(mode === 'register' ? '/api/register' : '/api/login', f);
        this.state.token = r.token; localStorage.setItem('nl:token', r.token);
        this.state.me = r.user;
        this.renderShell(); this.ext.loadCustom();
        await this.bootstrap(); this.connect(); this.handleDeepLink();
        if (mode === 'register') this.toast('Selamat datang di Novalink ✦');
      } catch (err) { $('#auth-err').textContent = err.message; }
    };
  }

  async logout(expired) {
    try { if (!expired) await this.api('/api/logout', {}); } catch { /* */ }
    localStorage.removeItem('nl:token'); await idb.del('cache'); await idb.del('outbox');
    this.ws?.close(); location.reload();
  }

  handleDeepLink() {
    const m = /#\/add\/([\w.]+)/.exec(location.hash);
    if (!m) return;
    history.replaceState(null, '', location.pathname);
    this.api('/api/contacts', { username: m[1] }).then((u) => { this.state.users[u.id] = u; this.openChat(u.id); this.toast(`@${u.username} ditambahkan`); }).catch(() => this.toast('Pengguna tidak ditemukan'));
  }

  // ================= shell =================
  renderShell() {
    $('#app').innerHTML = `
      <div class="layout ${this.view.conv ? 'in-chat' : ''}">
        <aside class="side glass">
          <header class="top">
            <div class="logo">${logo()}<div><b>${APP_NAME}</b><span class="by">By Natan</span></div></div>
            <div class="top-actions">
              <button class="icon-btn" data-act="nova" aria-label="Asisten suara Nova" title="Asisten Nova">🎙️</button>
              <button class="icon-btn" data-act="airplane" aria-label="Mode pesawat" title="Mode pesawat" id="airplane-btn">✈️</button>
              <button class="icon-btn" data-act="new-chat" aria-label="Chat baru" title="Chat baru">＋</button>
            </div>
          </header>
          <div id="status-bar"></div>
          <div class="search"><input class="input" id="search" placeholder="Cari chat atau pesan…" aria-label="Cari"></div>
          <div id="list" class="list"></div>
          <nav class="tabs">
            ${[['chats', '💬', 'Chat'], ['stories', '◎', 'Story'], ['calls', '📞', 'Panggilan'], ['ext', '🧩', 'Ekstensi'], ['settings', '⚙️', 'Setelan']].map(([k, i, n]) => `<button data-act="tab" data-tab="${k}" class="${this.view.tab === k ? 'on' : ''}"><span>${i}</span><small>${n}</small></button>`).join('')}
          </nav>
        </aside>
        <main id="pane" class="pane"></main>
      </div>`;
    this.bindGlobal();
    this.render();
  }

  render() {
    if (!$('.layout')) return;
    this.renderStatus();
    this.renderList();
    this.renderPane();
  }

  renderStatus() {
    const el = $('#status-bar');
    if (!el) return;
    const a = this.settings.airplane;
    $('#airplane-btn')?.classList.toggle('on', a);
    const q = this.state.outbox.length;
    el.innerHTML = a ? `<div class="banner warn">✈️ Mode pesawat aktif · ${q ? q + ' pesan menunggu · ' : ''}<button class="link" data-act="airplane">Matikan</button></div>`
      : !this.state.online ? `<div class="banner">📡 Menghubungkan… ${q ? '· ' + q + ' pesan di antrean offline' : ''} <button class="link" data-act="offline">Mode Offline</button></div>` : '';
  }

  setTab(tab) {
    this.view.tab = tab;
    document.querySelectorAll('.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
    $('#search').parentElement.style.display = ['chats', 'calls'].includes(tab) ? '' : 'none';
    this.renderList();
  }

  renderList() {
    const el = $('#list');
    if (!el || !this.state.me) return;
    const tab = this.view.tab;
    if (tab === 'chats') el.innerHTML = this.chatListHtml();
    else if (tab === 'stories') el.innerHTML = this.storiesHtml();
    else if (tab === 'calls') el.innerHTML = this.callsHtml();
    else if (tab === 'ext') el.innerHTML = this.extHtml();
    else if (tab === 'settings') el.innerHTML = this.settingsHtml();
  }

  conversations() {
    const s = this.state;
    const ids = new Set([...Object.keys(s.messages), ...Object.keys(s.groups), ...(s.me.contacts || [])]);
    return [...ids].filter((c) => (s.users[c] || s.groups[c]) && c !== s.me.id).map((c) => {
      const list = this.convMessages(c);
      return { id: c, last: list[list.length - 1], unread: this.unreadCount(c), pinned: !!this.settings.pinned[c] };
    }).sort((a, b) => (b.pinned - a.pinned) || ((b.last?.ts || 0) - (a.last?.ts || 0)));
  }

  chatListHtml() {
    const q = ($('#search')?.value || '').toLowerCase();
    let convs = this.conversations();
    if (q) convs = convs.filter((c) => this.convTitle(c.id).toLowerCase().includes(q) || this.convMessages(c.id).some((m) => (m.text || '').toLowerCase().includes(q)));
    if (!convs.length) return `<div class="empty"><div class="empty-orb"></div><p>Belum ada chat.</p><button class="btn" data-act="new-chat">＋ Mulai chat</button><button class="btn ghost" data-act="new-group">👥 Buat grup</button></div>`;
    const s = this.state;
    return `<div class="row pad"><button class="chip" data-act="new-group">👥 Grup baru</button><button class="chip" data-act="share-me">🔗 Link profilku</button><button class="chip" data-act="offline">📡 Offline</button></div>` + convs.map((c) => {
      const g = s.groups[c.id];
      const u = s.users[c.id];
      const typing = s.typing[c.id];
      const sub = typing ? `<i class="typing-txt">${typing.mode === 'voice' ? 'merekam suara…' : g ? esc(this.userName(typing.who)) + ' mengetik…' : 'mengetik…'}</i>` : esc((c.last && c.last.from === s.me.id ? tickText(c.last) + ' ' : '') + this.preview(c.last));
      return `<button class="conv ${this.view.conv === c.id ? 'active' : ''}" data-act="open" data-id="${c.id}">
        ${this.avatarHtml(g ? { displayName: g.name, avatar: g.avatar } : u, u?.online ? 'online' : '')}
        <div class="conv-main"><div class="conv-top"><b>${esc(this.convTitle(c.id))}</b>${u?.verified ? ' <span class="verified">✓</span>' : ''}<span class="muted tiny">${c.last ? timeStr(c.last.ts) : ''}</span></div>
        <div class="conv-sub"><span class="ellipsis">${sub}</span>${c.pinned ? '<span>📌</span>' : ''}${this.settings.muted[c.id] ? '<span>🔕</span>' : ''}${c.unread ? `<span class="badge">${c.unread}</span>` : ''}</div></div>
      </button>`;
    }).join('');
  }

  // ================= chat pane =================
  openChat(conv) {
    this.view.conv = conv;
    this.replyTo = null; this.editing = null;
    $('.layout')?.classList.add('in-chat');
    this.markRead(conv);
    this.renderPane();
    this.renderList();
    this.loadSmartReplies();
  }
  closeChat() { this.view.conv = null; $('.layout')?.classList.remove('in-chat'); this.renderPane(); this.renderList(); }

  async renderPane() {
    const pane = $('#pane');
    if (!pane) return;
    const conv = this.view.conv;
    if (!conv) {
      pane.innerHTML = `<div class="welcome"><div class="hero-orb"></div><h2>${APP_NAME} <span class="by">By Natan</span></h2><p class="muted">Pilih chat untuk mulai. Pesan terenkripsi saat transit, IP terlindungi, dan tetap jalan meski offline.</p>
        <div class="feature-grid">${[['🤖', 'Asisten Nova', 'Angkat telepon & balas chat pakai suara'], ['🛡️', 'Anti-Hapus', 'Pesan yang dihapus tetap terbaca'], ['🎵', 'Telepon + Musik', 'Karaoke saat telepon, cukup 1 HP'], ['📡', 'Offline Mode', 'Chat & telepon tanpa internet'], ['🎭', 'Pengubah Suara', '9 efek suara keren'], ['👥', 'Grup Call 20+', 'Video call ramai-ramai']].map(([i, t, d]) => `<div class="feature glass"><span>${i}</span><b>${t}</b><small class="muted">${d}</small></div>`).join('')}</div></div>`;
      return;
    }
    const s = this.state;
    const g = s.groups[conv];
    pane.innerHTML = `
      <div class="chat">
        <div class="chat-bg"></div>
        <header class="chat-head glass" id="chat-head"></header>
        <div class="messages" id="messages" aria-live="polite"></div>
        <div id="smart" class="smart"></div>
        <div id="reply-bar"></div>
        <div class="emoji-panel glass" id="emoji-panel" hidden></div>
        <footer class="composer glass">
          <button class="icon-btn" data-act="emoji" aria-label="Emoji">😊</button>
          <button class="icon-btn" data-act="attach" aria-label="Lampirkan dari galeri">📎</button>
          <textarea id="input" rows="1" placeholder="${g ? 'Pesan ke grup…' : 'Ketik pesan…'}" aria-label="Ketik pesan"></textarea>
          <button class="icon-btn" data-act="dictate" aria-label="Ketik dengan suara (periksa suara)" title="Dikte + periksa suara">🗣️</button>
          <button class="send" id="send-btn" data-act="send" aria-label="Kirim">${micIcon()}</button>
        </footer>
      </div>`;
    this.renderHeader();
    this.renderMessages(true);
    const input = $('#input');
    input.addEventListener('input', () => {
      input.style.height = 'auto'; input.style.height = Math.min(140, input.scrollHeight) + 'px';
      $('#send-btn').innerHTML = input.value.trim() ? sendIcon() : micIcon();
      this.sendTyping();
    });
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && this.settings.enterSend && !matchMedia('(pointer:coarse)').matches) { e.preventDefault(); this.submit(); } });
    const wall = await this.chatWallpaper(conv);
    const bg = pane.querySelector('.chat-bg');
    if (bg) bg.style.backgroundImage = wall;
  }

  renderHeader() {
    const h = $('#chat-head');
    const conv = this.view.conv;
    if (!h || !conv) return;
    const s = this.state;
    const g = s.groups[conv];
    const u = s.users[conv];
    const t = s.typing[conv];
    const sub = t ? (t.mode === 'voice' ? 'merekam suara…' : (g ? this.userName(t.who) + ' ' : '') + 'mengetik…')
      : g ? `${g.members.length} anggota` : lastSeenStr(u);
    const dis = this.settings.disappearing[conv];
    h.innerHTML = `
      <button class="icon-btn back" data-act="back" aria-label="Kembali">←</button>
      <button class="head-info" data-act="info">${this.avatarHtml(g ? { displayName: g.name, avatar: g.avatar } : u, u?.online ? 'online' : '')}
        <div><b>${esc(this.convTitle(conv))}</b><small class="${t ? 'typing-txt' : 'muted'}">${esc(sub)}${dis ? ' · ⏳' : ''}</small></div></button>
      <div class="head-actions">
        <button class="icon-btn" data-act="${g ? 'group-call' : 'call'}" data-video="1" aria-label="Video call">${icon('video')}</button>
        <button class="icon-btn" data-act="${g ? 'group-call' : 'call'}" aria-label="Telepon">${icon('phone')}</button>
        <button class="icon-btn" data-act="chat-menu" aria-label="Menu">⋮</button>
      </div>`;
  }

  renderTyping(conv) { if (this.view.conv === conv) this.renderHeader(); if (this.view.tab === 'chats') this.renderList(); }

  refreshConv(conv) {
    if (this.view.conv === conv) { this.renderMessages(); if (document.hasFocus()) this.markRead(conv); }
    if (this.view.tab === 'chats') this.renderList();
    this.renderStatus();
    this.persistCache();
  }

  renderMessages(forceBottom) {
    const el = $('#messages');
    if (!el) return;
    const atBottom = forceBottom || el.scrollHeight - el.scrollTop - el.clientHeight < 120;
    const list = this.convMessages(this.view.conv);
    const me = this.state.me.id;
    const g = this.state.groups[this.view.conv];
    let lastDay = '';
    let html = `<div class="sys-note">🔒 Pesan dikirim lewat koneksi terenkripsi (TLS). ${this.settings.antiDelete ? '🛡️ Anti-Hapus aktif.' : ''}</div>`;
    for (const m of list) {
      const d = dayStr(m.ts);
      if (d !== lastDay) { html += `<div class="day"><span>${d}</span></div>`; lastDay = d; }
      html += this.bubbleHtml(m, m.from === me, g);
    }
    el.innerHTML = html;
    el.querySelectorAll('video[data-src],audio[data-src]').forEach((v) => { v.src = v.dataset.src; });
    if (atBottom) el.scrollTop = el.scrollHeight;
  }

  bubbleHtml(m, out, group) {
    const anti = m.deleted && !out && this.settings.antiDelete;
    if (m.deleted && !anti) {
      return `<div class="msg ${out ? 'out' : 'in'}" data-id="${m.id}"><div class="bubble deleted"><i>🚫 ${out ? 'Kamu menghapus pesan ini' : 'Pesan ini telah dihapus'}</i><span class="meta">${timeStr(m.ts)}</span></div></div>`;
    }
    const reply = m.replyTo ? this.findMsg(m.replyTo) : null;
    const reacts = Object.values(m.reactions || {});
    const rc = {}; for (const r of reacts) rc[r] = (rc[r] || 0) + 1;
    const viewed = this.settings['viewed:' + m.id];
    let body = '';
    if (m.viewOnce && !out) {
      body = viewed ? '<i class="muted">👁 Media sekali lihat sudah dibuka</i>' : `<button class="chip" data-act="view-once" data-id="${m.id}">👁 Buka media sekali lihat</button>`;
    } else {
      const src = esc(this.media(m.media?.url));
      if (m.kind === 'image') body = src ? `<img class="media" src="${src}" alt="foto" loading="lazy" data-act="zoom">` : this.progressHtml(m);
      else if (m.kind === 'video') body = src ? `<video class="media" data-src="${src}" controls playsinline preload="metadata"></video>` : this.progressHtml(m);
      else if (m.kind === 'audio' || m.kind === 'voice') body = src ? `<div class="audio">${m.kind === 'voice' ? '🎤' : '🎵'}<audio data-src="${src}" controls preload="metadata"></audio></div>` : this.progressHtml(m);
      else if (m.kind === 'doc') body = `<a class="doc" ${src ? `href="${src}" download="${esc(m.media?.name)}" target="_blank" rel="noopener"` : ''}><span>📄</span><div><b>${esc(m.media?.name || 'Dokumen')}</b><small>${fmtSize(m.media?.size)}</small></div></a>${src ? '' : this.progressHtml(m)}`;
      else if (m.kind === 'sticker') body = `<div class="sticker">${esc(m.text)}</div>`;
      if (m.kind !== 'sticker' && m.text) body += `<div class="text">${linkify(esc(m.text))}</div>`;
    }
    return `<div class="msg ${out ? 'out' : 'in'} ${m.kind === 'sticker' ? 'is-sticker' : ''}" data-id="${m.id}">
      <div class="bubble ${anti ? 'anti' : ''}" data-act="msg-menu" data-id="${m.id}">
        ${group && !out ? `<b class="sender" style="--h:${hue(m.from)}">${esc(this.userName(m.from))}</b>` : ''}
        ${m.forwarded ? '<small class="muted">↪ Diteruskan</small>' : ''}
        ${anti ? '<small class="anti-tag">🛡️ Dihapus pengirim · tersimpan Anti-Hapus</small>' : ''}
        ${reply ? `<div class="quote"><b>${esc(this.userName(reply.from))}</b><span>${esc(this.preview(reply)).slice(0, 90)}</span></div>` : ''}
        ${body}
        <span class="meta">${m.expiresAt ? '⏳ ' : ''}${m.edits?.length ? 'diedit · ' : ''}${m.offline ? '📡 ' : ''}${timeStr(m.ts)} ${out ? `<span class="tick ${m.status}">${tickText(m)}</span>` : ''}</span>
      </div>
      ${reacts.length ? `<div class="reacts">${Object.entries(rc).map(([e, n]) => `${e}${n > 1 ? n : ''}`).join(' ')}</div>` : ''}
    </div>`;
  }
  progressHtml(m) { return `<div class="progress" data-prog="${m.id}"><div style="width:${Math.round((m.progress || 0) * 100)}%"></div><small>${m.pending ? 'Mengunggah…' : 'Media'}</small></div>`; }
  updateProgress(m) { const p = document.querySelector(`[data-prog="${m.id}"] div`); if (p) p.style.width = Math.round(m.progress * 100) + '%'; }

  sendTyping(mode = 'text') {
    const now = Date.now();
    if (now - (this.typingSent || 0) > 3000) { this.send({ t: 'typing', to: this.view.conv, on: true, mode }); this.typingSent = now; }
    clearTimeout(this.typingT);
    this.typingT = setTimeout(() => { this.send({ t: 'typing', to: this.view.conv, on: false }); this.typingSent = 0; }, 4000);
  }

  async submit() {
    const input = $('#input');
    const text = input.value;
    const conv = this.view.conv;
    if (!text.trim()) return this.toggleRecord();
    if (this.editing) {
      this.send({ t: 'edit', id: this.editing, text });
      const m = this.findMsg(this.editing); if (m) { m.edits = [...(m.edits || []), { text: m.text }]; m.text = text; }
      this.editing = null; input.value = ''; this.renderReplyBar(); this.renderMessages(); return;
    }
    input.value = ''; input.style.height = 'auto'; $('#send-btn').innerHTML = micIcon();
    const out = await this.ext.transformOutgoing(text, conv);
    if (out == null) return;
    this.sendMessage(conv, { kind: 'text', text: out, replyTo: this.replyTo });
    this.replyTo = null; this.renderReplyBar();
    $('#smart').innerHTML = '';
  }

  fillComposer(conv, text) { if (this.view.conv === conv && $('#input')) { $('#input').value = text; $('#input').dispatchEvent(new Event('input')); } }

  async loadSmartReplies() {
    const conv = this.view.conv;
    const list = this.convMessages(conv);
    const last = list[list.length - 1];
    const el = $('#smart');
    if (!el || !last || last.from === this.state.me.id || last.kind !== 'text' || this.settings.airplane) return;
    try {
      const ctxText = list.slice(-12).map((m) => `${this.userName(m.from)}: ${m.text}`).join('\n');
      const r = await this.api('/api/ai/reply', { context: ctxText, text: last.text });
      if (this.view.conv !== conv) return;
      el.innerHTML = `<span class="tiny muted">✨ ${r.source === 'ai' ? 'AI' : 'Saran'}</span>` + r.replies.map((x) => `<button class="chip" data-act="smart" data-text="${esc(x)}">${esc(x)}</button>`).join('');
    } catch { /* */ }
  }

  renderReplyBar() {
    const el = $('#reply-bar');
    if (!el) return;
    const id = this.replyTo || this.editing;
    if (!id) { el.innerHTML = ''; return; }
    const m = this.findMsg(id);
    el.innerHTML = `<div class="reply-bar glass"><div><b>${this.editing ? '✏️ Edit pesan' : '↩ Membalas ' + esc(this.userName(m?.from))}</b><span class="ellipsis">${esc(this.preview(m))}</span></div><button class="icon-btn" data-act="cancel-reply">✕</button></div>`;
  }

  // ---------- voice notes ----------
  async toggleRecord() {
    if (this.rec) { this.rec.stop(); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { noiseSuppression: true, echoCancellation: true } });
      const chunks = [];
      const r = new MediaRecorder(stream);
      this.rec = r;
      const started = Date.now();
      const bar = $('#reply-bar');
      const tick = setInterval(() => { bar.innerHTML = `<div class="reply-bar glass rec"><span class="rec-dot"></span><b>Merekam ${fmt(Math.round((Date.now() - started) / 1000))}</b><button class="chip" data-act="rec-cancel">Batal</button><button class="chip ok" data-act="send">Kirim ➤</button></div>`; this.sendTyping('voice'); }, 300);
      r.ondataavailable = (e) => chunks.push(e.data);
      r.onstop = () => {
        clearInterval(tick); stream.getTracks().forEach((t) => t.stop()); bar.innerHTML = ''; this.rec = null;
        if (this.recCancelled) { this.recCancelled = false; return; }
        const blob = new Blob(chunks, { type: r.mimeType || 'audio/webm' });
        const file = new File([blob], `voice-${Date.now()}.${(r.mimeType || '').includes('mp4') ? 'm4a' : 'webm'}`, { type: blob.type });
        this.sendMessage(this.view.conv, { kind: 'voice', media: { url: null } }, file);
      };
      r.start();
    } catch { this.toast('Izin mikrofon diperlukan untuk pesan suara'); }
  }

  // ---------- attachments (gallery) ----------
  attachMenu() {
    const b = this.dialog('Lampirkan', `
      <div class="attach-grid">
        <button data-act="pick" data-accept="image/*,video/*" data-multi="1"><span style="--h:280">🖼️</span>Galeri</button>
        <button data-act="pick" data-accept="image/*" data-capture="environment"><span style="--h:330">📷</span>Kamera</button>
        <button data-act="pick" data-accept="video/*" data-capture="environment"><span style="--h:10">🎥</span>Rekam video</button>
        <button data-act="pick" data-accept="audio/*" data-multi="1"><span style="--h:30">🎵</span>Audio</button>
        <button data-act="pick" data-accept="*/*" data-multi="1"><span style="--h:200">📄</span>Dokumen</button>
        <button data-act="pick" data-accept="image/*,video/*" data-once="1"><span style="--h:160">👁️</span>Sekali lihat</button>
      </div>
      <input class="input" id="attach-caption" placeholder="Keterangan (opsional)">`);
    return b;
  }
  pickFiles(btn) {
    const i = Object.assign(document.createElement('input'), { type: 'file', accept: btn.dataset.accept, multiple: !!btn.dataset.multi });
    if (btn.dataset.capture) i.capture = btn.dataset.capture;
    const caption = $('#attach-caption')?.value || '';
    const once = !!btn.dataset.once;
    i.onchange = () => {
      const conv = this.view.conv;
      [...i.files].forEach((f, idx) => {
        const kind = f.type.startsWith('image/') ? 'image' : f.type.startsWith('video/') ? 'video' : f.type.startsWith('audio/') ? 'audio' : 'doc';
        if (kind === 'doc' && btn.dataset.accept !== '*/*') return;
        this.sendMessage(conv, { kind, text: idx === 0 ? caption : '', viewOnce: once, media: { url: null, name: f.name, size: f.size } }, f);
      });
      this.closeDialog();
    };
    i.click();
  }

  // ---------- message menu ----------
  messageMenu(id) {
    const m = this.findMsg(id);
    if (!m) return;
    const out = m.from === this.state.me.id;
    const canEdit = out && m.kind === 'text' && !m.deleted && Date.now() - m.ts < 15 * 60e3;
    this.dialog('Pesan', `
      <div class="react-row">${['❤️', '😂', '👍', '😮', '😢', '🙏', '🔥', '🥹'].map((e) => `<button data-act="react" data-id="${id}" data-emoji="${e}" aria-label="${emojiName(e)}">${e}</button>`).join('')}</div>
      <div class="menu">
        <button data-act="reply" data-id="${id}">↩ Balas</button>
        ${m.text ? `<button data-act="copy" data-id="${id}">📋 Salin</button>` : ''}
        <button data-act="forward" data-id="${id}">↪ Teruskan</button>
        <button data-act="speak" data-id="${id}">🔊 Bacakan</button>
        <button data-act="to-wa" data-id="${id}">🟢 Kirim ke WhatsApp</button>
        ${canEdit ? `<button data-act="edit" data-id="${id}">✏️ Edit</button>` : ''}
        ${m.edits?.length ? `<button data-act="history" data-id="${id}">🕓 Riwayat edit (${m.edits.length})</button>` : ''}
        <button data-act="del-me" data-id="${id}">🗑️ Hapus untuk saya</button>
        ${out && !m.deleted ? `<button class="danger" data-act="del-all" data-id="${id}">🗑️ Hapus untuk semua</button>` : ''}
        <button data-act="msg-info" data-id="${id}">ℹ️ Info</button>
      </div>`);
  }

  forwardMenu(id) {
    const convs = this.conversations();
    this.dialog('Teruskan ke…', `<div class="pick-list">${convs.map((c) => `<button class="conv" data-act="do-forward" data-id="${id}" data-to="${c.id}">${this.avatarHtml(this.state.groups[c.id] ? { displayName: this.state.groups[c.id].name } : this.state.users[c.id])}<b>${esc(this.convTitle(c.id))}</b></button>`).join('')}</div>`);
  }

  chatMenu() {
    const conv = this.view.conv;
    const g = this.state.groups[conv];
    const u = this.state.users[conv];
    const dis = this.settings.disappearing[conv] || 0;
    this.dialog(esc(this.convTitle(conv)), `<div class="menu">
      <button data-act="info">ℹ️ Info ${g ? 'grup' : 'kontak'}</button>
      <button data-act="wallpaper">🖼️ Tema & wallpaper chat</button>
      <button data-act="find">🔎 Cari di chat</button>
      <button data-act="toggle-pin">${this.settings.pinned[conv] ? '📌 Lepas sematan' : '📌 Sematkan chat'}</button>
      <button data-act="toggle-mute">${this.settings.muted[conv] ? '🔔 Bunyikan' : '🔕 Bisukan notifikasi'}</button>
      <label class="menu-row">⏳ Pesan sementara <select data-act="disappear">${[[0, 'Mati'], [86400, '24 jam'], [604800, '7 hari'], [7776000, '90 hari']].map(([v, n]) => `<option value="${v}" ${dis === v ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
      ${!g ? `<button data-act="wa-chat">🟢 Lanjutkan di WhatsApp${u?.waNumber ? '' : ' (bagikan teks)'}</button>` : ''}
      <button data-act="export">💾 Ekspor chat (.txt)</button>
      <button data-act="clear">🧹 Bersihkan chat (di perangkat ini)</button>
      ${!g ? `<button class="danger" data-act="block">${this.isBlocked(conv) ? '✅ Buka blokir' : '⛔ Blokir'}</button>` : ''}
    </div>`);
  }

  async wallpaperMenu() {
    const conv = this.view.conv;
    const presets = ['none', 'radial-gradient(circle at 20% 20%,#7c3aed55,transparent 40%),radial-gradient(circle at 80% 70%,#06b6d455,transparent 45%)',
      'linear-gradient(160deg,#0f172a,#312e81)', 'linear-gradient(160deg,#1e1b4b,#831843)', 'repeating-linear-gradient(45deg,#ffffff08 0 12px,transparent 12px 24px)',
      'radial-gradient(#ffffff14 1px,transparent 1px) 0 0/18px 18px', 'linear-gradient(160deg,#022c22,#064e3b)', 'conic-gradient(from 200deg at 70% 30%,#f472b633,#60a5fa33,#a78bfa33,#f472b633)'];
    this.dialog('🖼️ Wallpaper chat', `
      <div class="wall-grid">${presets.map((p, i) => `<button class="wall" data-act="wall-preset" data-i="${i}" style="background:${p === 'none' ? 'var(--bg2)' : p}">${p === 'none' ? 'Polos' : ''}</button>`).join('')}</div>
      <div class="row"><button class="btn" data-act="wall-gallery">📁 Pilih dari galeri (chat ini)</button><button class="btn ghost" data-act="wall-gallery-all">📁 Galeri (semua chat)</button></div>
      <button class="btn ghost" data-act="wall-reset">↺ Reset wallpaper</button>`);
    this.wallPresets = presets;
    this.wallConv = conv;
  }

  infoPanel() {
    const conv = this.view.conv;
    const g = this.state.groups[conv];
    if (g) {
      const isAdmin = g.admins.includes(this.state.me.id);
      this.dialog('Info grup', `<div class="profile">${this.avatarHtml({ displayName: g.name, avatar: g.avatar }, 'xl')}<h2>${esc(g.name)}</h2><p class="muted">${g.members.length} anggota · maks 1024</p></div>
        <div class="row"><button class="btn" data-act="group-call">📞 Telepon grup</button><button class="btn" data-act="group-call" data-video="1">📹 Video grup</button></div>
        ${isAdmin ? '<button class="btn ghost" data-act="group-add">＋ Tambah anggota</button>' : ''}
        <div class="pick-list">${g.members.map((id) => `<div class="conv">${this.avatarHtml(this.state.users[id])}<b>${esc(this.userName(id))}</b>${g.admins.includes(id) ? '<span class="chip">admin</span>' : ''}</div>`).join('')}</div>`);
    } else {
      const u = this.state.users[conv] || {};
      this.dialog('Info kontak', `<div class="profile">${this.avatarHtml(u, 'xl')}<h2>${esc(u.displayName)}</h2><p class="muted">@${esc(u.username)}</p><p>${esc(u.about)}</p><p class="muted tiny">${esc(lastSeenStr(u))}</p></div>
        <p class="chip ok">🛡️ Nomor HP disembunyikan — anti pelacakan</p>
        <div class="row"><button class="btn" data-act="call">📞</button><button class="btn" data-act="call" data-video="1">📹</button>${u.waNumber ? '<button class="btn ghost" data-act="wa-chat">🟢 WhatsApp</button>' : ''}</div>`);
    }
  }

  offerWhatsAppFallback(peer, video) {
    const u = this.state.users[peer];
    this.dialog('Pengguna offline', `<p>${esc(this.userName(peer))} sedang tidak online di Novalink.</p>
      <div class="menu"><button data-act="leave-msg" data-to="${peer}">💬 Tinggalkan pesan</button>
      ${u?.waNumber ? `<a class="btn" href="https://wa.me/${esc(u.waNumber.replace(/\D/g, ''))}" target="_blank" rel="noopener">🟢 Hubungi lewat WhatsApp</a>` : '<p class="muted tiny">Kontak ini belum membagikan nomor WhatsApp.</p>'}</div>`);
  }

  // ================= new chat / group =================
  newChatDialog() {
    const b = this.dialog('Chat baru', `
      <input class="input" id="user-q" placeholder="Cari @username…" autocapitalize="none">
      <div id="user-results" class="pick-list"></div>
      <div class="row"><button class="chip" data-act="new-group">👥 Grup baru</button><button class="chip" data-act="share-me">🔗 Bagikan link profilku</button><button class="chip" data-act="invite-wa">🟢 Undang via WhatsApp</button></div>
      <details><summary class="muted">Cari dengan nomor HP (terbatas, anti-pelacakan)</summary><div class="row"><input class="input" id="phone-q" type="tel" placeholder="+62…"><button class="btn" data-act="phone-search">Cari</button></div><p class="tiny muted">Hanya menemukan pengguna yang mengizinkan. Maks 5 pencarian/jam.</p></details>`);
    const q = b.querySelector('#user-q');
    let t;
    q.oninput = () => {
      clearTimeout(t);
      t = setTimeout(async () => {
        const res = q.value.length >= 3 ? await this.api('/api/users/search?q=' + encodeURIComponent(q.value)).catch((e) => { this.toast(e.message); return []; }) : [];
        b.querySelector('#user-results').innerHTML = res.map((u) => `<button class="conv" data-act="add-contact" data-id="${u.id}">${this.avatarHtml(u)}<div><b>${esc(u.displayName)}</b><small class="muted">@${esc(u.username)}</small></div></button>`).join('') || (q.value.length >= 3 ? '<p class="muted">Tidak ditemukan</p>' : '');
      }, 300);
    };
    q.focus();
  }

  newGroupDialog(addTo) {
    const contacts = Object.values(this.state.users).filter((u) => u.id !== this.state.me.id);
    this.dialog(addTo ? 'Tambah anggota' : '👥 Grup baru', `
      ${addTo ? '' : '<input class="input" id="group-name" placeholder="Nama grup" maxlength="50">'}
      <p class="tiny muted">Grup bisa sampai 1024 anggota. Panggilan grup mendukung 20+ peserta (dengan server SFU).</p>
      <div class="pick-list">${contacts.map((u) => `<label class="conv">${this.avatarHtml(u)}<b>${esc(u.displayName)}</b><input type="checkbox" value="${u.id}" class="gm"></label>`).join('') || '<p class="muted">Tambahkan kontak dulu.</p>'}</div>
      <button class="btn full" data-act="${addTo ? 'do-group-add' : 'create-group'}">${addTo ? 'Tambahkan' : 'Buat grup'}</button>`);
  }

  // ================= stories =================
  storiesHtml() {
    const s = this.state;
    const mine = s.stories.filter((x) => x.owner === s.me.id);
    const others = {};
    for (const st of s.stories) if (st.owner !== s.me.id) (others[st.owner] ||= []).push(st);
    const seen = JSON.parse(localStorage.getItem('nl:seen') || '{}');
    return `
      <div class="story-me glass" >
        <button class="conv" data-act="${mine.length ? 'view-story' : 'new-story'}" data-id="${s.me.id}">${this.avatarHtml(s.me, mine.length ? 'ring' : '')}<div><b>Story saya</b><small class="muted">${mine.length ? mine.length + ' story · ' + mine.reduce((a, x) => a + (x.views?.length || 0), 0) + ' dilihat' : 'Ketuk untuk menambah'}</small></div></button>
        <button class="icon-btn accent" data-act="new-story" aria-label="Buat story">＋</button>
      </div>
      <div class="row pad"><button class="chip" data-act="story-link">🔗 Link story publikku</button><button class="chip" data-act="story-wa">🟢 Bagikan ke Status WA</button></div>
      <h4 class="section">Terbaru</h4>
      ${Object.entries(others).map(([owner, list]) => {
        const unseen = list.some((x) => !seen[x.id]);
        const u = s.users[owner];
        return `<button class="conv" data-act="view-story" data-id="${owner}">${this.avatarHtml(u, unseen ? 'ring' : 'ring seen')}<div><b>${esc(u?.displayName || 'Pengguna')}</b><small class="muted">${timeStr(list[list.length - 1].createdAt)} ${list.some((x) => x.audience === 'public') ? '· 🌍 publik' : ''}</small></div></button>`;
      }).join('') || '<p class="muted pad">Belum ada story dari kontak.</p>'}`;
  }

  newStoryDialog() {
    const colors = ['#7c3aed', '#db2777', '#0891b2', '#059669', '#ea580c', '#111827', 'linear-gradient(135deg,#7c3aed,#06b6d4)', 'linear-gradient(135deg,#f43f5e,#f59e0b)'];
    const b = this.dialog('Buat story', `
      <div class="seg"><button class="on" data-act="story-type" data-type="text">Aa Teks</button><button data-act="story-type" data-type="media">🖼️ Foto/Video</button></div>
      <div id="story-form">
        <textarea class="input story-text" id="story-text" maxlength="700" placeholder="Apa yang kamu pikirkan?" style="background:${colors[0]}"></textarea>
        <div class="row">${colors.map((c) => `<button class="swatch" data-act="story-bg" data-bg="${c}" style="background:${c}"></button>`).join('')}</div>
      </div>
      <label class="menu-row">Siapa yang bisa lihat <select id="story-aud"><option value="contacts">👥 Kontak saya</option><option value="public">🌍 Publik (siapa saja + link)</option></select></label>
      <p class="tiny muted">Video story tanpa batas 30 detik — bisa lebih dari 5 menit (maks ukuran file server).</p>
      <button class="btn full" data-act="post-story">Posting story ✦</button>`);
    this.storyDraft = { type: 'text', bg: colors[0] };
    return b;
  }

  async postStory() {
    const d = this.storyDraft;
    const audience = $('#story-aud').value;
    try {
      let body;
      if (d.type === 'text') {
        const text = $('#story-text').value.trim();
        if (!text) return this.toast('Tulis sesuatu dulu');
        body = { type: 'text', text, bg: d.bg, audience };
      } else {
        if (!d.file) return this.toast('Pilih foto/video dulu');
        $('#story-progress').hidden = false;
        const up = await this.upload(d.file, (p) => { const el = $('#story-progress div'); if (el) el.style.width = Math.round(p * 100) + '%'; });
        body = { type: d.file.type.startsWith('video') ? 'video' : 'image', media: up.url, caption: $('#story-caption').value, duration: d.duration, audience };
      }
      const st = await this.api('/api/stories', body);
      this.state.stories = this.state.stories.filter((x) => x.id !== st.id).concat(st);
      this.closeDialog(); this.renderList();
      this.toast(audience === 'public' ? '🌍 Story publik diposting — bagikan linknya ke WhatsApp!' : 'Story diposting ✦');
      if (audience === 'public' && d.file) this.lastStoryFile = d.file;
    } catch (e) { this.toast('Gagal posting story: ' + e.message); }
  }

  storyLink() { return `${this.base}/s/${this.state.me.username}`; }
  async shareStoryToWhatsApp() {
    const link = this.storyLink();
    const text = `Lihat story-ku di Novalink & simpan kontakku ✦ ${link}`;
    const file = this.lastStoryFile;
    if (navigator.canShare && file && navigator.canShare({ files: [file] })) {
      await navigator.share({ files: [file], text }).catch(() => {});
    } else if (navigator.share) await navigator.share({ title: 'Story Novalink', text }).catch(() => {});
    else window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank');
  }

  viewStories(owner) {
    const list = this.state.stories.filter((x) => x.owner === owner).sort((a, b) => a.createdAt - b.createdAt);
    if (!list.length) return this.newStoryDialog();
    const v = $('#story-viewer');
    let i = 0;
    const seen = JSON.parse(localStorage.getItem('nl:seen') || '{}');
    const show = () => {
      clearTimeout(this.storyT);
      const st = list[i];
      if (!st) { v.classList.remove('open'); v.innerHTML = ''; this.renderList(); return; }
      seen[st.id] = 1; localStorage.setItem('nl:seen', JSON.stringify(seen));
      if (owner !== this.state.me.id) this.api(`/api/stories/${st.id}/view`, {}).catch(() => {});
      const u = owner === this.state.me.id ? this.state.me : this.state.users[owner];
      const mine = owner === this.state.me.id;
      v.innerHTML = `
        <div class="bars">${list.map((_, k) => `<div><span style="width:${k < i ? 100 : 0}%" class="${k === i ? 'cur' : ''}"></span></div>`).join('')}</div>
        <div class="story-head">${this.avatarHtml(u)}<b>${esc(u?.displayName)}</b><small>${timeStr(st.createdAt)} ${st.audience === 'public' ? '🌍' : '👥'}</small><button class="icon-btn" data-sv="close">✕</button></div>
        <div class="story-body">${st.type === 'video' ? `<video src="${esc(this.media(st.media))}" autoplay playsinline></video>` : st.type === 'image' ? `<img src="${esc(this.media(st.media))}" alt="">` : `<div class="story-txt" style="background:${esc(st.bg)}">${esc(st.text)}</div>`}
          ${st.caption ? `<p class="story-cap">${esc(st.caption)}</p>` : ''}</div>
        <button class="tap left" data-sv="prev" aria-label="Sebelumnya"></button><button class="tap right" data-sv="next" aria-label="Berikutnya"></button>
        <div class="story-foot">${mine ? `<button class="chip" data-sv="views">👁 ${st.views?.length || 0} dilihat</button><button class="chip" data-sv="share">🟢 Status WA</button><button class="chip" data-sv="del">🗑️</button>`
          : `<form data-sv="reply-form" class="row"><input class="input" name="r" placeholder="Balas story…"><button class="btn">➤</button></form>`}</div>`;
      v.classList.add('open');
      const vid = v.querySelector('video');
      const cur = v.querySelector('.bars .cur');
      const run = (ms) => { if (cur) { cur.style.transition = `width ${ms}ms linear`; requestAnimationFrame(() => { cur.style.width = '100%'; }); } this.storyT = setTimeout(() => { i++; show(); }, ms); };
      if (vid) vid.onloadedmetadata = () => run((vid.duration || 15) * 1000 + 300);
      else run(6000);
    };
    v.onclick = async (e) => {
      const b = e.target.closest('[data-sv]');
      if (!b) return;
      const st = list[i];
      if (b.dataset.sv === 'close') { clearTimeout(this.storyT); v.classList.remove('open'); v.innerHTML = ''; this.renderList(); }
      if (b.dataset.sv === 'next') { i++; show(); }
      if (b.dataset.sv === 'prev') { i = Math.max(0, i - 1); show(); }
      if (b.dataset.sv === 'views') { clearTimeout(this.storyT); this.dialog('Dilihat oleh', (st.views || []).map((x) => `<div class="conv">${this.avatarHtml(this.state.users[x.id])}<b>${esc(this.userName(x.id))}</b><small class="muted">${timeStr(x.at)}</small></div>`).join('') || '<p class="muted">Belum ada</p>'); }
      if (b.dataset.sv === 'share') { clearTimeout(this.storyT); this.shareStoryToWhatsApp(); }
      if (b.dataset.sv === 'del') { await this.api('/api/stories/' + st.id, null, 'DELETE'); this.state.stories = this.state.stories.filter((x) => x.id !== st.id); list.splice(i, 1); show(); }
    };
    v.onsubmit = (e) => {
      e.preventDefault();
      const t = e.target.elements.r.value.trim();
      if (!t) return;
      const st = list[i];
      this.sendText(owner, `💬 Membalas story${st.text ? ` "${st.text.slice(0, 40)}"` : ''}: ${t}`);
      e.target.reset(); this.toast('Balasan terkirim');
    };
    show();
  }

  // ================= calls tab =================
  addCallLog(c) { this.state.callLog.push({ ...c, ts: Date.now() }); this.saveCallLog(); if (this.view.tab === 'calls') this.renderList(); }
  callsHtml() {
    const log = [...this.state.callLog].reverse();
    const missed = log.filter((c) => c.status === 'missed' && !c.reported).length;
    return `
      <div class="row pad"><button class="chip" data-act="call-pick">📞 Panggilan baru</button><button class="chip" data-act="call-pick" data-video="1">📹 Video call</button><button class="chip" data-act="offline">📡 Telepon offline</button></div>
      <button class="nova-card glass" data-act="nova-report"><div class="orb small"></div><div><b>Laporan Nova</b><small class="muted">${missed ? missed + ' panggilan tak terjawab — ketuk untuk dibacakan' : 'Tidak ada panggilan tak terjawab'}</small></div></button>
      <h4 class="section">Riwayat</h4>
      ${log.map((c) => {
        const name = c.group ? this.state.groups[c.group]?.name || 'Grup' : this.userName(c.peer);
        const st = { missed: ['↙', 'red', 'Tak terjawab'], declined: ['✕', 'red', 'Ditolak'], cancelled: ['↗', 'muted', 'Dibatalkan'], 'missed-out': ['↗', 'muted', 'Tidak dijawab'], done: [c.dir === 'in' ? '↙' : '↗', 'green', fmt(c.dur || 0)] }[c.status] || ['•', 'muted', c.status];
        return `<div class="conv">${this.avatarHtml(c.group ? { displayName: name } : this.state.users[c.peer])}<div class="conv-main"><b class="${st[1] === 'red' ? 'red-t' : ''}">${esc(name)}</b><small class="muted"><span class="${st[1]}-t">${st[0]}</span> ${c.video ? '📹' : '📞'} ${dayStr(c.ts)} ${timeStr(c.ts)} · ${st[2]}</small></div>
          ${c.peer && !c.group ? `<button class="icon-btn" data-act="call" data-peer="${c.peer}" ${c.video ? 'data-video="1"' : ''} aria-label="Telepon balik">${icon(c.video ? 'video' : 'phone')}</button>` : ''}</div>`;
      }).join('') || '<p class="muted pad">Belum ada panggilan.</p>'}`;
  }

  // ================= extensions tab =================
  extHtml() {
    const custom = this.settings.customExtensions || [];
    return `<div class="pad"><p class="muted">Tambah kemampuan baru ke Novalink. Ekstensi kustom berjalan di sandbox — tidak bisa membaca akun atau token kamu.</p></div>
      ${BUILTIN.map((e) => `<label class="ext glass"><span class="ext-ico">${e.icon}</span><div><b>${e.name}</b><small class="muted">${e.desc}</small></div><input type="checkbox" class="switch" data-set-ext="${e.id}" ${this.ext.enabled(e.id) ? 'checked' : ''}></label>`).join('')}
      <details class="glass pad-box"><summary>⚡ Atur balasan cepat & balas otomatis</summary>
        ${[0, 1, 2, 3, 4].map((k) => `<input class="input" data-quick="${k}" placeholder="/${k + 1} …" value="${esc(this.settings.quickReplies[k] || '')}">`).join('')}
        <label class="menu-row">🌙 Balas otomatis aktif <input type="checkbox" class="switch" data-set="awayOn" ${this.settings.awayOn ? 'checked' : ''}></label>
        <input class="input" data-set-text="awayText" placeholder="Teks balas otomatis" value="${esc(this.settings.awayText)}">
      </details>
      <h4 class="section">Ekstensi kustom (${custom.length})</h4>
      ${custom.map((e) => `<div class="ext glass"><span class="ext-ico">🧩</span><div><b>${esc(e.name)}</b><small class="muted">${[...(this.ext.custom.get(e.id)?.commands || [])].map((c) => '/' + c).join(' ') || 'sandbox'}</small></div><button class="icon-btn" data-act="ext-remove" data-id="${e.id}" aria-label="Hapus">🗑️</button></div>`).join('')}
      <div class="row pad"><button class="btn" data-act="ext-install">＋ Pasang ekstensi</button><button class="btn ghost" data-act="ext-cmds">📜 Daftar perintah</button></div>`;
  }

  extInstallDialog() {
    this.dialog('Pasang ekstensi', `<input class="input" id="ext-name" placeholder="Nama ekstensi" value="Mainan Seru">
      <textarea class="input code tall" id="ext-code" spellcheck="false">${esc(SAMPLE_EXTENSION)}</textarea>
      <div class="row"><button class="btn ghost" data-act="ext-file">📁 Dari file .js</button><button class="btn" data-act="ext-save">Pasang</button></div>
      <p class="tiny muted">API: nl.command(nama, fn) · nl.onMessage(fn) · nl.send(id, teks) · nl.toast(teks)</p>`, { wide: true });
  }

  // ================= settings =================
  settingsHtml() {
    const s = this.settings;
    const me = this.state.me;
    const sw = (key, label, hint = '') => `<label class="menu-row"><span>${label}${hint ? `<small class="muted">${hint}</small>` : ''}</span><input type="checkbox" class="switch" data-set="${key}" ${s[key] ? 'checked' : ''}></label>`;
    const psw = (key, label, hint = '', def = false) => `<label class="menu-row"><span>${label}${hint ? `<small class="muted">${hint}</small>` : ''}</span><input type="checkbox" class="switch" data-priv="${key}" ${(me.privacy?.[key] ?? def) ? 'checked' : ''}></label>`;
    const sel = (key, label, opts) => `<label class="menu-row"><span>${label}</span><select data-set-sel="${key}">${Object.entries(opts).map(([k, v]) => `<option value="${k}" ${String(s[key]) === String(k) ? 'selected' : ''}>${v}</option>`).join('')}</select></label>`;
    return `
      <button class="profile-card glass" data-act="edit-profile">${this.avatarHtml(me, 'lg')}<div><b>${esc(me.displayName)}</b><small class="muted">@${esc(me.username)} · ${esc(me.about)}</small></div><span>✏️</span></button>
      <details class="set glass"><summary>🎨 Tema & Tampilan</summary>
        <div class="theme-grid">${Object.entries(THEMES).map(([k, t]) => `<button class="theme ${s.theme === k ? 'on' : ''}" data-act="theme" data-theme="${k}" style="background:${t.bg2};color:${t.text}"><i style="background:${t.out.includes('gradient') ? t.out : t.accent}"></i>${t.name}</button>`).join('')}</div>
        <label class="menu-row"><span>Warna aksen</span><input type="color" data-act-color value="${s.accent || THEMES[s.theme].accent}"></label>
        <div class="row"><button class="btn ghost" data-act="app-bg">🖼️ Background aplikasi dari galeri</button><button class="btn ghost" data-act="app-bg-reset">↺</button></div>
        <div class="row"><button class="btn ghost" data-act="wall-gallery-all">💬 Wallpaper semua chat dari galeri</button></div>
        <label class="menu-row"><span>Redupkan background</span><input type="range" min="0" max="0.9" step="0.05" value="${s.dim}" data-range="dim"></label>
      </details>
      <details class="set glass"><summary>🔔 Notifikasi & Nada Dering</summary>
        ${sel('ringtone', '📞 Nada dering', { ...Object.fromEntries(Object.entries(RINGTONES).map(([k, v]) => [k, v.name])), custom: '🎵 Dari galeri…' })}
        <div class="row"><button class="chip" data-act="preview-ring">▶️ Coba nada dering</button><button class="chip" data-act="custom-ring">📁 Nada dering dari galeri</button></div>
        ${sel('msgSound', '💬 Suara pesan', Object.fromEntries(Object.entries(SFX).map(([k, v]) => [k, v.name])))}
        ${sel('groupSound', '👥 Suara grup', Object.fromEntries(Object.entries(SFX).map(([k, v]) => [k, v.name])))}
        <div class="sfx-grid">${Object.entries(SFX).filter(([k]) => k !== 'none').map(([k, v]) => `<button class="chip" data-act="sfx" data-sfx="${k}">${v.name}</button>`).join('')}</div>
        <button class="btn ghost" data-act="notif-perm">Izinkan notifikasi sistem</button>
      </details>
      <details class="set glass"><summary>🛡️ Privasi & Anti-Pelacakan</summary>
        ${sw('antiDelete', '🛡️ Anti-Hapus pesan', 'Pesan yang dihapus pengirim tetap bisa kamu lihat')}
        ${sw('hideIp', '🕶️ Lindungi IP saat telepon', this.state.ice?.relayAvailable ? 'Semua panggilan lewat relay TURN — IP tidak terlihat' : 'Server belum punya TURN; aktifkan di server untuk perlindungan penuh')}
        ${psw('readReceipts', '✓✓ Laporan dibaca', '', true)}
        <label class="menu-row"><span>👁 Terakhir dilihat</span><select data-priv-sel="lastSeen">${[['all', 'Semua'], ['contacts', 'Kontak'], ['nobody', 'Tidak ada']].map(([k, v]) => `<option value="${k}" ${(me.privacy?.lastSeen || 'contacts') === k ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
        <label class="menu-row"><span>🔎 Bisa dicari lewat username</span><input type="checkbox" class="switch" data-me="discoverable" ${me.discoverable !== false ? 'checked' : ''}></label>
        ${psw('findByPhone', '📵 Boleh ditemukan via nomor HP', 'Mati = nomor HP tidak bisa dipakai untuk melacakmu')}
        ${psw('shareWhatsApp', '🟢 Tampilkan nomor WhatsApp ke kontak', 'Untuk "Lanjutkan di WhatsApp" & story publik')}
        <label class="menu-row"><span>No. WhatsApp</span><input class="input sm" data-me-text="waNumber" placeholder="62812…" value="${esc(me.waNumber || '')}"></label>
        <button class="btn ghost" data-act="blocked">⛔ Daftar blokir (${(me.blocked || []).length})</button>
      </details>
      <details class="set glass"><summary>✈️ Mode Pesawat</summary>
        ${sw('airplane', 'Mode pesawat Novalink', 'Putus dari jaringan: tidak ada pesan/panggilan masuk')}
        ${sel('autoAirplaneMin', 'Otomatis aktif saat tidak dipakai', { 0: 'Mati', 5: '5 menit', 15: '15 menit', 30: '30 menit', 60: '1 jam', 240: '4 jam' })}
        <p class="tiny muted">Pesan yang kamu tulis saat mode pesawat masuk antrean & terkirim otomatis setelah dimatikan.</p>
      </details>
      <details class="set glass"><summary>🤖 Asisten AI Nova</summary>
        ${sw('assistant', 'Aktifkan Nova')}
        ${sw('announceCalls', '📞 Laporkan panggilan masuk (suara)')}
        ${sw('handsFree', '🎙️ Angkat/tolak telepon dengan perintah suara')}
        ${sw('announceMessages', '💬 Bacakan pesan masuk & tawarkan balas suara')}
        ${sw('voiceCheck', '🗣️ Periksa suara sebelum kirim dikte')}
        ${sw('assistantVoice', '🔊 Nova berbicara')}
        <div class="row"><button class="chip" data-act="nova">🎙️ Coba perintah</button><button class="chip" data-act="nova-report">📋 Laporan panggilan</button><button class="chip" data-act="nova-read">📨 Bacakan pesan baru</button></div>
        <p class="tiny muted">${this.assistant.supported.listen ? '✅ Pengenalan suara didukung' : '⚠️ Browser ini belum mendukung pengenalan suara (pakai Chrome Android)'}</p>
      </details>
      <details class="set glass"><summary>🎧 Panggilan & Audio</summary>
        ${sw('noiseSuppression', '🎚️ Peredam kebisingan', 'Noise gate adaptif + filter + peredam bawaan')}
        ${sel('voiceEffect', '🎭 Pengubah suara default', VOICE_EFFECTS)}
        ${sw('preferSfu', '👥 Pakai server SFU untuk semua grup call', this.state.livekit ? 'SFU tersedia — 20+ peserta lancar' : 'Server SFU belum dikonfigurasi')}
        <button class="btn ghost" data-act="voice-test">🎤 Tes pengubah suara</button>
      </details>
      <details class="set glass"><summary>♿ Aksesibilitas</summary>
        ${sw('readEmoji', '🔊 Bacakan emoji di keyboard', 'Ketuk emoji untuk mendengar namanya')}
        ${sw('highContrast', '◐ Kontras tinggi')}
        <label class="menu-row"><span>Ukuran teks</span><input type="range" min="0.85" max="1.4" step="0.05" value="${s.fontScale}" data-range="fontScale"></label>
        ${sw('enterSend', '⏎ Enter untuk kirim (keyboard fisik)')}
      </details>
      <details class="set glass"><summary>📡 Offline & Data</summary>
        <button class="btn ghost" data-act="offline">📡 Mode Offline (chat/telepon tanpa internet)</button>
        <p class="tiny muted">Antrean offline: ${this.state.outbox.length} pesan. Chat tersimpan di perangkat untuk dibaca tanpa internet.</p>
        <div class="row"><button class="btn ghost" data-act="backup">💾 Backup lokal</button><button class="btn ghost" data-act="restore">📥 Pulihkan</button></div>
        ${this.installPrompt ? '<button class="btn" data-act="install">⬇️ Pasang aplikasi</button>' : ''}
      </details>
      <details class="set glass"><summary>ℹ️ Tentang</summary>
        <p><b>${APP_NAME} By Natan</b> v1.0.0</p><p class="muted tiny">Server: ${esc(this.base)} · ${this.state.online ? '🟢 online' : '🔴 offline'}</p>
        <button class="btn red" data-act="logout">Keluar</button>
      </details>`;
  }

  editProfileDialog() {
    const me = this.state.me;
    this.dialog('Edit profil', `<div class="profile"><button data-act="avatar" class="avatar-edit">${this.avatarHtml(me, 'xl')}<span>📷</span></button></div>
      <input class="input" id="p-name" value="${esc(me.displayName)}" maxlength="40" placeholder="Nama">
      <input class="input" id="p-about" value="${esc(me.about)}" maxlength="140" placeholder="Tentang">
      <button class="btn full" data-act="save-profile">Simpan</button>`);
  }

  async voiceTest() {
    const { AudioPipeline } = await import('./audiofx.js');
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true });
      const p = await new AudioPipeline(s).init();
      p.setEffect(this.settings.voiceEffect);
      const mon = new Audio(); mon.srcObject = p.dest.stream; mon.play();
      const b = this.dialog('🎤 Tes suara', `<p class="muted">Bicara sekarang — pakai headset agar tidak berdengung.</p><select class="input" id="vt-fx">${Object.entries(VOICE_EFFECTS).map(([k, v]) => `<option value="${k}" ${this.settings.voiceEffect === k ? 'selected' : ''}>${v}</option>`).join('')}</select><div class="meter"><div id="vt-meter"></div></div><button class="btn full" data-act="close-dialog">Selesai</button>`);
      b.querySelector('#vt-fx').onchange = (e) => p.setEffect(e.target.value);
      const iv = setInterval(() => { const m = $('#vt-meter'); if (!m) { clearInterval(iv); mon.pause(); p.destroy(); return; } m.style.width = Math.min(100, p.level() * 160) + '%'; }, 80);
    } catch { this.toast('Izin mikrofon diperlukan'); }
  }

  // ================= emoji keyboard =================
  renderEmojiPanel() {
    const el = $('#emoji-panel');
    if (!el) return;
    el.hidden = !el.hidden;
    if (el.hidden) return;
    const groups = Object.keys(EMOJI_GROUPS);
    const cur = this.emojiTab || groups[0];
    el.innerHTML = `<div class="emoji-tabs">${groups.map((g) => `<button class="${g === cur ? 'on' : ''}" data-act="emoji-tab" data-g="${g}">${Object.keys(EMOJI_GROUPS[g])[0]}<small>${g}</small></button>`).join('')}</div>
      <div class="emoji-grid">${Object.entries(EMOJI_GROUPS[cur]).map(([e, n]) => `<button data-act="emoji-pick" data-e="${e}" aria-label="${esc(n)}" title="${esc(n)}">${e}</button>`).join('')}</div>
      ${this.settings.readEmoji ? '<p class="tiny muted">🔊 Mode baca emoji aktif</p>' : ''}`;
  }
  speak(text) {
    if (window.NovaNative?.speak) { window.NovaNative.speak(speakableText(text), 1.0); return; }
    if (!('speechSynthesis' in window)) return;
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(speakableText(text)); u.lang = 'id-ID'; speechSynthesis.speak(u);
  }

  // ================= global event delegation =================
  bindGlobal() {
    if (this.bound) return;
    this.bound = true;
    document.addEventListener('click', (e) => this.onClick(e));
    document.addEventListener('change', (e) => this.onChange(e));
    document.addEventListener('input', (e) => {
      if (e.target.id === 'search') this.renderList();
      if (e.target.dataset.range) { this.settings[e.target.dataset.range] = Number(e.target.value); this.saveSettings(); this.applyTheme(); }
    });
    document.addEventListener('contextmenu', (e) => { const b = e.target.closest('.bubble[data-id]'); if (b) { e.preventDefault(); this.messageMenu(b.dataset.id); } });
    window.addEventListener('popstate', () => { if (this.view.conv) this.closeChat(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { if ($('#dialog').classList.contains('open')) this.closeDialog(); else if (this.view.conv) this.closeChat(); } });
  }

  async onClick(e) {
    const b = e.target.closest('[data-act]');
    if (e.target.id === 'dialog') return this.closeDialog();
    if (!b) return;
    const a = b.dataset.act;
    const id = b.dataset.id;
    const conv = this.view.conv;
    const s = this.settings;
    switch (a) {
      case 'auth-mode': return this.renderAuth(b.dataset.mode);
      case 'tab': return this.setTab(b.dataset.tab);
      case 'open': this.closeDialog(); return this.openChat(id);
      case 'back': return this.closeChat();
      case 'close-dialog': return this.closeDialog();
      case 'send': if (this.rec) return this.rec.stop(); return this.submit();
      case 'emoji': return this.renderEmojiPanel();
      case 'emoji-tab': this.emojiTab = b.dataset.g; $('#emoji-panel').hidden = true; return this.renderEmojiPanel();
      case 'emoji-pick': {
        const inp = $('#input'); const em = b.dataset.e;
        const p = inp.selectionStart ?? inp.value.length;
        inp.value = inp.value.slice(0, p) + em + inp.value.slice(p); inp.dispatchEvent(new Event('input'));
        if (s.readEmoji) this.speak(emojiName(em));
        return;
      }
      case 'attach': return this.attachMenu();
      case 'pick': return this.pickFiles(b);
      case 'dictate': return this.assistant.dictateReply(conv);
      case 'smart': $('#input').value = b.dataset.text; $('#input').dispatchEvent(new Event('input')); $('#input').focus(); return;
      case 'rec-cancel': this.recCancelled = true; return this.rec?.stop();
      case 'msg-menu': if (e.target.closest('a,video,audio,button:not([data-act="msg-menu"])')) return; return this.messageMenu(id);
      case 'react': { const m = this.findMsg(id); const cur = m.reactions?.[this.state.me.id]; this.send({ t: 'react', id, emoji: cur === b.dataset.emoji ? null : b.dataset.emoji }); this.closeDialog(); return; }
      case 'reply': this.replyTo = id; this.editing = null; this.closeDialog(); this.renderReplyBar(); return $('#input').focus();
      case 'edit': { this.editing = id; this.replyTo = null; this.closeDialog(); this.renderReplyBar(); const i = $('#input'); i.value = this.findMsg(id).text; i.focus(); return; }
      case 'history': { const m = this.findMsg(id); return this.dialog('Riwayat edit', m.edits.map((x) => `<div class="bubble in"><span>${esc(x.text)}</span></div>`).join('') + `<div class="bubble out"><span>${esc(m.text)}</span><small> (sekarang)</small></div>`); }
      case 'cancel-reply': this.replyTo = null; this.editing = null; return this.renderReplyBar();
      case 'copy': await navigator.clipboard.writeText(this.findMsg(id).text).catch(() => {}); this.closeDialog(); return this.toast('Disalin');
      case 'speak': this.closeDialog(); return this.speak(`${this.userName(this.findMsg(id).from)}: ${this.preview(this.findMsg(id))}`);
      case 'forward': return this.forwardMenu(id);
      case 'do-forward': { const m = this.findMsg(id); this.sendMessage(b.dataset.to, { kind: m.kind, text: m.text, media: m.media, forwarded: true }); this.closeDialog(); return this.toast('Diteruskan ↪'); }
      case 'to-wa': { const m = this.findMsg(id); this.closeDialog(); const t = m.text || this.media(m.media?.url); const u = this.state.users[conv]; return window.open(`https://wa.me/${u?.waNumber ? u.waNumber.replace(/\D/g, '') : ''}?text=${encodeURIComponent(t)}`, '_blank'); }
      case 'del-me': s.hidden[id] = 1; this.saveSettings(); this.closeDialog(); return this.renderMessages();
      case 'del-all': this.send({ t: 'delete', id }); { const m = this.findMsg(id); if (m) m.deleted = true; } this.closeDialog(); return this.renderMessages();
      case 'msg-info': { const m = this.findMsg(id); return this.dialog('Info pesan', `<p>Dikirim: ${new Date(m.ts).toLocaleString('id-ID')}</p><p>Status: ${tickText(m)} ${m.status}</p>${m.deleted ? `<p>Dihapus: ${new Date(m.deletedAt || m.ts).toLocaleString('id-ID')}</p>` : ''}${m.offline ? '<p>📡 Dikirim saat offline (antrean)</p>' : ''}`); }
      case 'view-once': { const m = this.findMsg(id); s['viewed:' + id] = 1; this.saveSettings(); this.dialog('👁 Sekali lihat', m.kind === 'video' ? `<video class="media" src="${esc(this.media(m.media?.url))}" autoplay controls playsinline></video>` : `<img class="media" src="${esc(this.media(m.media?.url))}" alt="">`); return this.renderMessages(); }
      case 'zoom': return this.dialog('Foto', `<img class="media full" src="${b.src}" alt="">`, { wide: true });
      case 'call': this.closeDialog(); return this.calls.start(b.dataset.peer || conv, !!b.dataset.video);
      case 'group-call': this.closeDialog(); return this.calls.startGroup(conv, !!b.dataset.video);
      case 'call-pick': return this.dialog('Pilih kontak', `<div class="pick-list">${Object.values(this.state.users).filter((u) => u.id !== this.state.me.id).map((u) => `<button class="conv" data-act="call" data-peer="${u.id}" ${b.dataset.video ? 'data-video="1"' : ''}>${this.avatarHtml(u)}<b>${esc(u.displayName)}</b></button>`).join('') || '<p class="muted">Belum ada kontak</p>'}</div>`);
      case 'chat-menu': return this.chatMenu();
      case 'info': return this.infoPanel();
      case 'wallpaper': return this.wallpaperMenu();
      case 'wall-preset': s['wallPreset:' + (this.wallConv || '*')] = this.wallPresets[b.dataset.i] === 'none' ? '' : this.wallPresets[b.dataset.i]; await idb.del('wall:' + (this.wallConv || '*')); this.saveSettings(); this.closeDialog(); return this.renderPane();
      case 'wall-gallery': return this.pickImage(async (f) => { await idb.set('wall:' + conv, f); this.closeDialog(); this.renderPane(); this.toast('Wallpaper chat diganti'); });
      case 'wall-gallery-all': return this.pickImage(async (f) => { await idb.set('wall:*', f); this.closeDialog(); this.renderPane(); this.toast('Wallpaper semua chat diganti'); });
      case 'wall-reset': await idb.del('wall:' + conv); delete s['wallPreset:' + conv]; this.saveSettings(); this.closeDialog(); return this.renderPane();
      case 'find': { this.closeDialog(); const q = prompt('Cari di chat:'); if (!q) return; const hit = [...this.convMessages(conv)].reverse().find((m) => (m.text || '').toLowerCase().includes(q.toLowerCase())); if (!hit) return this.toast('Tidak ditemukan'); const el = document.querySelector(`.msg[data-id="${hit.id}"]`); el?.scrollIntoView({ block: 'center' }); el?.classList.add('flash'); return; }
      case 'toggle-pin': s.pinned[conv] = !s.pinned[conv]; this.saveSettings(); this.closeDialog(); return this.renderList();
      case 'toggle-mute': s.muted[conv] = !s.muted[conv]; this.saveSettings(); this.closeDialog(); return this.renderList();
      case 'wa-chat': { this.closeDialog(); const u = this.state.users[conv]; return window.open(u?.waNumber ? `https://wa.me/${u.waNumber.replace(/\D/g, '')}` : `https://wa.me/?text=${encodeURIComponent('Yuk chat di Novalink: ' + this.base + '/#/add/' + this.state.me.username)}`, '_blank'); }
      case 'export': { const txt = this.convMessages(conv).map((m) => `[${new Date(m.ts).toLocaleString('id-ID')}] ${this.userName(m.from)}: ${this.preview(m)}`).join('\n'); download(`chat-${this.convTitle(conv)}.txt`, txt); return this.closeDialog(); }
      case 'clear': if (confirm('Bersihkan semua pesan di chat ini dari perangkat ini?')) { for (const m of this.convMessages(conv)) s.hidden[m.id] = 1; this.saveSettings(); this.renderMessages(); } return this.closeDialog();
      case 'block': { const blocked = this.isBlocked(conv); this.state.me = await this.api('/api/block', { id: conv, block: !blocked }); this.closeDialog(); return this.toast(blocked ? 'Blokir dibuka' : 'Kontak diblokir'); }
      case 'leave-msg': this.closeDialog(); return this.openChat(b.dataset.to);
      case 'new-chat': return this.newChatDialog();
      case 'new-group': return this.newGroupDialog();
      case 'group-add': return this.newGroupDialog(conv);
      case 'create-group': case 'do-group-add': {
        const members = [...document.querySelectorAll('.gm:checked')].map((x) => x.value);
        if (a === 'create-group') { const g = await this.api('/api/groups', { name: $('#group-name').value || 'Grup Baru', members }); this.state.groups[g.id] = g; this.closeDialog(); return this.openChat(g.id); }
        const g = await this.api('/api/groups/' + conv, { add: members }, 'PATCH'); this.state.groups[g.id] = g; this.closeDialog(); return this.renderHeader();
      }
      case 'add-contact': { const u = await this.api('/api/contacts', { id }); this.state.users[u.id] = u; this.state.me.contacts = [...new Set([...(this.state.me.contacts || []), u.id])]; this.closeDialog(); return this.openChat(u.id); }
      case 'phone-search': { const r = await this.api('/api/users/by-phone', { phone: $('#phone-q').value }).catch((er) => { this.toast(er.message); return []; }); $('#user-results').innerHTML = r.map((u) => `<button class="conv" data-act="add-contact" data-id="${u.id}">${this.avatarHtml(u)}<b>${esc(u.displayName)}</b></button>`).join('') || '<p class="muted">Tidak ditemukan / tidak mengizinkan</p>'; return; }
      case 'share-me': case 'invite-wa': {
        const link = `${this.base}/#/add/${this.state.me.username}`;
        const text = `Hai! Chat aku di Novalink By Natan ✦ @${this.state.me.username} ${link}`;
        if (a === 'invite-wa') return window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank');
        if (navigator.share) return navigator.share({ title: 'Novalink', text }).catch(() => {});
        await navigator.clipboard.writeText(link).catch(() => {}); return this.toast('Link disalin');
      }
      case 'new-story': return this.newStoryDialog();
      case 'story-type': {
        document.querySelectorAll('[data-act="story-type"]').forEach((x) => x.classList.toggle('on', x === b));
        this.storyDraft.type = b.dataset.type;
        $('#story-form').innerHTML = b.dataset.type === 'text'
          ? `<textarea class="input story-text" id="story-text" maxlength="700" placeholder="Apa yang kamu pikirkan?" style="background:${this.storyDraft.bg}"></textarea>`
          : `<button class="btn ghost full" data-act="story-media">📁 Pilih foto / video dari galeri</button><div id="story-prev"></div><input class="input" id="story-caption" placeholder="Keterangan"><div class="progress" id="story-progress" hidden><div></div></div>`;
        return;
      }
      case 'story-bg': this.storyDraft.bg = b.dataset.bg; { const t = $('#story-text'); if (t) t.style.background = b.dataset.bg; } return;
      case 'story-media': return this.pickImage((f) => {
        this.storyDraft.file = f;
        const url = URL.createObjectURL(f);
        const prev = $('#story-prev');
        if (f.type.startsWith('video')) {
          prev.innerHTML = `<video class="media" src="${url}" controls playsinline></video><p class="tiny muted" id="story-dur"></p>`;
          const v = prev.querySelector('video');
          v.onloadedmetadata = () => { this.storyDraft.duration = v.duration; $('#story-dur').textContent = `Durasi ${fmt(Math.round(v.duration))} · ${fmtSize(f.size)} — tanpa batas durasi ✓`; };
        } else prev.innerHTML = `<img class="media" src="${url}" alt="">`;
      }, 'image/*,video/*');
      case 'post-story': return this.postStory();
      case 'view-story': return this.viewStories(id);
      case 'story-link': { const l = this.storyLink(); await navigator.clipboard.writeText(l).catch(() => {}); return this.dialog('🔗 Link story publik', `<p>Siapa saja — termasuk pengguna WhatsApp — bisa membuka link ini, melihat story publikmu, lalu <b>simpan kontak</b> atau chat kamu.</p><input class="input" readonly value="${esc(l)}"><div class="row"><a class="btn" target="_blank" rel="noopener" href="https://wa.me/?text=${encodeURIComponent('Lihat story-ku ✦ ' + l)}">🟢 Kirim ke WhatsApp</a><a class="btn ghost" href="${esc(l)}" target="_blank" rel="noopener">Buka</a></div><p class="tiny muted">Tip: aktifkan "Tampilkan nomor WhatsApp" di Privasi agar tombol "Chat via WhatsApp" muncul di halaman story.</p>`); }
      case 'story-wa': return this.shareStoryToWhatsApp();
      case 'nova': return this.assistant.command();
      case 'nova-report': return this.assistant.reportCalls();
      case 'nova-read': return this.assistant.readUnread();
      case 'airplane': return this.setAirplane(!s.airplane);
      case 'offline': this.closeDialog(); return this.offline.open();
      case 'theme': s.theme = b.dataset.theme; s.accent = ''; this.saveSettings(); await this.applyTheme(); return this.renderList();
      case 'app-bg': return this.pickImage(async (f) => { await idb.set('appBg', f); this.applyTheme(); this.toast('Background aplikasi diganti'); });
      case 'app-bg-reset': await idb.del('appBg'); return this.applyTheme();
      case 'preview-ring': return s.ringtone === 'custom' && s.customRingtone ? new Audio(s.customRingtone).play() : previewRingtone(s.ringtone);
      case 'custom-ring': return this.pickImage((f) => { const r = new FileReader(); r.onload = () => { s.customRingtone = r.result; s.ringtone = 'custom'; try { this.saveSettings(); this.toast('🎵 Nada dering kustom dipasang'); this.renderList(); } catch { this.toast('File terlalu besar, pilih audio < 3 MB'); delete s.customRingtone; } }; r.readAsDataURL(f); }, 'audio/*');
      case 'sfx': return playSfx(b.dataset.sfx);
      case 'notif-perm': return Notification.requestPermission().then((p) => this.toast(p === 'granted' ? 'Notifikasi diizinkan ✓' : 'Notifikasi ditolak'));
      case 'blocked': return this.dialog('Diblokir', (this.state.me.blocked || []).map((x) => `<div class="conv">${this.avatarHtml(this.state.users[x])}<b>${esc(this.userName(x))}</b></div>`).join('') || '<p class="muted">Kosong</p>');
      case 'voice-test': return this.voiceTest();
      case 'edit-profile': return this.editProfileDialog();
      case 'avatar': return this.pickImage(async (f) => { const r = await this.upload(f); this.state.me = await this.api('/api/me', { avatar: r.url }, 'PATCH'); this.editProfileDialog(); this.renderList(); });
      case 'save-profile': this.state.me = await this.api('/api/me', { displayName: $('#p-name').value, about: $('#p-about').value }, 'PATCH'); this.closeDialog(); return this.renderList();
      case 'ext-install': return this.extInstallDialog();
      case 'ext-file': return this.pickImage(async (f) => { $('#ext-code').value = await f.text(); $('#ext-name').value = f.name.replace(/\.js$/, ''); }, '.js,text/javascript');
      case 'ext-save': this.ext.install($('#ext-name').value || 'Ekstensi', $('#ext-code').value); this.closeDialog(); this.toast('🧩 Ekstensi dipasang'); return setTimeout(() => this.renderList(), 400);
      case 'ext-remove': this.ext.remove(id); return this.renderList();
      case 'ext-cmds': return this.dialog('📜 Perintah', `<div class="menu">${this.ext.commandList().map(([c, d]) => `<div class="menu-row"><code>${esc(c)}</code><span class="muted">${esc(d)}</span></div>`).join('')}</div>`);
      case 'backup': { const cache = await idb.get('cache'); download(`novalink-backup-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify({ app: 'novalink', v: 1, settings: s, cache, calls: this.state.callLog }, null, 0)); return; }
      case 'restore': return this.pickImage(async (f) => { try { const j = JSON.parse(await f.text()); if (j.app !== 'novalink') throw 0; Object.assign(s, j.settings); this.saveSettings(); if (j.cache) await idb.set('cache', j.cache); localStorage.setItem('nl:calls', JSON.stringify(j.calls || [])); location.reload(); } catch { this.toast('File backup tidak valid'); } }, '.json,application/json');
      case 'install': this.installPrompt?.prompt(); return;
      case 'logout': if (confirm('Keluar dari Novalink?')) this.logout(); return;
      default: break;
    }
  }

  async onChange(e) {
    const t = e.target;
    const s = this.settings;
    if (t.dataset.set) {
      if (t.dataset.set === 'airplane') return this.setAirplane(t.checked);
      s[t.dataset.set] = t.checked; this.saveSettings();
      if (t.dataset.set === 'highContrast') this.applyTheme();
      if (t.dataset.set === 'hideIp') this.toast(t.checked ? '🕶️ Perlindungan IP aktif' : 'Perlindungan IP mati');
      return;
    }
    if (t.dataset.setSel) {
      s[t.dataset.setSel] = t.value; this.saveSettings();
      if (t.dataset.setSel === 'ringtone') { if (t.value === 'custom' && !s.customRingtone) $('[data-act="custom-ring"]')?.click(); else if (t.value !== 'custom') previewRingtone(t.value); }
      if (['msgSound', 'groupSound'].includes(t.dataset.setSel)) playSfx(t.value);
      return;
    }
    if (t.dataset.setExt) { s.extensions[t.dataset.setExt] = t.checked; return this.saveSettings(); }
    if (t.dataset.quick) { s.quickReplies[Number(t.dataset.quick)] = t.value; return this.saveSettings(); }
    if (t.dataset.setText) { s[t.dataset.setText] = t.value; return this.saveSettings(); }
    if (t.dataset.priv) { this.state.me = await this.api('/api/me', { privacy: { [t.dataset.priv]: t.checked } }, 'PATCH'); return; }
    if (t.dataset.privSel) { this.state.me = await this.api('/api/me', { privacy: { [t.dataset.privSel]: t.value } }, 'PATCH'); return; }
    if (t.dataset.me) { this.state.me = await this.api('/api/me', { [t.dataset.me]: t.checked }, 'PATCH'); return; }
    if (t.dataset.meText) { this.state.me = await this.api('/api/me', { [t.dataset.meText]: t.value }, 'PATCH'); return this.toast('Tersimpan'); }
    if (t.dataset.actColor !== undefined) { s.accent = t.value; this.saveSettings(); return this.applyTheme(); }
    if (t.dataset.act === 'disappear') { s.disappearing[this.view.conv] = Number(t.value); this.saveSettings(); this.renderHeader(); this.sendText(this.view.conv, Number(t.value) ? `⏳ Pesan sementara diaktifkan (${t.selectedOptions[0].text})` : '⏳ Pesan sementara dimatikan'); return this.closeDialog(); }
  }

  openOffline() { this.offline.open(); }

  /** Android back button: returns true when handled inside the app. */
  handleBack() {
    if ($('#dialog')?.classList.contains('open')) { this.closeDialog(); return true; }
    const sv = $('#story-viewer');
    if (sv?.classList.contains('open')) { clearTimeout(this.storyT); sv.classList.remove('open'); sv.innerHTML = ''; return true; }
    if (this.calls.active) return true; // never leave the app during a call
    if (!$('#emoji-panel')?.hidden && $('#emoji-panel')) { $('#emoji-panel').hidden = true; return true; }
    if (this.view.conv) { this.closeChat(); return true; }
    if (this.view.tab !== 'chats' && $('.layout')) { this.setTab('chats'); return true; }
    return false;
  }
}

// ---------- small helpers ----------
function tickText(m) { return m.pending || m.status === 'pending' ? '🕓' : m.status === 'failed' ? '⚠️' : m.status === 'read' ? '✓✓' : m.status === 'delivered' ? '✓✓' : '✓'; }
function hue(s) { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; }
function fmtSize(n) { if (!n) return ''; const u = ['B', 'KB', 'MB', 'GB']; let i = 0; while (n >= 1024 && i < 3) { n /= 1024; i++; } return n.toFixed(i ? 1 : 0) + ' ' + u[i]; }
function linkify(s) { return s.replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>').replace(/\*([^*\n]+)\*/g, '<b>$1</b>').replace(/_([^_\n]+)_/g, '<i>$1</i>').replace(/~([^~\n]+)~/g, '<s>$1</s>'); }
function download(name, text) { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: 'text/plain' })); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); }
function micIcon() { return '<svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M12 14a3 3 0 003-3V5a3 3 0 10-6 0v6a3 3 0 003 3zm5-3a5 5 0 01-10 0H5a7 7 0 006 6.9V21h2v-3.1A7 7 0 0019 11z"/></svg>'; }
function sendIcon() { return '<svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M2 21l21-9L2 3v7l15 2-15 2z"/></svg>'; }
function logo() { return '<svg class="logo-mark" viewBox="0 0 48 48" aria-hidden="true"><defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="var(--accent)"/><stop offset="1" stop-color="var(--accent2)"/></linearGradient></defs><path d="M24 3c11.6 0 21 8.7 21 19.5S35.6 42 24 42c-2.6 0-5-.4-7.3-1.2L6 45l3.2-9.2A18.6 18.6 0 013 22.5C3 11.7 12.4 3 24 3z" fill="url(#lg)"/><path d="M16 30V16l16 14V16" stroke="#fff" stroke-width="3.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>'; }

const app = new App();
window.novalink = app;
app.boot();
