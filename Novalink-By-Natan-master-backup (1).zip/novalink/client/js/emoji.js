// Emoji catalog with Indonesian names — powers the emoji keyboard and the "baca emoji" accessibility feature.
export const EMOJI_GROUPS = {
  'Wajah': {
    '😀': 'wajah tersenyum lebar', '😁': 'nyengir', '😂': 'tertawa sampai menangis', '🤣': 'tertawa berguling', '😊': 'senyum malu',
    '😇': 'senyum malaikat', '🙂': 'senyum tipis', '😉': 'mengedipkan mata', '😍': 'mata cinta', '🥰': 'senyum penuh cinta',
    '😘': 'kirim ciuman', '😋': 'enak', '😛': 'menjulurkan lidah', '😜': 'melet sambil kedip', '🤪': 'wajah konyol',
    '🤗': 'pelukan', '🤭': 'menutup mulut', '🤫': 'ssst diam', '🤔': 'berpikir', '😐': 'wajah datar', '😑': 'tanpa ekspresi',
    '😶': 'tanpa mulut', '🙄': 'memutar mata', '😏': 'senyum sinis', '😴': 'tidur', '😪': 'mengantuk', '🤤': 'ngiler',
    '😷': 'pakai masker', '🤒': 'demam', '🤕': 'kepala diperban', '🤢': 'mual', '🤮': 'muntah', '🥵': 'kepanasan', '🥶': 'kedinginan',
    '😵': 'pusing', '🤯': 'kepala meledak', '🤠': 'koboi', '🥳': 'pesta', '😎': 'keren pakai kacamata hitam', '🤓': 'kutu buku',
    '😕': 'bingung', '😟': 'khawatir', '🙁': 'sedikit sedih', '😮': 'terkejut', '😲': 'kaget sekali', '🥺': 'memelas',
    '😢': 'menangis', '😭': 'menangis keras', '😱': 'menjerit ketakutan', '😖': 'frustrasi', '😞': 'kecewa', '😓': 'keringat dingin',
    '😩': 'lelah', '😤': 'kesal', '😡': 'marah', '🤬': 'mengumpat', '😈': 'setan tersenyum', '💀': 'tengkorak', '🤡': 'badut',
    '👻': 'hantu', '👽': 'alien', '🤖': 'robot', '💩': 'kotoran', '🫠': 'meleleh', '🫡': 'hormat', '🥹': 'menahan tangis',
  },
  'Gestur': {
    '👍': 'jempol', '👎': 'jempol ke bawah', '👌': 'oke', '✌️': 'tanda damai', '🤞': 'jari silang', '🤟': 'aku sayang kamu',
    '🤘': 'tanda rock', '👏': 'tepuk tangan', '🙌': 'angkat tangan', '🙏': 'tangan berdoa atau terima kasih', '🤝': 'jabat tangan',
    '👋': 'melambaikan tangan', '💪': 'otot kuat', '👊': 'tinju', '✊': 'kepalan tangan', '🫶': 'tangan hati', '👀': 'mata melirik',
    '🫰': 'jari hati', '☝️': 'telunjuk ke atas', '👉': 'menunjuk ke kanan', '👈': 'menunjuk ke kiri',
  },
  'Hati': {
    '❤️': 'hati merah', '🧡': 'hati oranye', '💛': 'hati kuning', '💚': 'hati hijau', '💙': 'hati biru', '💜': 'hati ungu',
    '🖤': 'hati hitam', '🤍': 'hati putih', '💔': 'patah hati', '💕': 'dua hati', '💖': 'hati berkilau', '💯': 'seratus',
    '🔥': 'api', '✨': 'berkilau', '⭐': 'bintang', '🌟': 'bintang bersinar', '💫': 'pusing bintang', '💥': 'ledakan', '💤': 'zzz tidur',
  },
  'Alam & Makanan': {
    '🌹': 'mawar', '🌸': 'bunga sakura', '🌈': 'pelangi', '☀️': 'matahari', '🌙': 'bulan sabit', '⚡': 'petir', '🌊': 'ombak',
    '🐱': 'kucing', '🐶': 'anjing', '🐼': 'panda', '🦋': 'kupu-kupu', '🐔': 'ayam', '🍕': 'pizza', '🍔': 'burger', '🍜': 'mi kuah',
    '🍚': 'nasi', '🍗': 'paha ayam', '☕': 'kopi', '🧋': 'boba', '🍰': 'kue', '🎂': 'kue ulang tahun', '🍉': 'semangka', '🥭': 'mangga',
  },
  'Aktivitas & Benda': {
    '🎉': 'perayaan', '🎁': 'hadiah', '🎈': 'balon', '⚽': 'bola sepak', '🏀': 'bola basket', '🎮': 'main game', '🎧': 'headphone',
    '🎤': 'mikrofon karaoke', '🎵': 'not musik', '🎶': 'musik', '📱': 'ponsel', '💻': 'laptop', '📷': 'kamera', '📞': 'telepon',
    '💰': 'uang', '🚀': 'roket', '✈️': 'pesawat', '🏠': 'rumah', '⏰': 'jam alarm', '📌': 'pin', '✅': 'centang', '❌': 'silang',
    '⚠️': 'peringatan', '❓': 'tanda tanya', '‼️': 'tanda seru ganda', '🆗': 'oke', '🇮🇩': 'bendera Indonesia',
  },
};

export const EMOJI_NAMES = Object.assign({}, ...Object.values(EMOJI_GROUPS));
const EMOJI_RE = /\p{Extended_Pictographic}/u;

export function emojiName(e) {
  return EMOJI_NAMES[e] || EMOJI_NAMES[e.replace(/️/g, '')] || EMOJI_NAMES[e + '️'] || 'emoji';
}

/** Replace emojis with spoken names, e.g. "Halo 👋" -> "Halo (emoji melambaikan tangan)". */
export function speakableText(text) {
  if (!text) return '';
  const seg = typeof Intl !== 'undefined' && Intl.Segmenter ? new Intl.Segmenter('id', { granularity: 'grapheme' }) : null;
  const parts = seg ? [...seg.segment(text)].map((s) => s.segment) : [...text];
  return parts.map((g) => (EMOJI_RE.test(g) ? ` (emoji ${emojiName(g)}) ` : g)).join('').replace(/\s+/g, ' ').trim();
}
