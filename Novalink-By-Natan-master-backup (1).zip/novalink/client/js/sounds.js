// Synthesized ringtones & sound effects (Web Audio) — original sounds, no copyrighted files.
let ctx;
const ac = () => (ctx ||= new (window.AudioContext || window.webkitAudioContext)());

function tone(freq, start, dur, { type = 'sine', gain = 0.2, glide = 0, out } = {}) {
  const a = ac();
  const o = a.createOscillator();
  const g = a.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, a.currentTime + start);
  if (glide) o.frequency.exponentialRampToValueAtTime(glide, a.currentTime + start + dur);
  g.gain.setValueAtTime(0.0001, a.currentTime + start);
  g.gain.exponentialRampToValueAtTime(gain, a.currentTime + start + 0.015);
  g.gain.exponentialRampToValueAtTime(0.0001, a.currentTime + start + dur);
  o.connect(g).connect(out || a.destination);
  o.start(a.currentTime + start);
  o.stop(a.currentTime + start + dur + 0.05);
}
function noise(start, dur, gain = 0.15, hp = 2000) {
  const a = ac();
  const b = a.createBuffer(1, a.sampleRate * dur, a.sampleRate);
  const d = b.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
  const s = a.createBufferSource(); s.buffer = b;
  const f = a.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = hp;
  const g = a.createGain(); g.gain.value = gain;
  s.connect(f).connect(g).connect(a.destination);
  s.start(a.currentTime + start);
}
const N = (n) => 440 * Math.pow(2, (n - 69) / 12); // MIDI note -> Hz

// ---- Ringtones (loop length in seconds + pattern) ----
export const RINGTONES = {
  neon: { name: 'Neon Pulse', len: 2.4, play() { [72, 76, 79, 84, 79, 76].forEach((n, i) => tone(N(n), i * 0.16, 0.22, { type: 'square', gain: 0.07 })); [72, 76, 79, 84].forEach((n, i) => tone(N(n + 12), 1.2 + i * 0.12, 0.2, { type: 'triangle', gain: 0.1 })); } },
  cyber: { name: 'Cyber Drop', len: 2.0, play() { tone(N(48), 0, 0.5, { type: 'sawtooth', gain: 0.12, glide: N(36) }); [0, 0.25, 0.5, 0.75].forEach((t) => noise(t, 0.05, 0.12, 6000)); [84, 88, 91].forEach((n, i) => tone(N(n), 0.9 + i * 0.1, 0.35, { gain: 0.12 })); } },
  lofi: { name: 'Lo-Fi Chill', len: 3.2, play() { [[60, 64, 67, 71], [57, 60, 64, 67]].forEach((ch, k) => ch.forEach((n) => tone(N(n), k * 1.4, 1.3, { type: 'triangle', gain: 0.05 }))); [76, 74, 72, 71].forEach((n, i) => tone(N(n), 0.2 + i * 0.35, 0.3, { gain: 0.09 })); } },
  galaxy: { name: 'Galaxy Bell', len: 2.8, play() { [88, 83, 79, 76, 79, 83].forEach((n, i) => { tone(N(n), i * 0.2, 0.9, { gain: 0.1 }); tone(N(n) * 2.01, i * 0.2, 0.5, { gain: 0.03 }); }); } },
  retro: { name: 'Retro 8-Bit', len: 1.8, play() { [76, 76, 0, 76, 0, 72, 76, 0, 79].forEach((n, i) => n && tone(N(n), i * 0.11, 0.1, { type: 'square', gain: 0.08 })); tone(N(67), 1.0, 0.25, { type: 'square', gain: 0.08 }); } },
  koplo: { name: 'Dangdut Koplo Beat', len: 2.0, play() { [0, 0.5, 1, 1.5].forEach((t) => tone(110, t, 0.18, { gain: 0.25, glide: 50 })); [0.25, 0.75, 1.25, 1.62, 1.75].forEach((t) => tone(320, t, 0.08, { type: 'triangle', gain: 0.18, glide: 200 })); [74, 76, 77, 76, 74, 72].forEach((n, i) => tone(N(n), i * 0.3, 0.25, { type: 'sawtooth', gain: 0.04 })); } },
  gamelan: { name: 'Gamelan Modern', len: 3.0, play() { [62, 64, 67, 69, 71, 69, 67, 64].forEach((n, i) => { tone(N(n), i * 0.3, 0.8, { gain: 0.09 }); tone(N(n) * 2.76, i * 0.3, 0.4, { gain: 0.025 }); }); } },
  classic: { name: 'Classic Phone', len: 3.0, play() { for (let i = 0; i < 2; i++) { tone(440, i * 0.5, 0.4, { gain: 0.08 }); tone(480, i * 0.5, 0.4, { gain: 0.08 }); } } },
};

// ---- Notification / UI sound effects ----
export const SFX = {
  pop: { name: 'Bubble Pop', play() { tone(600, 0, 0.12, { gain: 0.2, glide: 1200 }); } },
  chime: { name: 'Crystal Chime', play() { tone(N(84), 0, 0.4, { gain: 0.12 }); tone(N(91), 0.08, 0.5, { gain: 0.1 }); } },
  laser: { name: 'Laser Zap', play() { tone(1800, 0, 0.18, { type: 'sawtooth', gain: 0.08, glide: 200 }); } },
  coin: { name: 'Coin Up', play() { tone(N(83), 0, 0.08, { type: 'square', gain: 0.07 }); tone(N(88), 0.08, 0.25, { type: 'square', gain: 0.07 }); } },
  drop: { name: 'Water Drop', play() { tone(1400, 0, 0.15, { gain: 0.15, glide: 400 }); } },
  swoosh: { name: 'Swoosh', play() { noise(0, 0.25, 0.1, 1200); } },
  ding: { name: 'Soft Ding', play() { tone(N(81), 0, 0.6, { type: 'triangle', gain: 0.15 }); } },
  glitch: { name: 'Glitch', play() { [0, 0.04, 0.09].forEach((t, i) => tone(300 + i * 700, t, 0.04, { type: 'square', gain: 0.07 })); } },
  none: { name: 'Senyap', play() {} },
};
export const SEND_SFX = () => tone(900, 0, 0.07, { gain: 0.05, glide: 1500 });

let ringTimer = null;
let customAudio = null;
export function playRingtone(id, customUrl) {
  stopRingtone();
  if (id === 'custom' && customUrl) {
    customAudio = new Audio(customUrl); customAudio.loop = true; customAudio.play().catch(() => {});
    return;
  }
  const r = RINGTONES[id] || RINGTONES.neon;
  const loop = () => { r.play(); ringTimer = setTimeout(loop, r.len * 1000 + 600); };
  loop();
  if (navigator.vibrate) navigator.vibrate([400, 200, 400, 200, 400]);
}
export function stopRingtone() {
  clearTimeout(ringTimer); ringTimer = null;
  if (customAudio) { customAudio.pause(); customAudio = null; }
  if (navigator.vibrate) navigator.vibrate(0);
}
export function playSfx(id) { try { (SFX[id] || SFX.pop).play(); } catch { /* audio blocked */ } }
export function previewRingtone(id) { try { (RINGTONES[id] || RINGTONES.neon).play(); } catch { /* */ } }
export function dialTone() { const t = () => { tone(425, 0, 1, { gain: 0.05 }); }; t(); const iv = setInterval(t, 4000); return () => clearInterval(iv); }
export { ac as audioContext };
