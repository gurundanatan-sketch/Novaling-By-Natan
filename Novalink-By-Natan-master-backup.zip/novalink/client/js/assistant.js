// "Nova" — voice AI assistant: reports incoming calls, answers by voice command,
// reads incoming chats, and replies by dictation with a voice read-back check before sending.
import { speakableText } from './emoji.js';

const SR = window.SpeechRecognition || window.webkitSpeechRecognition;

export class Assistant {
  constructor(app) {
    this.app = app;
    this.rec = null;
    this.listening = false;
    this.pending = null; // { kind: 'reply', to, text }
    this.ui = document.getElementById('nova');
  }

  get supported() { return { speak: 'speechSynthesis' in window, listen: !!SR }; }
  get on() { return this.app.settings.assistant !== false; }

  say(text, { then } = {}) {
    this.show(text);
    if (!('speechSynthesis' in window) || this.app.settings.assistantVoice === false) { then?.(); return; }
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(speakableText(text));
    u.lang = 'id-ID';
    u.rate = this.app.settings.speechRate || 1.05;
    const v = speechSynthesis.getVoices().find((x) => x.lang?.startsWith('id'));
    if (v) u.voice = v;
    u.onend = () => then?.();
    u.onerror = () => then?.();
    speechSynthesis.speak(u);
  }

  show(text, listening = this.listening) {
    if (!this.ui) return;
    this.ui.innerHTML = `<div class="orb ${listening ? 'listening' : ''}"></div><div class="nova-text"><b>Nova</b><span>${this.app.esc(text)}</span></div><button class="icon-btn" data-nova="close" aria-label="Tutup">✕</button>`;
    this.ui.classList.add('open');
    clearTimeout(this.hideT);
    if (!listening) this.hideT = setTimeout(() => this.ui.classList.remove('open'), 7000);
    this.ui.onclick = (e) => { if (e.target.closest('[data-nova="close"]')) { this.stopListening(); this.ui.classList.remove('open'); } };
  }

  /** Listen once; resolve with lower-cased transcript or '' on silence. */
  listen(timeoutMs = 7000) {
    return new Promise((resolve) => {
      if (!SR) { resolve(''); return; }
      this.stopListening();
      const r = new SR();
      r.lang = 'id-ID'; r.interimResults = true; r.maxAlternatives = 3; r.continuous = false;
      let final = '';
      let done = false;
      const finish = (v) => { if (done) return; done = true; this.listening = false; clearTimeout(t); try { r.stop(); } catch { /* */ } resolve(v.trim()); };
      r.onresult = (e) => {
        let interim = '';
        for (const res of e.results) { if (res.isFinal) final = res[0].transcript; else interim += res[0].transcript; }
        this.show(final || interim || '…', true);
        if (final) finish(final);
      };
      r.onerror = () => finish(final);
      r.onend = () => finish(final);
      const t = setTimeout(() => finish(final), timeoutMs);
      this.rec = r; this.listening = true;
      this.show('Mendengarkan…', true);
      try { r.start(); } catch { finish(''); }
    });
  }

  stopListening() { try { this.rec?.abort(); } catch { /* */ } this.rec = null; this.listening = false; }

  // ---------- incoming call reporting + voice answer ----------
  async announceCall(fromId, video, groupName) {
    if (!this.on || this.app.settings.announceCalls === false) return;
    const who = this.app.userName(fromId);
    const text = `${video ? 'Video call' : 'Panggilan'} masuk dari ${who}${groupName ? ' di grup ' + groupName : ''}. Katakan angkat, tolak, atau tolak sambil balas sibuk.`;
    // Let the ringtone play once before speaking
    await new Promise((r) => setTimeout(r, 1500));
    if (this.app.calls.active?.status !== 'ringing') return;
    this.say(text, { then: () => this.callCommandLoop(2) });
  }

  async callCommandLoop(tries) {
    const calls = this.app.calls;
    if (calls.active?.status !== 'ringing' || !SR || this.app.settings.handsFree === false) return;
    const t = (await this.listen(6000)).toLowerCase();
    if (calls.active?.status !== 'ringing') return;
    if (/\b(angkat|terima|jawab|ya|oke|ok|halo)\b/.test(t)) { this.say('Oke, panggilan diangkat.'); calls.accept(); return; }
    if (/sibuk|nanti/.test(t)) { this.say('Ditolak dan aku kirim pesan kamu sedang sibuk.'); calls.decline('Maaf, aku lagi sibuk. Nanti aku telepon balik ya 🙏'); return; }
    if (/\b(tolak|tidak|nggak|enggak|jangan|abaikan)\b/.test(t)) { this.say('Panggilan ditolak.'); calls.decline(); return; }
    if (tries > 1) this.say('Maaf, aku belum dengar. Angkat atau tolak?', { then: () => this.callCommandLoop(tries - 1) });
  }

  // ---------- incoming messages ----------
  announceMessage(msg) {
    if (!this.on || this.app.settings.announceMessages !== true) return;
    if (this.app.calls.active) return;
    const who = this.app.userName(msg.from);
    const g = this.app.state.groups[msg.to];
    const body = msg.kind === 'text' ? msg.text : ({ image: 'sebuah foto', video: 'sebuah video', audio: 'audio', voice: 'pesan suara', doc: 'dokumen', sticker: 'stiker' }[msg.kind] || 'pesan');
    const convo = g ? g.id : msg.from;
    this.say(`Pesan dari ${who}${g ? ' di ' + g.name : ''}: ${body}. Mau dibalas?`, {
      then: async () => {
        if (!SR || this.app.settings.handsFree === false) return;
        const t = (await this.listen(5000)).toLowerCase();
        if (/\b(balas|iya|ya|boleh|oke)\b/.test(t)) this.dictateReply(convo);
        else if (t) this.say('Oke, nanti saja.');
      },
    });
  }

  /** Dictate → read back ("periksa suara") → confirm "kirim" / "ulang" / "batal". */
  async dictateReply(convo, attempts = 3) {
    this.say('Silakan ucapkan balasanmu.', {
      then: async () => {
        const text = await this.listen(12000);
        if (!text) { this.say('Aku tidak mendengar apa-apa. Dibatalkan.'); return; }
        this.pending = { to: convo, text };
        this.app.fillComposer?.(convo, text);
        this.say(`Kamu bilang: ${text}. Katakan kirim, ulang, atau batal.`, {
          then: async () => {
            const c = (await this.listen(6000)).toLowerCase();
            if (/\b(kirim|kirimkan|send|ya|oke)\b/.test(c)) { this.app.sendText(convo, text); this.say('Terkirim ✓'); this.app.fillComposer?.(convo, ''); }
            else if (/\b(ulang|ganti|salah)\b/.test(c) && attempts > 1) this.dictateReply(convo, attempts - 1);
            else this.say('Dibatalkan. Teksnya masih ada di kolom ketik kalau mau diedit.');
            this.pending = null;
          },
        });
      },
    });
  }

  /** Free-form command mode (mic button in header). */
  async command() {
    if (!SR) { this.say('Perangkat ini belum mendukung pengenalan suara. Coba di Chrome Android.'); return; }
    const t = (await this.listen(8000)).toLowerCase();
    if (!t) { this.show('Tidak ada perintah.'); return; }
    const app = this.app;
    const findUser = (name) => Object.values(app.state.users).find((u) => name.includes(u.displayName.toLowerCase()) || name.includes(u.username));
    let m;
    if ((m = /(video ?call|vc)\s+(.+)/.exec(t))) { const u = findUser(m[2]); return u ? (this.say(`Video call ke ${u.displayName}`), app.calls.start(u.id, true)) : this.say('Kontak tidak ditemukan.'); }
    if ((m = /(telepon|telpon|panggil|hubungi)\s+(.+)/.exec(t))) { const u = findUser(m[2]); return u ? (this.say(`Menelepon ${u.displayName}`), app.calls.start(u.id, false)) : this.say('Kontak tidak ditemukan.'); }
    if ((m = /(kirim pesan|chat|pesan|balas)\s+(ke\s+)?(\S+)\s*(.*)/.exec(t))) {
      const u = findUser(m[3]);
      if (!u) return this.say('Kontak tidak ditemukan.');
      if (m[4]) { this.pending = { to: u.id, text: m[4] }; return this.say(`Kirim ke ${u.displayName}: ${m[4]}? Katakan kirim atau batal.`, { then: async () => { const c = await this.listen(5000); if (/kirim|ya|oke/.test(c)) { app.sendText(u.id, m[4]); this.say('Terkirim ✓'); } else this.say('Dibatalkan.'); } }); }
      return this.dictateReply(u.id);
    }
    if (/baca pesan|pesan baru|ada pesan/.test(t)) return this.readUnread();
    if (/laporan|panggilan tak terjawab|siapa (yang )?(telepon|nelpon)/.test(t)) return this.reportCalls();
    if (/mode pesawat/.test(t)) { const on = !/mati|nonaktif|off/.test(t); app.setAirplane(on); return this.say(`Mode pesawat ${on ? 'aktif' : 'nonaktif'}.`); }
    if (/mode offline/.test(t)) { app.openOffline(); return this.say('Membuka mode offline.'); }
    return this.say('Perintah yang bisa: telepon Sari, video call Budi, kirim pesan ke Sari halo, baca pesan, laporan panggilan, mode pesawat nyala.');
  }

  readUnread() {
    const list = this.app.unreadMessages().slice(-5);
    if (!list.length) return this.say('Tidak ada pesan baru.');
    const text = list.map((m) => `${this.app.userName(m.from)}: ${m.kind === 'text' ? m.text : m.kind}`).join('. ');
    this.say(`Kamu punya ${list.length} pesan baru. ${text}`);
  }

  reportCalls() {
    const missed = this.app.state.callLog.filter((c) => c.status === 'missed' && !c.reported);
    if (!missed.length) return this.say('Tidak ada panggilan tak terjawab.');
    const names = [...new Set(missed.map((c) => this.app.userName(c.peer)))].join(', ');
    missed.forEach((c) => (c.reported = true));
    this.app.saveCallLog();
    this.say(`Ada ${missed.length} panggilan tak terjawab dari ${names}. Mau aku telepon balik? Katakan telepon dan namanya.`);
  }
}
