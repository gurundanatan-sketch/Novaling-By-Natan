# ✦ Novalink By Natan

Aplikasi chat, telepon, video call, dan story generasi baru dengan tampilan futuristik ala anak muda. Fiturnya mirip WhatsApp, ditambah asisten AI suara, anti-hapus, telepon sambil putar musik atau karaoke, mode offline, pengubah suara, ekstensi, dan perlindungan privasi.

> Web (PWA) + Android native (proyek Gradle di folder utama, APK via GitHub Actions) + server real-time Node.js tanpa dependensi.

---

## 🚀 Fitur

### 💬 Chat (setara WhatsApp, plus lebih)
- Chat pribadi & **grup sampai 1024 anggota**, status ✓ terkirim / ✓✓ diterima / ✓✓ biru dibaca, indikator mengetik & merekam suara
- Balas (quote), reaksi emoji, teruskan, salin, **edit pesan (15 menit) + riwayat edit**, hapus untuk saya / semua
- Kirim **foto, video, audio, dokumen** dari galeri/kamera (upload dengan progress), **pesan suara**, **media sekali lihat**, stiker jumbo
- **Pesan sementara** (24 jam / 7 hari / 90 hari), sematkan chat, bisukan, cari pesan, ekspor chat .txt
- **Saran balasan AI** (✨) di atas kolom ketik
- Format teks `*tebal*`, `_miring_`, `~coret~`, tautan otomatis

### 🛡️ Anti-Hapus
Saat pengirim memilih "hapus untuk semua", pesannya tetap tampil di HP kamu dengan label **🛡️ Dihapus pengirim · tersimpan Anti-Hapus**. Fitur ini bisa dinyalakan atau dimatikan di Setelan → Privasi.

### 🤖 Asisten AI "Nova"
- **Melaporkan panggilan masuk** dengan suara: "Panggilan masuk dari Sari…"
- **Angkat atau tolak telepon cukup dengan suara**: ucapkan *"angkat"*, *"tolak"*, atau *"tolak, lagi sibuk"* (menolak sekaligus mengirim pesan otomatis)
- **Bacakan pesan masuk**, lalu tawarkan balas dengan suara
- **Dikte dengan periksa suara** (🗣️): kamu bicara → Nova membacakan ulang → ucapkan *"kirim"*, *"ulang"*, atau *"batal"*
- Perintah bebas (🎙️): "telepon Sari", "video call Budi", "kirim pesan ke Sari halo", "baca pesan", "laporan panggilan", "mode pesawat nyala"
- Laporan panggilan tak terjawab
- Opsional: sambungkan ke LLM (endpoint kompatibel OpenAI) lewat `AI_API_URL` / `AI_API_KEY` untuk saran balasan yang lebih pintar

### 📞 Telepon & Video Call
- Panggilan suara & video 1-on-1 (WebRTC), ganti kamera, bagikan layar, bisukan
- **Grup call / video call 20+ orang**: mode mesh untuk grup kecil, dan **LiveKit SFU** untuk ratusan peserta
- **🎵 Telepon sambil putar musik / karaoke, cukup 1 HP**: lagu dari galeri dicampur ke suara telepon sehingga semua peserta ikut mendengar. Ada pengatur volume dan mode 🎤 Karaoke (efek gema)
- **🎚️ Peredam kebisingan**: noise gate adaptif (AudioWorklet), filter, dan peredam bawaan browser
- **🎭 Pengubah suara**: Chipmunk, Suara Berat, Robot, Alien, Gua/Gema, Radio HT, Anak Kecil, Monster
- Balas cepat saat menolak telepon. Jika lawan bicara offline, ada tombol "Hubungi lewat WhatsApp"

### 🔔 Nada Dering & Efek Suara Keren
Semua suara dibuat langsung (Web Audio), jadi orisinal dan bebas hak cipta:
- **8 nada dering**: Neon Pulse, Cyber Drop, Lo-Fi Chill, Galaxy Bell, Retro 8-Bit, **Dangdut Koplo Beat**, **Gamelan Modern**, Classic Phone, plus **nada dering dari galeri**
- **8 efek notifikasi**: Bubble Pop, Crystal Chime, Laser Zap, Coin Up, Water Drop, Swoosh, Soft Ding, Glitch. Suara chat pribadi dan grup bisa dibedakan

### ✈️ Mode Pesawat
Memutus Novalink dari jaringan sehingga tidak ada pesan atau panggilan yang masuk. Bisa **aktif otomatis saat aplikasi tidak dipakai** (5 menit sampai 4 jam) dan mati otomatis saat dibuka lagi. Pesan yang ditulis selama mode pesawat masuk antrean, lalu terkirim otomatis.

### 📡 Bisa Dipakai Offline
1. **Antrean offline**: pesan dan media tersimpan di HP, lalu terkirim otomatis begitu online. Riwayat chat tetap bisa dibaca tanpa internet (cache IndexedDB + service worker)
2. **Mode Offline langsung (tanpa internet & tanpa server)**: dua HP di Wi-Fi atau hotspot yang sama, tanpa kuota, bisa **chat dan telepon** langsung lewat WebRTC. Pemasangan memakai kode sekali pakai (salin, Nearby Share, atau Bluetooth share)
3. **Server lokal**: jalankan server di laptop pada jaringan lokal (sekolah, kantor, acara) agar semua orang bisa chat tanpa internet

### 🕶️ Privasi: Perlindungan IP & Anti-Pelacakan Nomor
- **Lindungi IP saat telepon**: semua media dipaksa lewat relay TURN (`iceTransportPolicy: relay`) sehingga lawan bicara tidak melihat IP kamu. Server tidak pernah menyimpan atau membagikan IP
- **Anti pelacakan nomor**: akun berbasis **username**. Nomor HP opsional, disimpan sebagai hash, **tidak pernah ditampilkan**. Pencarian lewat nomor hanya berlaku untuk yang mengizinkan, dan dibatasi 5×/jam
- Pencarian username dibatasi (anti-scraping), PIN di-hash dengan scrypt, login dibatasi (anti brute-force)
- Atur siapa yang bisa melihat "terakhir dilihat", laporan dibaca, dan blokir pengguna

### ◎ Story
- Story teks (latar warna-warni), foto, dan **video tanpa batas 30 detik, bisa lebih dari 5 menit** (batas hanya ukuran file server, default 1 GB)
- Penonton: **Kontak** atau **🌍 Publik**
- **Halaman story publik** `https://servermu/s/username`: siapa pun, termasuk pengguna WhatsApp, bisa membuka link ini, melihat story-mu, menekan **Simpan Kontak** (vCard), atau **Chat via WhatsApp** (jika kamu mengizinkan nomor WA ditampilkan)
- **Bagikan ke Status WhatsApp** dengan satu tombol (share sheet Android, membawa video/foto + link)
- Daftar penonton, balas story, hapus story

### 🟢 Terhubung dengan WhatsApp
- "Lanjutkan di WhatsApp", "Kirim ke WhatsApp" untuk setiap pesan, "Undang via WhatsApp", dan story ke Status WA, semuanya lewat `wa.me` dan share sheet

### 🎨 Tema & Kustomisasi
- 8 tema: Neon Violet, Cyber Teal, Sunset Pop, Matrix, Sakura, Ocean Deep, AMOLED Black, Light Frost, ditambah warna aksen bebas
- **Background aplikasi dari galeri**, **wallpaper chat dari galeri** (per chat atau semua chat), 8 wallpaper preset, dan slider redup

### 🧩 Ekstensi
- Bawaan: Balasan Cepat (`/1`…), Jadwal Pesan (`/jadwal 10m …`), Pengingat (`/ingatkan 30m …`), Gaya Teks Keren (`/bold …`), Kalkulator (`=12*7`), Balas Otomatis, Ringkas Chat (`/ringkas`), Stiker Jumbo
- **Pasang ekstensi sendiri** (JavaScript) yang berjalan di **sandbox iframe**, sehingga tidak bisa membaca token atau akunmu:
  ```js
  nl.command('dadu', () => '🎲 ' + (1 + Math.floor(Math.random() * 6)));
  nl.onMessage((msg) => { if (msg.text === 'ping') nl.send(msg.from, 'pong 🏓'); });
  ```

### ♿ Aksesibilitas
- **Bacakan emoji di keyboard**: ketuk emoji dan namanya diucapkan dalam Bahasa Indonesia (150+ emoji). Fitur "Bacakan pesan" juga mengucapkan nama emoji
- Kontras tinggi, ukuran teks, label ARIA, dan dukungan reduced motion

### 💾 Backup
Ada backup dan pemulihan lokal (JSON) di Setelan → Offline & Data.

---

## 🛠️ Menjalankan

```bash
# Node 20+ (tidak perlu npm install untuk server)
npm start              # http://localhost:8080
npm test               # tes server
```

Buka dua jendela browser, daftar dua akun, lalu cari `@username` untuk mulai chat dan telepon.


### 🌐 Server wajib berjalan (APK tidak bisa daftar/masuk tanpa server)
Akun, chat, story, dan sinyal telepon semuanya lewat server di folder `server/`. Pilih salah satu cara:

**A. Gratis di internet: Render.com** (bisa dipakai publik)
1. Login ke render.com dengan akun GitHub → **New + → Blueprint** → pilih repo ini (file `render.yaml` dipakai otomatis)
2. Tunggu sampai muncul alamat seperti `https://novalink-xxxx.onrender.com`
3. Di aplikasi: **Server lanjutan** → tempel alamat itu → **Tes koneksi server** → Daftar

Catatan paket gratis Render: server tidur setelah 15 menit tanpa aktivitas (butuh ±1 menit untuk bangun lagi), dan data terhapus saat server di-restart. Untuk pemakaian serius, gunakan paket berbayar dengan disk, atau VPS + `docker compose up -d`.

**B. Langsung di HP (Termux)**, untuk mencoba atau dipakai di Wi-Fi yang sama
```
pkg install nodejs git -y
git clone https://github.com/USERNAME/REPO.git && cd REPO
node server/index.js
```
Di aplikasi, isi server `http://localhost:8080`. HP lain di Wi-Fi yang sama memakai `http://IP-HP-kamu:8080`.

### Publik (produksi)
```bash
cp .env.example .env    # isi TURN_SECRET, dsb.
docker compose up -d                     # server + TURN (perlindungan IP)
docker compose --profile sfu up -d       # + LiveKit untuk grup call 20+
```
Pasang di belakang HTTPS (Caddy/Nginx/Cloudflare). **Mikrofon, kamera, dan notifikasi hanya berfungsi di HTTPS.**

---

## ⚙️ GitHub: Repo & Workflows

| Workflow | Fungsi |
|---|---|
| `ci.yml` | Cek sintaks + tes server setiap push/PR (Node 20 & 22) |
| `android.yml` | **Build APK Android** (`./gradlew assembleDebug`) setiap push ke `main`; push tag `v1.0.0` → APK terbit di Releases |
| `docker.yml` | Build & push image server ke `ghcr.io/<kamu>/novalink` |
| `pages.yml` | Terbitkan aplikasi web ke GitHub Pages |

### Membuat repo & push
```bash
cd novalink
git remote add origin https://github.com/USERNAME/novalink.git
git push -u origin main
git tag v1.0.0 && git push --tags     # memicu build APK + Release
```
Atau dengan GitHub CLI: `gh repo create novalink --public --source . --push`

**Pengaturan repo:**
- Variabel `NOVALINK_SERVER_URL` (juga bisa `./gradlew assembleDebug -PnovalinkServer=https://...`) (Settings → Secrets and variables → Actions → Variables) berisi URL server publikmu. URL ini ditanam di APK & GitHub Pages
- (Opsional, untuk APK rilis bertanda tangan) secrets `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`
- GitHub Pages: Settings → Pages → Source: **GitHub Actions**

---

## 📁 Struktur

```
app/      Proyek Android native (WebView + mic/kamera/galeri + suara Nova via TTS & SpeechRecognizer Android)
settings.gradle, build.gradle, gradlew   → build: ./gradlew assembleDebug  (APK: app/build/outputs/apk/debug/)
server/   index.js (API + WebSocket + sinyal panggilan), ws.js (WebSocket RFC6455), store.js, test.js
client/   index.html, styles.css, sw.js, manifest.webmanifest, icons/
client/js app.js, call.js, audiofx.js (peredam/pengubah suara/musik), assistant.js (Nova),
          sounds.js (nada dering), offline.js, extensions.js, emoji.js, db.js
.github/workflows/  ci, android, docker, pages
```

## ⚠️ Batasan yang perlu diketahui
- **Telepon GSM biasa (operator seluler)** tidak bisa dikelola oleh aplikasi web. Nova mengelola panggilan & chat **di dalam Novalink**. Untuk mengangkat panggilan seluler diperlukan plugin native Android (ConnectionService/InCallService) yang bisa ditambahkan ke proyek Android di folder `app/`.
- **WhatsApp tidak menyediakan API terbuka** untuk aplikasi pihak ketiga mengirim chat atau telepon atas nama pengguna, atau menampilkan story di dalam WhatsApp. Klien WA tidak resmi melanggar ketentuan WhatsApp dan bisa membuat nomor diblokir. Karena itu Novalink terhubung lewat jalur resmi: tautan `wa.me`, share sheet (termasuk ke Status WA), dan halaman story publik yang bisa dibuka pengguna WA. Untuk bisnis, WhatsApp Business Platform (Cloud API) bisa diintegrasikan.
- Pengguna yang mengirim pesan di Novalink sebaiknya tahu bahwa penerima bisa memakai Anti-Hapus. Info ini ditampilkan di bagian atas setiap chat.
- Mode Offline langsung memerlukan kedua HP berada di jaringan lokal yang sama. Mesh Bluetooth murni memerlukan plugin native.
- Enkripsi saat ini memakai TLS (transport). End-to-end encryption (mis. Signal Protocol) adalah langkah pengembangan berikutnya.

---
MIT © 2026 Natan · **Novalink By Natan**
